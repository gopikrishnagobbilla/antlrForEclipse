/**
 * <small>
 * <p><i>Copyright (C) 2005 Torsten Juergeleit, 
 * All rights reserved. </i></p>
 * 
 * <p>USE OF THIS CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS
 * AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE
 * OF THE CONTENT IS GOVERNED BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS
 * OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED
 * BELOW. IF YOU DO NOT AGREE TO THE TERMS AND CONDITIONS OF THIS AGREEMENT AND
 * THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW, THEN YOU MAY NOT USE THE CONTENT.</p>
 * 
 * <p>This Content is Copyright (C) 2005 Torsten Juergeleit, 
 * and is provided to you under the terms and conditions of the Common Public 
 * License Version 1.0 ("CPL"). A copy of the CPL is provided with this Content 
 * and is also available at 
 *     <a href="http://www.eclipse.org/legal/cpl-v10.html">
 *         http://www.eclipse.org/legal/cpl-v10.html </a>.
 * 
 * For purposes of the CPL, "Program" will mean the Content.</p>
 * 
 * <p>Content includes, but is not limited to, source code, object code,
 * documentation and any other files in this distribution.</p>
 * 
 * </small>
 */
package antlr;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Reader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import org.antlr.eclipse.core.AntlrCorePlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;

/**
 * Replacement ANTLR tool (main entry point) for Eclipse integration
 */
public class AntlrTool extends Tool {
	private Map<String, Map<Integer, List<Integer>>> sourceMaps;
    private String[] fPreprocessedArgs = null;
	private LLkAnalyzer fAnalyzer = null;
	private MakeGrammar fBehavior = null;
    private ANTLRParser fParser = null;
    private Vector<String> fFiles = new Vector<String>();
    private Vector<PrintWriter> fWriters = new Vector<PrintWriter>();

	/**
	 * Create the antlr tool instance
	 */
	public AntlrTool() {
		setFileLineFormatter(new MarkerFormatter());
	}

	/**
	 * Returns iterator for all files created during last code generation.
	 * @return an iterator of all generated files
	 */
	public Iterator<String> files() {
		return fFiles.iterator();
	}

	/** {@inheritDoc} */
	@Override
	public void fatalError(String aMessage) {
		System.err.println(FileLineFormatter.getFormatter().
						   getFormatString(null, -1, -1) + aMessage);
		throw new IllegalStateException();
    }

    /** {@inheritDoc} */
	@Override
    public void error(String aMessage) {
		System.err.println(FileLineFormatter.getFormatter().
						   getFormatString(null, -1, -1) + aMessage);
        hasError = true;
    }

    /** {@inheritDoc} */
	@Override
    public void warning(String aMessage) {
		System.err.println(FileLineFormatter.getFormatter().
						   getFormatString(null, -1, -1) + "warning: " +
						   aMessage);
    }

	/** {@inheritDoc} */
	@Override
	public void warning(String[] aMessageLines, String aFile, int aLine,
						 int aColumn) {
		if (aMessageLines != null && aMessageLines.length != 0) {
			StringBuffer message = new StringBuffer(aMessageLines[0]);
			for (int i = 1; i < aMessageLines.length; i++) {
				String line = aMessageLines[i];
				int pos = 0;
				while (Character.isWhitespace(line.charAt(pos))) {
					pos++;
				}
				message.append(" ");
				message.append(line.substring(pos));
			}
			System.err.println(FileLineFormatter.getFormatter().
							   getFormatString(aFile, aLine, aColumn) +
							   "warning: " + message.toString());
		}
    }

	/** {@inheritDoc} */
	@Override
	public void toolError(String aMessage) {
		System.err.println(FileLineFormatter.getFormatter().
						   getFormatString(null, -1, -1) + aMessage);
	}

    /** {@inheritDoc} */
	@Override
    public PrintWriter openOutputFile(String aFileName) throws IOException {
		if (!fFiles.contains(aFileName)) {
			fFiles.add(aFileName);
		}
		PrintWriter writer = new PrintWriter(new FileWriter(outputDir +
							System.getProperty("file.separator") + aFileName));
		fWriters.add(writer);
		return writer;
    }

    /**
     * Perform preprocessing on the grammar file.
     * Can only be called from main().
     * @param anArgs  the command-line arguments passed to main()
     * @return true if there was an error, false otherwise
     */
    public boolean preprocess(String[] anArgs) {

        // run the preprocessor to handle inheritance first.
        antlr.preprocessor.Tool preTool = new antlr.preprocessor.Tool(this,
        															  anArgs);
        if (preTool.preprocess()) {
			fPreprocessedArgs = preTool.preprocessedArgList();
        } else {
            fPreprocessedArgs = null;
            hasError = true;
        }
        return hasError;
    }

    /**
     * Parse the grammar file.
     * Can only be called after calling preprocess().
     * @return true if there was an error; false otherwise
     * @throws CoreException If eclipse got upset
     */
    public boolean parse() throws CoreException {
        if (fPreprocessedArgs == null) {
            throw createException("AntlrTool.error.missingPreprocess");
        } else {
            // process arguments for the Tool
			processArguments(fPreprocessedArgs);
        }
		if (!hasError) {
			Reader reader = getGrammarReader();
			ANTLRLexer lexer = new ANTLRLexer(reader);
			fAnalyzer = new LLkAnalyzer(this);
			fBehavior = new MakeGrammar(this, fPreprocessedArgs, fAnalyzer);
            fParser = new ANTLRParser(new TokenBuffer(lexer), fBehavior, this);
            fParser.setFilename(grammarFile);
	        try {
	            fParser.grammar();
            } catch (IllegalStateException e) {
            	// Thrown by AntlrTool.fatalError()
				System.err.println(e.toString());
				hasError = true;
            } catch (RecognitionException e) {
				System.err.println(
							  FileLineFormatter.getFormatter().getFormatString(
							  null, e.getLine(), e.getColumn())
							  + e.getMessage());
				hasError = true;
            } catch (TokenStreamException e) {
				if (e instanceof TokenStreamRecognitionException) {
				System.err.println(e.toString());
				} else if (e.getMessage() != null) {
					System.err.println(
							  FileLineFormatter.getFormatter().getFormatString(
							  null, -1, -1)
							  + e.getMessage());
				}
            	hasError = true;
            } finally {

				// Close all writers opened during grammar inheritance
				// (expanded grammar files)
				Iterator<PrintWriter> writers = fWriters.iterator();
				while (writers.hasNext()) {
					PrintWriter writer = writers.next();
					writer.close();
				}

				// Close reader
            	try {
					reader.close();
            	} catch (IOException e) {
            		throw createException("AntlrTool.error.canNotCloseFile",
            							  grammarFile, e);
            	}
            }
        }
        return hasError;
    }

	/**
	 * Run the code generation
	 * @return true if there was an error; false otherwise
	 * @throws CoreException If eclipse got upset
	 */
	public boolean generate() throws CoreException {
        if (fParser == null) {
            throw createException("AntlrTool.error.missingParse");
        } else if (!hasError) {
//        	fFiles.clear();
        	fWriters.clear();

			// Create the right code generator according to the
            // "language" option
            String codeGenClassName = "antlr." + getLanguage(fBehavior) +
            						  "CodeGenerator";
            try {
                CodeGenerator codeGen = (CodeGenerator)
								 Class.forName(codeGenClassName).newInstance();
                codeGen.setBehavior(fBehavior);
                codeGen.setAnalyzer(fAnalyzer);
                codeGen.setTool(this);
                codeGen.gen();
                if (codeGen instanceof JavaCodeGenerator) {
                	sourceMaps = ((JavaCodeGenerator) codeGen).getPrintWriterManager().getSourceMaps();
                }
            } catch (ClassNotFoundException e) {
                throw createException("AntlrTool.error.noCodeGenerator",
                					   codeGenClassName, e);
            } catch (InstantiationException e) {
                throw createException("AntlrTool.error.noCodeGenerator",
                					   codeGenClassName, e);
            } catch (IllegalArgumentException e) {
                throw createException("AntlrTool.error.noCodeGenerator",
                					   codeGenClassName, e);
            } catch (IllegalAccessException e) {
                throw createException("AntlrTool.error.noCodeGenerator",
                					   codeGenClassName, e);
            } catch (IllegalStateException e) {

				// Thrown in fatalError() - ignore
				hasError = true;
			} finally {

				// Close all writers opened during code generation
				Iterator<PrintWriter> writers = fWriters.iterator();
				while (writers.hasNext()) {
					PrintWriter writer = writers.next();
					writer.close();
				}
			}
        }
        return hasError;
	}

    private CoreException createException(String aKey) {
        return createException(aKey, (String[])null, null);
    }
    
    private CoreException createException(String aKey, String anArg,
    									   Throwable aThrowable) {
        return createException(aKey, new String[] { anArg }, aThrowable);
    }
    
    private CoreException createException(String aKey, String[] anArgs,
    									   Throwable aThrowable) {
    	String msg = (anArgs == null ? AntlrCorePlugin.getMessage(aKey) :
    						AntlrCorePlugin.getFormattedMessage(aKey, anArgs));
        return new CoreException(new Status(IStatus.ERROR,
					   AntlrCorePlugin.PLUGIN_ID, IStatus.OK, msg, aThrowable));
    }

	private class MarkerFormatter extends FileLineFormatter {
	
		/**
	     * Returns given information separated by a '|'.
	     * 
	     * @param aFileName  the file that should appear in the prefix (or null)
	     * @param aLine  the line (or -1)
	     * @param aColumn  the column (or -1)
		 * @see antlr.FileLineFormatter#getFormatString(java.lang.String, int, int)
	     */
		@Override
	    public String getFormatString(String aFileName, int aLine,
									  int aColumn) {
	        StringBuffer buf = new StringBuffer();
	
	        if (aFileName != null) {
	            buf.append(aFileName);
	        } else {
	            buf.append("<noname>");
	        }
	        buf.append('|').append(aLine).append('|').append(aColumn).
	        														append('|');
	        return buf.toString();
	    }
	}

	public Map<String, Map<Integer, List<Integer>>> getSourceMaps() {
		return sourceMaps;
	}
}