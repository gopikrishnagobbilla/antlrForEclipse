/**
 * <small>
 * <p><i>Copyright (C) 2005 Torsten Juergeleit, 
 * All rights reserved. </i></p>
 * 
 * <p>USE OF THIS CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS
 * AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE
 * OF THE CONTENT IS GOVERNED BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS
 * OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED
 * BELOW. IF YOU DO NOT AGREE TO THE TERMS AND CONDITIONS OF THIS AGREEMENT AND
 * THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW, THEN YOU MAY NOT USE THE CONTENT.</p>
 * 
 * <p>This Content is Copyright (C) 2005 Torsten Juergeleit, 
 * and is provided to you under the terms and conditions of the Common Public 
 * License Version 1.0 ("CPL"). A copy of the CPL is provided with this Content 
 * and is also available at 
 *     <a href="http://www.eclipse.org/legal/cpl-v10.html">
 *         http://www.eclipse.org/legal/cpl-v10.html </a>.
 * 
 * For purposes of the CPL, "Program" will mean the Content.</p>
 * 
 * <p>Content includes, but is not limited to, source code, object code,
 * documentation and any other files in this distribution.</p>
 * 
 * </small>
 */
package org.antlr.eclipse.core.parser;

import java.io.Reader;
import java.util.Stack;

import org.antlr.eclipse.core.AntlrCorePlugin;

import antlr.ANTLRGrammarParseBehavior;
import antlr.ANTLRLexer;
import antlr.ANTLRParser;
import antlr.SemanticException;
import antlr.Token;
import antlr.TokenBuffer;
import antlr.Tool;
import antlr.collections.impl.BitSet;

/**
 * Parser used to create an ANTLR grammar overview (only terminals and
 * non-terminals; no actions, comments and type information).
 */
public class AntlrOverviewParser implements ANTLRGrammarParseBehavior {

	private StringBuffer fBuffer;
	private Stack<SubRule> fSubRules;
	private SubRule fCurrentSubRule;

	/**
	 * Parse a file to generate the overview
	 * @param aReader the file to parse
	 * @return overview 
	 */
	public String parse(final Reader aReader) {
		fBuffer = new StringBuffer(2000);
		fSubRules = new Stack<SubRule>();
		fCurrentSubRule = new SubRule();

		// Parse ANTLR grammar from given reader
		ANTLRLexer lexer = new ANTLRLexer(aReader);
		TokenBuffer tokenBuf = new TokenBuffer(lexer);
		ANTLRParser p = new ANTLRParser(tokenBuf, this,
										new OverviewTool());
		p.setFilename(".");
		try {
			p.grammar();
		}
		catch (Exception e) {
			AntlrCorePlugin.log(e);
		}

		String text = fBuffer.toString(); 

		fBuffer = null;
		fSubRules = null;
		fCurrentSubRule = null;

		return text;
	}

	/** {@inheritDoc} */
	public void beginAlt(final boolean doAST_) {
		if (fSubRules.empty()) {
			fBuffer.append("\n\t");
		}
		if (fCurrentSubRule.alt > 0) {
			fBuffer.append("| ");
		}
		fCurrentSubRule.alt++;
	}

	/** {@inheritDoc} */
	public void beginSubRule(final Token label, final Token start, final boolean not) {
		if (fCurrentSubRule.ref > 0 && fSubRules.empty()) {
			fBuffer.append("\n\t");
		}
		if (not) {
			fBuffer.append('~');
		}
		fBuffer.append("( ");
		fSubRules.push(fCurrentSubRule);
		fCurrentSubRule = new SubRule();
	}

	/** {@inheritDoc} */
	public void defineRuleName(final Token r, final String access, final boolean ruleAST,
			final String docComment) throws SemanticException {
		fBuffer.append('\n').append(r.getText()).append(" :");
	}

	/** {@inheritDoc} */
	public void endRule(String r) {
		if (fCurrentSubRule.ref > 0) {
			fBuffer.append("\n\t");
		}
		if (!fCurrentSubRule.isBracketClosed) {
			fBuffer.append('\t');
		}
		fBuffer.append(";\n");
		fCurrentSubRule.alt = 0;
		fCurrentSubRule.ref = 0;
	}

	/** {@inheritDoc} */
	public void endSubRule() {
		if (!fCurrentSubRule.isBracketClosed) {
			fBuffer.append(") ");
		}
		fCurrentSubRule = (SubRule)fSubRules.pop();
		if (fSubRules.empty()) {
			fBuffer.append("\n\t");
			fCurrentSubRule.isBracketClosed = true;
			fCurrentSubRule.ref = 0;
		}
	}

	/** {@inheritDoc} */
	public void oneOrMoreSubRule() {
		fBuffer.append(")+ ");
		fCurrentSubRule.isBracketClosed = true;
	}

	/** {@inheritDoc} */
	public void optionalSubRule() {
		fBuffer.append(")? ");
		fCurrentSubRule.isBracketClosed = true;
	}

	/** {@inheritDoc} */
	public void zeroOrMoreSubRule() {
		fBuffer.append(")* ");
		fCurrentSubRule.isBracketClosed = true;
	}

	/** {@inheritDoc} */
	public void synPred() {
		fBuffer.append(") => ");
		fCurrentSubRule.isBracketClosed = true;
	}

	/** {@inheritDoc} */
	public void refCharLiteral(final Token lit, final Token label, final boolean inverted,
			final int autoGenType, final boolean lastInRule) {
		if (inverted) {
			fBuffer.append('~');
		}
		fBuffer.append(lit.getText()).append(' ');
		fCurrentSubRule.ref++;
	}

	/** {@inheritDoc} */
	public void refCharRange(final Token t1, final Token t2, final Token label, final int autoGenType,
			final boolean lastInRule) {
		fBuffer.append(t1.getText()).append("..").append(t2.getText()).
																   append(' ');
		fCurrentSubRule.ref++;
	}

	/** {@inheritDoc} */
	public void refRule(final Token idAssign, final Token r, final Token label, final Token arg,
			final int autoGenType) {
		fBuffer.append(r.getText()).append(' ');
		fCurrentSubRule.ref++;
	}

	/** {@inheritDoc} */
	public void refSemPred(final Token pred) {
		fBuffer.append("{").append(pred.getText()).append("}? ");
		fCurrentSubRule.ref++;
	}

	/** {@inheritDoc} */
	public void refStringLiteral(final Token lit, final Token label, final int autoGenType,
			final boolean lastInRule) {
		fBuffer.append(lit.getText()).append(' ');
		fCurrentSubRule.ref++;
	}

	/** {@inheritDoc} */
	public void refToken(final Token assignId, final Token t, final Token label, final Token args,
			final boolean inverted, final int autoGenType, final boolean lastInRule) {
		if (inverted) {
			fBuffer.append('~');
		}
		fBuffer.append(t.getText()).append(' ');
		fCurrentSubRule.ref++;
	}

	/** {@inheritDoc} */
	public void refTokenRange(final Token t1, final Token t2, final Token label, final int autoGenType,
			final boolean lastInRule) {
		fBuffer.append(t1.getText()).append("..").append(t2.getText()).
																   append(' ');
		fCurrentSubRule.ref++;
	}

	/** {@inheritDoc} */
	public void refWildcard(final Token t, final Token label, final int autoGenType) {
		fBuffer.append(". ");
		fCurrentSubRule.ref++;
	}

	/** {@inheritDoc} */
	public void startLexer(final String file, final Token name, final String superClass,
			final String doc) {
		startClass(file, name, superClass, doc, "Lexer");
	}

	/** {@inheritDoc} */
	public void startParser(final String file, final Token name, final String superClass,
			final String doc) {
		startClass(file, name, superClass, doc, "Parser");
	}

	/** {@inheritDoc} */
	public void startTreeWalker(final String file, final Token name, final String superClass,
			final String doc) {
		startClass(file, name, superClass, doc, "TreeParser");
	}

	private void startClass(final String file, final Token name, final String superClass,
			final String doc, final String className) {
		if (fBuffer.length() > 0) {
			fBuffer.append("\n\n\n");
		}
		if (doc != null) {
			fBuffer.append(doc).append("\n\n");
		}
		fBuffer.append("class ").append(name.getText()).append(" extends ").
											 append(className).append(";\n\n");
	}

	/** {@inheritDoc} */
	public void abortGrammar() {
		// do nothing
	}

	/** {@inheritDoc} */
	public void beginChildList() {
		// do nothing
	}

	/** {@inheritDoc} */
	public void beginExceptionGroup() {
		// do nothing
	}

	/** {@inheritDoc} */
	public void beginExceptionSpec(final Token label) {
		// do nothing
	}

	/** {@inheritDoc} */
	public void beginTree(final Token tok) throws SemanticException {
		// do nothing
	}

	/** {@inheritDoc} */
	public void defineToken(final Token tokname, final Token tokliteral) {
		// do nothing
	}

	/** {@inheritDoc} */
	public void endAlt() {
		// do nothing
	}

	/** {@inheritDoc} */
	public void endChildList() {
		// do nothing
	}

	/** {@inheritDoc} */
	public void endExceptionGroup() {
		// do nothing
	}

	/** {@inheritDoc} */
	public void endExceptionSpec() {
		// do nothing
	}

	/** {@inheritDoc} */
	public void endGrammar() {
		// do nothing
	}

	/** {@inheritDoc} */
	public void endOptions() {
		// do nothing
	}

	/** {@inheritDoc} */
	public void endTree() {
		// do nothing
	}

	/** {@inheritDoc} */
	public void hasError() {
		// do nothing
	}

	/** {@inheritDoc} */
	public void noASTSubRule() {
		// do nothing
	}

	/** {@inheritDoc} */
	public void refAction(final Token action) {
		// do nothing
	}

	/** {@inheritDoc} */
	public void refArgAction(final Token action) {
		// do nothing
	}

	/** {@inheritDoc} */
	public void setUserExceptions(final String thr) {
		// do nothing
	}

	/** {@inheritDoc} */
	public void refElementOption(final Token option, final Token value) {
		// do nothing
	}

	/** {@inheritDoc} */
	public void refTokensSpecElementOption(final Token tok, final Token option,
			final Token value) {
		// do nothing
	}

	/** {@inheritDoc} */
	public void refExceptionHandler(final Token exTypeAndName, final Token action) {
		// do nothing
	}

	/** {@inheritDoc} */
	public void refHeaderAction(final Token name, final Token act) {
		// do nothing
	}

	/** {@inheritDoc} */
	public void refInitAction(final Token action) {
		// do nothing
	}

	/** {@inheritDoc} */
	public void refMemberAction(final Token act) {
		// do nothing
	}

	/** {@inheritDoc} */
	public void refPreambleAction(final Token act) {
		// do nothing
	}

	/** {@inheritDoc} */
	public void refReturnAction(final Token returnAction) {
		// do nothing
	}

	/** {@inheritDoc} */
	public void refTreeSpecifier(final Token treeSpec) {
		// do nothing
	}

	/** {@inheritDoc} */
	public void setArgOfRuleRef(final Token argaction) {
		// do nothing
	}

	/** {@inheritDoc} */
	public void setCharVocabulary(final BitSet b) {
		// do nothing
	}

	/** {@inheritDoc} */
	public void setFileOption(final Token key, final Token value, final String filename) {
		// do nothing
	}

	/** {@inheritDoc} */
	public void setGrammarOption(final Token key, final Token value) {
		// do nothing
	}

	/** {@inheritDoc} */
	public void setRuleOption(final Token key, final Token value) {
		// do nothing
	}

	/** {@inheritDoc} */
	public void setSubruleOption(final Token key, final Token value) {
		// do nothing
	}

	private class OverviewTool extends Tool {

		/** {@inheritDoc} */
		public void error(final String s, final String file, final int line, final int column) {
			// do nothing
		}

		/** {@inheritDoc} */
		public void error(final String s) {
			// do nothing
		}

		/** {@inheritDoc} */
		public void warning(final String s, final String file, final int line, final int column) {
			// do nothing
		}

		/** {@inheritDoc} */
		public void warning(final String s) {
			// do nothing
		}

		/** {@inheritDoc} */
		public void warning(final String[] s, final String file, final int line, final int column) {
			// do nothing
		}
	}

	private class SubRule {
		int ref = 0;
		int alt = 0;
		boolean isBracketClosed = false;
	}

	/** {@inheritDoc} */
	public void beginRule(final Token ruleId, final Token lookahead, final boolean ruleAutoGen) {
		// do nothing
	}
}
