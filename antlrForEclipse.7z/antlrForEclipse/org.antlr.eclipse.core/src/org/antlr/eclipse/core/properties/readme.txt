This directory contains an ANTXR-generated XML parser.

The generated files are provided so the ANTLR plugin can compile without requiring ANTXR be installed.

If you would like to compile from the ANTXR grammar, please obtain ANTXR from http://javadude.com/tools/antxr

-- Scott Stanchfield