/**
 * <small>
 * <p><i>Copyright (C) 2005 Torsten Juergeleit, 
 * All rights reserved. </i></p>
 * 
 * <p>USE OF THIS CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS
 * AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE
 * OF THE CONTENT IS GOVERNED BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS
 * OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED
 * BELOW. IF YOU DO NOT AGREE TO THE TERMS AND CONDITIONS OF THIS AGREEMENT AND
 * THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW, THEN YOU MAY NOT USE THE CONTENT.</p>
 * 
 * <p>This Content is Copyright (C) 2005 Torsten Juergeleit, 
 * and is provided to you under the terms and conditions of the Common Public 
 * License Version 1.0 ("CPL"). A copy of the CPL is provided with this Content 
 * and is also available at 
 *     <a href="http://www.eclipse.org/legal/cpl-v10.html">
 *         http://www.eclipse.org/legal/cpl-v10.html </a>.
 * 
 * For purposes of the CPL, "Program" will mean the Content.</p>
 * 
 * <p>Content includes, but is not limited to, source code, object code,
 * documentation and any other files in this distribution.</p>
 * 
 * </small>
 */
package org.antlr.eclipse.core.parser;

/**
 * Describes a block for the outline view
 */
public class Block extends AbstractModel {
    /** antlr header */
    public static final int HEADER = 0;
    /** antlr options */
    public static final int OPTIONS = 1;
    /** antlr tokens */
    public static final int TOKENS = 2;
    /** antlr preamble */
    public static final int PREAMBLE = 3;
    /** antlr comment */
    public static final int COMMENT = 4;
    /** antlr action code */
    public static final int ACTION = 5;
    /** antlr exception */
    public static final int EXCEPTION = 6;
	private static final String[] TYPES = { "Header", "Options", "Tokens",
	    									"Preamble", "Comment", "Action",
	    									"Exception" };
	private int fType;
	
	/**
	 * Define a block
	 * @param aParent the parent block
	 * @param aType the type of block
	 * @param aStartLine the start line
	 * @param anEndLine the end line
	 */
	public Block(final IModel aParent, final int aType, final int aStartLine, final int anEndLine) {
	    super(TYPES[aType], aParent);
	    fType = aType;
	    setStartLine(aStartLine);
	    setEndLine(anEndLine);
	}
	
	/** {@inheritDoc} */
	public boolean hasChildren() {
	    return false;
	}

	/** {@inheritDoc} */
	public Object[] getChildren() {
	    return NO_CHILDREN;
	}
	
	/** {@inheritDoc} */
	public String getUniqueID() {
		return ((ISegment)getParent()).getUniqueID() + "/Block:" +
				TYPES[fType];
	}

	/** {@inheritDoc} */
	public boolean accept(final ISegmentVisitor aVisitor) {
		return aVisitor.visit(this);
	}
	
	/**
	 * Get the type of block
	 * @return the block type
	 */
	public int getType() {
	    return fType;
	}
	
	/** {@inheritDoc} */
	public String toString() {
	    return getUniqueID() + " [" + getStartLine() + ":" +
	    		getEndLine() + "]";
	}
}
