/**
 * <small>
 * <p><i>Copyright (C) 2005 Torsten Juergeleit, 
 * All rights reserved. </i></p>
 * 
 * <p>USE OF THIS CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS
 * AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE
 * OF THE CONTENT IS GOVERNED BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS
 * OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED
 * BELOW. IF YOU DO NOT AGREE TO THE TERMS AND CONDITIONS OF THIS AGREEMENT AND
 * THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW, THEN YOU MAY NOT USE THE CONTENT.</p>
 * 
 * <p>This Content is Copyright (C) 2005 Torsten Juergeleit, 
 * and is provided to you under the terms and conditions of the Common Public 
 * License Version 1.0 ("CPL"). A copy of the CPL is provided with this Content 
 * and is also available at 
 *     <a href="http://www.eclipse.org/legal/cpl-v10.html">
 *         http://www.eclipse.org/legal/cpl-v10.html </a>.
 * 
 * For purposes of the CPL, "Program" will mean the Content.</p>
 * 
 * <p>Content includes, but is not limited to, source code, object code,
 * documentation and any other files in this distribution.</p>
 * 
 * </small>
 */
package org.antlr.eclipse.core.parser;

import java.util.Enumeration;
import java.util.Vector;

import antlr.Token;

/**
 * Represents a grammar in the outline view
 */
public class Grammar extends AbstractModel {

	private Block fPreamble = null;
	private Block fDocComment = null;
	private Block fOptions = null;
	private Block fTokens = null;
	private Block fMemberAction = null;
	private Vector<Rule> fRules = new Vector<Rule>();

	/**
	 * Create the grammar node
	 * @param aHierarchy the hiearchy definition
	 * @param aName the name of the node
	 * @param aSuperClass the superclass
	 * @param aStartLine the start line
	 */
	public Grammar(final Hierarchy aHierarchy, final String aName, final String aSuperClass,
			final int aStartLine) {
		super(aName, aHierarchy);
		// superclass not used
		setStartLine(aStartLine);
		setEndLine(aStartLine);
	}
	
    /**
     * @see IModel#hasChildren()
     */
	public boolean hasChildren() {
	    return fPreamble != null || fDocComment != null || fOptions != null ||
	    	   fTokens != null || fMemberAction != null || !fRules.isEmpty();
	}

    /**
     * @see IModel#getChildren()
     */
	public Object[] getChildren() {
	    Vector<AbstractModel> childs = new Vector<AbstractModel>();
	    if (fPreamble != null) {
	        childs.add(fPreamble);
	    }
	    if (fDocComment != null) {
	        childs.add(fDocComment);
	    }
	    if (fOptions != null) {
	        childs.add(fOptions);
	    }
	    if (fTokens != null) {
	        childs.add(fTokens);
	    }
	    if (fMemberAction != null) {
	        childs.add(fMemberAction);
	    }
	    childs.addAll(fRules);
	    return childs.toArray();
	}
	
	/**
	 * @see ISegment#getUniqueID()
	 */
	public String getUniqueID() {
		return ((ISegment)getParent()).getUniqueID() + "/Grammar:" + getName();
	}

	/**
	 * @see ISegment#accept(ISegmentVisitor)
	 */
	public boolean accept(final ISegmentVisitor aVisitor) {
		boolean more = true;
		
		// At first visit all rules of this grammar
		Enumeration<Rule> rules = fRules.elements();
		while (rules.hasMoreElements() && more) {
			more = ((ISegment)rules.nextElement()).accept(aVisitor);
		}

		// Now visit this grammar's preamble, doc comment, options, tokens and
		// member action
		if (more && fPreamble != null) {
			more = aVisitor.visit(fPreamble);
		}
		if (more && fDocComment != null) {
			more = aVisitor.visit(fDocComment);
		}
		if (more && fOptions != null) {
			more = aVisitor.visit(fOptions);
		}
		if (more && fTokens != null) {
			more = aVisitor.visit(fTokens);
		}
		if (more && fMemberAction != null) {
			more = aVisitor.visit(fMemberAction);
		}

		// Finally visit this grammar
		if (more) {
			more = aVisitor.visit(this);
		}
		return more;
	}

	/**
	 * Set the preamble for the grammar
	 * @param aToken the preamble
	 */
	public	void setPreamble(final Token aToken) {
	    fPreamble = new Block(this, Block.PREAMBLE, aToken.getLine(),
	    					  aToken.getColumn());
	}

	/**
	 * get the reamble for the grammar
	 * @return the reamble
	 */
	public Block getPreamble() {
	    return fPreamble;
	}

	/**
	 * set the doc comment for the grammar
	 * @param aToken the doc comment
	 */
	public	void setDocComment(final Token aToken) {
	    fDocComment = new Block(this, Block.COMMENT, aToken.getLine(),
	    						aToken.getColumn());
	}

	/**
	 * Get the doc comment for the grammar
	 * @return the doc comment
	 */
	public Block getDocComment() {
	    return fDocComment;
	}
	
	/**
	 * Set the options for the grammar
	 * @param aToken the options
	 */
	public void setOptions(final Token aToken) {
	    fOptions = new Block(this, Block.OPTIONS, aToken.getLine(),
	    					 aToken.getColumn());
	}

	/**
	 * Get the options for the grammar
	 * @return the options
	 */
	public Block getOptions() {
	    return fOptions;
	}
	
	/**
	 * Set the tokens for the grammar
	 * @param aToken the tokens
	 */
	public void setTokens(final Token aToken) {
	    fTokens = new Block(this, Block.TOKENS, aToken.getLine(),
	    					aToken.getColumn());
	}

	/**
	 * Get the tokens
	 * @return the tokens
	 */
	public Block getTokens() {
	    return fTokens;
	}
	
	/**
	 * Set the member action
	 * @param aToken the member action
	 */
	public void setMemberAction(final Token aToken) {
	    fMemberAction = new Block(this, Block.ACTION, aToken.getLine(),
	    						  aToken.getColumn());
	}

	/**
	 * Get the member action
	 * @return member action
	 */
	public Block getMemberAction() {
	    return fMemberAction;
	}
	
	/**
	 * Add a rule to the grammar
	 * @param aRule the rule to add
	 */
	public void addRule(final Rule aRule) {
	    fRules.add(aRule);
	}

	/**
	 * Get all rules in the grammar
	 * @return the rules
	 */
	public Enumeration<Rule> getRules() {
	    return fRules.elements();
	}

	/**
	 * Get the last rule in the grammar
	 * @return the last rule
	 */
	public Rule getLastRule() {
	    return (fRules.isEmpty() ? null : (Rule)fRules.lastElement());
	}

	/** {@inheritDoc} */
	public String toString() {
	    return getUniqueID() + " [" + getStartLine() + ":" + getEndLine() +
	    		"] with rule(s) " + fRules;
	}
}
