// $ANTXR : "antlrSettings.antxr" -> "AntlrSettingsParser.java"$
// GENERATED CODE - DO NOT EDIT!

package org.antlr.eclipse.core.properties;
import java.util.Map;
import java.util.HashMap;

public interface AntlrSettingsParserTokenTypes {
	int EOF = 1;
	int NULL_TREE_LOOKAHEAD = 3;
	// "<settings>" = 4
	int XML_END_TAG = 5;
	// "<resource>" = 6
	// "<property>" = 7
}
