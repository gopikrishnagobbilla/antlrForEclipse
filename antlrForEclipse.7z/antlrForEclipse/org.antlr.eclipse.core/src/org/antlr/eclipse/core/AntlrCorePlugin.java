/**
 * <small>
 * <p><i>Copyright (C) 2005 Torsten Juergeleit, 
 * All rights reserved. </i></p>
 * 
 * <p>USE OF THIS CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS
 * AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE
 * OF THE CONTENT IS GOVERNED BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS
 * OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED
 * BELOW. IF YOU DO NOT AGREE TO THE TERMS AND CONDITIONS OF THIS AGREEMENT AND
 * THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW, THEN YOU MAY NOT USE THE CONTENT.</p>
 * 
 * <p>This Content is Copyright (C) 2005 Torsten Juergeleit, 
 * and is provided to you under the terms and conditions of the Common Public 
 * License Version 1.0 ("CPL"). A copy of the CPL is provided with this Content 
 * and is also available at 
 *     <a href="http://www.eclipse.org/legal/cpl-v10.html">
 *         http://www.eclipse.org/legal/cpl-v10.html </a>.
 * 
 * For purposes of the CPL, "Program" will mean the Content.</p>
 * 
 * <p>Content includes, but is not limited to, source code, object code,
 * documentation and any other files in this distribution.</p>
 * 
 * </small>
 */
package org.antlr.eclipse.core;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.text.MessageFormat;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.MissingResourceException;
import java.util.ResourceBundle;
import java.util.StringTokenizer;

import org.antlr.eclipse.core.properties.SettingsPersister;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IWorkspace;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.MultiStatus;
import org.eclipse.core.runtime.Path;
import org.eclipse.core.runtime.Platform;
import org.eclipse.core.runtime.Plugin;
import org.eclipse.core.runtime.QualifiedName;
import org.eclipse.core.runtime.Status;
import org.eclipse.jdt.core.JavaCore;
import org.eclipse.jdt.core.JavaModelException;
import org.osgi.framework.Bundle;
import org.osgi.framework.BundleContext;

/**
 * Central access point for the ANTLR Core plug-in
 * (id <code>"org.antlr.eclipse.core"</code>).
 *
 * @author Torsten Juergeleit
 * @author Scott Stanchfield
 */
public class AntlrCorePlugin extends Plugin {
	static {
		// tell ANTLR not to call System.exit
		System.setProperty("ANTLR_DO_NOT_EXIT", "true");
		// tell ANTLR not to use context class loaders
		System.setProperty("ANTLR_USE_DIRECT_CLASS_LOADING", "true");
	}
	
	/** The name of the ANTLR_HOME classpath variable */
	public static final String VERSION = "2.7.6";
	
	/** The name of the plugin version property in the settings file */
	public static final String PLUGIN_RESOURCE_NAME = "**ANTLR-ECLIPSE-PLUGIN**";
	
	/** The name of the ANTLR_HOME classpath variable */
	public static final String ANTLR_HOME = "ANTLR_HOME";
	
	/** ID of the ANTLR core plugin
	 * (value <code>"org.antlr.eclipse.core"</code>) */	
	public static final String PLUGIN_ID = "org.antlr.eclipse.core";

	/** The name of the source mapping markers */
	public static final String SOURCE_MAPPING_MARKER = PLUGIN_ID + ".sourceMapMarker";
	
	/** The name of the source mapping grammar line attribute */
	public static final String GRAMMAR_LINE_ATTRIBUTE = "grammarLine";
	
	/** The name of the source mapping generated line attribute */
	public static final String GENERATED_LINE_ATTRIBUTE = "generatedLine";
	
	/** Name of the property holding the output path for generated files */
	public static final QualifiedName OLD_OUTPUT_PROPERTY =
								new QualifiedName(PLUGIN_ID, "AntlrOutput");
	
	/** Name of the property holding a list of paths to super grammar files
	 * (delimited by ';') */
	public static final QualifiedName OLD_SUPER_GRAMMARS_PROPERTY =
							new QualifiedName(PLUGIN_ID, "AntlrSuperGrammars");

	/** Name of the property holding a list of paths to super grammar files
	 * (delimited by ';') */
	public static final QualifiedName OLD_IMPORT_VOCABULARIES_PROPERTY =
							new QualifiedName(PLUGIN_ID, "AntlrImportVocabularies");
	
	/** Singleton instance of this plugin */
	private static AntlrCorePlugin plugin;

	private static final String RESOURCE_NAME = PLUGIN_ID + ".messages";
	private ResourceBundle fResourceBundle;

	/**
	 * 
	 */
	public AntlrCorePlugin() {
		plugin = this;
		try {
			fResourceBundle = ResourceBundle.getBundle(RESOURCE_NAME);
		} catch (MissingResourceException e) {
			log(e);
			fResourceBundle = null;
		}
	}
	
	protected void createClasspathVariable(final String pluginName, final String variableName) {
		Bundle bundle= Platform.getBundle(pluginName); //$NON-NLS-1$
		
		if (bundle == null) {
			JavaCore.removeClasspathVariable(variableName, null);
			return;
		}
		else {
			URL installLocation= bundle.getEntry("/"); //$NON-NLS-1$
			URL local= null;
			try {
				local= Platform.asLocalURL(installLocation);
			} catch (IOException e) {
				JavaCore.removeClasspathVariable(variableName, null);
				return;
			}
			try {
				String fullPath= new File(local.getPath()).getAbsolutePath();
				JavaCore.setClasspathVariable(variableName, new Path(fullPath), null);
			} catch (JavaModelException e1) {
				JavaCore.removeClasspathVariable(variableName, null);
			}
		}		
	}
	
	/** {@inheritDoc} */
	@Override
	public void start(final BundleContext context) throws Exception {
		super.start(context);
		// Add ANTLR grammar files to JDT builder's copy exclusion filter
		Hashtable options = JavaCore.getOptions();
		String filter = (String) options.get(JavaCore.CORE_JAVA_BUILD_RESOURCE_COPY_FILTER);
		StringTokenizer st = new StringTokenizer(filter, ",");
		boolean found = false;
		while (st.hasMoreTokens()) {
			if (st.nextToken().equals("*.g")) {
				found = true;
				break;
			}
		}
		if (!found) {
			if (isDebug()) {
				System.out.println("Adding '*.g' to JDT builder's " +
								   "resource filter (" + filter + ")");
			}
			options.put(JavaCore.CORE_JAVA_BUILD_RESOURCE_COPY_FILTER, filter + ",*.g");
			JavaCore.setOptions(options);
		}

		createClasspathVariable("org.antlr", ANTLR_HOME);
	}
	
	/**
	 * Returns the shared instance.
	 * @return the shared instance
	 */
	public static AntlrCorePlugin getDefault() {
		return plugin;
	}

	/**
	 * Get the resource bundle for the app
	 * @return the resource bundle
	 */
	public ResourceBundle getResourceBundle() {
		return fResourceBundle;
	}

	/**
	 * Get the workspace
	 * @return The workspace
	 */
	public static IWorkspace getWorkspace() {
		return ResourcesPlugin.getWorkspace();
	}
	
	/**
	 * Log an error message
	 * @param aStatus The status information to log
	 */
	public static void log(final IStatus aStatus) {
		getDefault().getLog().log(aStatus);
	}
	
	/**
	 * Log an exception
	 * @param aThrowable The exception to log
	 */
	public static void log(final Throwable aThrowable) {
		log(new Status(IStatus.ERROR, PLUGIN_ID, Status.OK,
						getMessage("AntlrCorePlugin.internal_error"),
						aThrowable));
	}
	
	/**
	 * Log an error message
	 * @param aMessage the error message to log
	 */
	public static void logErrorMessage(final String aMessage) {
		log(new Status(IStatus.ERROR, PLUGIN_ID, Status.OK, aMessage,
			null));
	}

	/**
	 * Log a message and a status
	 * @param aMessage The message
	 * @param aStatus The status
	 */
	public static void logErrorStatus(final String aMessage, final IStatus aStatus) {
		if (aStatus == null) {
			logErrorMessage(aMessage);
		} else {
			MultiStatus multi = new MultiStatus(PLUGIN_ID, Status.OK,
											    aMessage, null);
			multi.add(aStatus);
			log(multi);
		}
	}
	
	/**
	 * Are we in debug mode?
	 * @return true if in debug mode; false otherwise
	 */
	public static boolean isDebug() {
		return getDefault().isDebugging();
	}

	/**
	 * Is the specified option a valid debug option?
	 * @param anOption The option to test
	 * @return true if it's a debug option; false otherwise
	 */
	public static boolean isDebug(final String anOption) {
		boolean debug;
		if (isDebug()) {
			String value = Platform.getDebugOption(anOption);
			debug = (value != null && value.equalsIgnoreCase("true") ?
					 true : false);
		} else {
			debug = false;
		}
		return debug;
	}

	/**
	 * Translate a key into message text
	 * @param aKey The key to translate
	 * @return The message text
	 */
	public static String getMessage(final String aKey) {
	    String bundleString;
		ResourceBundle bundle = getDefault().getResourceBundle();
		if (bundle != null) {
			try {
				bundleString = bundle.getString(aKey);
			} catch (MissingResourceException e) {
			    log(e);
				bundleString = "!" + aKey + "!";
			}
		} else {
			bundleString = "!" + aKey + "!";
		}
		return bundleString;
	}

	/**
	 * Translate a message with an argument
	 * @param aKey The message key
	 * @param anArg The argument to replace
	 * @return The formatted message
	 */
	public static String getFormattedMessage(final String aKey, final String anArg) {
		return getFormattedMessage(aKey, new String[] { anArg });
	}

	/**
	 * Translate a message with arguments
	 * @param aKey The message key
	 * @param anArgs the replacement strings
	 * @return The formatted message
	 */
	public static String getFormattedMessage(final String aKey, final String[] anArgs) {
		return MessageFormat.format(getMessage(aKey), anArgs);
	}
	
	/**
	 * Upgrade from the old antlr settings to the new ones
	 * @param resource the resource to upgrade
	 * @param map the new map of settings
	 */
	public void upgradeOldSettings(final IResource resource, final HashMap<String,HashMap<String,String>> map) {
		boolean upgraded = false;
		
		// check for old settings, delete them, and overwrite the defaults
		String oldValue;
		try {
			oldValue = resource.getPersistentProperty(AntlrCorePlugin.OLD_OUTPUT_PROPERTY);
			resource.setPersistentProperty(AntlrCorePlugin.OLD_OUTPUT_PROPERTY, null);
			if (oldValue != null) {
				upgraded = true;
				SettingsPersister.set(map, resource, SettingsPersister.OUTPUT_PROPERTY, oldValue);
			}
		}
		catch (CoreException e) {
			e.printStackTrace();
		}
		try {
			oldValue = resource.getPersistentProperty(AntlrCorePlugin.OLD_SUPER_GRAMMARS_PROPERTY);
			resource.setPersistentProperty(AntlrCorePlugin.OLD_SUPER_GRAMMARS_PROPERTY, null);
			if (oldValue != null) {
				upgraded = true;
				SettingsPersister.set(map, resource, SettingsPersister.SUPER_GRAMMARS_PROPERTY, oldValue);
			}
		}
		catch (CoreException e) {
			e.printStackTrace();
		}
		try {
			oldValue = resource.getPersistentProperty(AntlrCorePlugin.OLD_IMPORT_VOCABULARIES_PROPERTY);
			resource.setPersistentProperty(AntlrCorePlugin.OLD_IMPORT_VOCABULARIES_PROPERTY, null);
			if (oldValue != null) {
				upgraded = true;
				SettingsPersister.set(map, resource, SettingsPersister.IMPORT_VOCABULARIES_PROPERTY, oldValue);
			}
		}
		catch (CoreException e) {
			e.printStackTrace();
		}	

		// if the version # changed, mark the properties with the new plugin version
		// we're not using the version # now, but we may need it for compat later
		if (!AntlrCorePlugin.VERSION.equals(SettingsPersister.get(map, SettingsPersister.PLUGIN_VERSION_PROPERTY))) {
			upgraded = true;
			SettingsPersister.set(map, SettingsPersister.PLUGIN_VERSION_PROPERTY, AntlrCorePlugin.VERSION);
		}
		
		if (upgraded) {
			SettingsPersister.writeSettings(resource.getProject(), map);
		}
	}
}
