/**
 * <small>
 * <p><i>Copyright (C) 2005 Torsten Juergeleit, 
 * All rights reserved. </i></p>
 * 
 * <p>USE OF THIS CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS
 * AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE
 * OF THE CONTENT IS GOVERNED BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS
 * OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED
 * BELOW. IF YOU DO NOT AGREE TO THE TERMS AND CONDITIONS OF THIS AGREEMENT AND
 * THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW, THEN YOU MAY NOT USE THE CONTENT.</p>
 * 
 * <p>This Content is Copyright (C) 2005 Torsten Juergeleit, 
 * and is provided to you under the terms and conditions of the Common Public 
 * License Version 1.0 ("CPL"). A copy of the CPL is provided with this Content 
 * and is also available at 
 *     <a href="http://www.eclipse.org/legal/cpl-v10.html">
 *         http://www.eclipse.org/legal/cpl-v10.html </a>.
 * 
 * For purposes of the CPL, "Program" will mean the Content.</p>
 * 
 * <p>Content includes, but is not limited to, source code, object code,
 * documentation and any other files in this distribution.</p>
 * 
 * </small>
 */
package org.antlr.eclipse.core;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;

import org.antlr.eclipse.core.builder.AntlrBuilder;
import org.antlr.eclipse.core.builder.WarningCleanerBuilder;
import org.antlr.eclipse.smapinstaller.SMapInstallerBuilder;
import org.eclipse.core.resources.ICommand;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IProjectDescription;
import org.eclipse.core.resources.IProjectNature;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.Path;
import org.eclipse.jdt.core.IClasspathEntry;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.JavaCore;


/**
 * An eclipse nature that represents a project that contains ANTLR grammars
 */
public class AntlrNature implements IProjectNature {
    /** The antlr-eclipse nature id */
    public static final String ID = AntlrCorePlugin.PLUGIN_ID + ".antlrnature";
    /** The antlr-eclipse plugin debugging optiojn */
	public static final String DEBUG_OPTION = AntlrCorePlugin.PLUGIN_ID + "/nature/debug";
	
	/** are we in debug mode? */
	public static boolean DEBUG = false;

	private IProject fProject;

	/**
	 * Create an instance of the nature
	 */
	public AntlrNature() {
		DEBUG = AntlrCorePlugin.isDebug(DEBUG_OPTION);
	}
	
    /**
     * @see IProjectNature#getProject()
     */
    public IProject getProject() {
        return fProject;
    }

    /**
     * @see IProjectNature#setProject(IProject)
     */
    public void setProject(final IProject aProject) {
		fProject = aProject;
    }

    /**
     * @see IProjectNature#configure()
     */
    public void configure() throws CoreException {
    	if (DEBUG) {
    		System.out.println("configuring ANTLR nature");
    	}
    	IProject project = getProject();
    	IProjectDescription projectDescription = project.getDescription();
    	ArrayList<ICommand> commands = new ArrayList<ICommand>(Arrays.asList(projectDescription.getBuildSpec()));
    	
    	ICommand antlrBuilderCommand = projectDescription.newCommand();
    	antlrBuilderCommand.setBuilderName(AntlrBuilder.BUILDER_ID);
    	ICommand warningCleanerBuilderCommand = projectDescription.newCommand();
		warningCleanerBuilderCommand.setBuilderName(WarningCleanerBuilder.BUILDER_ID);
    	ICommand smapBuilderCommand = projectDescription.newCommand();
    	smapBuilderCommand.setBuilderName(SMapInstallerBuilder.BUILDER_ID);
    	
    	if (!commands.contains(antlrBuilderCommand))
    		commands.add(0,antlrBuilderCommand); // add at start
    	if (!commands.contains(warningCleanerBuilderCommand))
    		commands.add(warningCleanerBuilderCommand);  // add at end
    	if (!commands.contains(smapBuilderCommand))
    		commands.add(smapBuilderCommand);  // add at end
    	
    	// Commit the spec change into the project
    	projectDescription.setBuildSpec((ICommand[])commands.toArray(new ICommand[commands.size()]));
    	getProject().setDescription(projectDescription, null);
    }

    /**
     * @see IProjectNature#deconfigure()
     */
    public void deconfigure() throws CoreException {
    	if (DEBUG) {
    		System.out.println("deconfiguring ANTLR nature");
    	}
    	IProject project = getProject();
    	IProjectDescription desc = project.getDescription();
    	ArrayList<ICommand> commands = new ArrayList<ICommand>(Arrays.asList(desc.getBuildSpec()));
    	for (Iterator<ICommand> i = commands.iterator(); i.hasNext();) {
			ICommand command = i.next();
			if (command.getBuilderName().equals(AntlrBuilder.BUILDER_ID) ||
				command.getBuilderName().equals(SMapInstallerBuilder.BUILDER_ID) ||
				command.getBuilderName().equals(WarningCleanerBuilder.BUILDER_ID))
				i.remove();
		}
    	
    	// Commit the spec change into the project
    	desc.setBuildSpec((ICommand[])commands.toArray(new ICommand[commands.size()]));
    	project.setDescription(desc, null);
    }

	/**
	 * Add the ANTLR nature to a project
	 * @param aProject The project to add it to
	 * @param aMonitor A progess monitor
	 */
	public static void addNature(final IProject aProject, final IProgressMonitor aMonitor) {
		if (aProject != null) {
	    	if (DEBUG) {
	    		System.out.println("adding ANTLR nature to project '" +
	    						   aProject.getName() + "'");
	    	}
			try {
				if (!aProject.hasNature(ID)) {
			    	IProjectDescription desc = aProject.getDescription();
			    	ArrayList<String> natures = new ArrayList<String>(Arrays.asList(desc.getNatureIds()));
			    	natures.add(0,ID);
					desc.setNatureIds(natures.toArray(new String[natures.size()]));
					aProject.setDescription(desc, aMonitor);
					
					// if it's a Java project, set up classpath variable for:
					//    ANTLR_HOME
					// these will point to the ANTLR plugins' 
					//   jars, respectively
					if (aProject.hasNature(JavaCore.NATURE_ID)) {
						IJavaProject javaProject = JavaCore.create(aProject);
						ArrayList<IClasspathEntry> rawClasspath = new ArrayList<IClasspathEntry>(Arrays.asList(javaProject.getRawClasspath()));
						boolean hasAntlrJar = false;
						for (Iterator<IClasspathEntry> i = rawClasspath.iterator(); i.hasNext();) {
							IClasspathEntry entry = i.next();
							if (entry.getEntryKind() == IClasspathEntry.CPE_VARIABLE) {
								String segment0 = entry.getPath().segment(0);
								if (AntlrCorePlugin.ANTLR_HOME.equals(segment0)) {
									hasAntlrJar = true;
									break;
								}
							}
						}
						if (!hasAntlrJar)
							rawClasspath.add(JavaCore.newVariableEntry(
									new Path(AntlrCorePlugin.ANTLR_HOME + "/antlr.jar"),
									new Path(AntlrCorePlugin.ANTLR_HOME + "/antlrsrc.zip"),
									null));
						
						if (!hasAntlrJar)
							javaProject.setRawClasspath((IClasspathEntry[]) rawClasspath.toArray(new IClasspathEntry[rawClasspath.size()]),null);
					}
				}
			} catch(CoreException e) {
				AntlrCorePlugin.log(e);
			}
		}
	}
	
	/**
	 * Remove the ANTLR nature from a project
	 * @param aProject The project to remove the nature from
	 * @param aMonitor A progress monitor
	 */
	public static void removeNature(final IProject aProject, final IProgressMonitor aMonitor) {
		if (aProject != null) {
	    	if (DEBUG) {
	    		System.out.println("removing ANTLR nature from project '" +
	    						   aProject.getName() + "'");
	    	}
			try {
				if (aProject.hasNature(ID)) {
			    	IProjectDescription desc = aProject.getDescription();
			    	ArrayList<String> natures = new ArrayList<String>(Arrays.asList(desc.getNatureIds()));
			    	natures.remove(ID);
					desc.setNatureIds(natures.toArray(new String[natures.size()]));
					aProject.setDescription(desc, aMonitor);
					
					// if it's a Java Project, remove the ANTLR_HOME class path variable
					if (aProject.hasNature(JavaCore.NATURE_ID)) {
						IJavaProject javaProject = JavaCore.create(aProject);
						ArrayList<IClasspathEntry> rawClasspath = new ArrayList<IClasspathEntry>(Arrays.asList(javaProject.getRawClasspath()));
						boolean hadAntlrJar = false;
						for (Iterator<IClasspathEntry> i = rawClasspath.iterator(); i.hasNext();) {
							IClasspathEntry entry = i.next();
							if (entry.getEntryKind() == IClasspathEntry.CPE_VARIABLE) {
								String segment0 = entry.getPath().segment(0);
								if (AntlrCorePlugin.ANTLR_HOME.equals(segment0)) {
									i.remove();
									hadAntlrJar = true;
								}
								if ("PARSEVIEW_HOME".equals(segment0)) {
									i.remove();
									hadAntlrJar = true;
								}
							}
						}
						if (hadAntlrJar) {
							javaProject.setRawClasspath((IClasspathEntry[]) rawClasspath.toArray(new IClasspathEntry[rawClasspath.size()]),null);
						}
					}
				}
			} catch(CoreException e) {
				AntlrCorePlugin.log(e);
			}
		} 
	}

	/**
	 * Returns true if given project has an ANTLR project nature.
	 * @param aProject The project to check
	 * @return true if it's an ANTLR project; false otherwise
	 * @see IProject#hasNature(String)
	 */
	public static boolean hasNature(final IProject aProject) {
	    boolean hasNature;
		try {
			hasNature = aProject.hasNature(ID);
		} catch (CoreException e) {
			AntlrCorePlugin.log(e);
			hasNature = false;
		}
		return hasNature;
	}
}
