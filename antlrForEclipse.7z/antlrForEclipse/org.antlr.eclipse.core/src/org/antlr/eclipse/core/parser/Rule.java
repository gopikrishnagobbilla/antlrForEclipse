/**
 * <small>
 * <p><i>Copyright (C) 2005 Torsten Juergeleit, 
 * All rights reserved. </i></p>
 * 
 * <p>USE OF THIS CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS
 * AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE
 * OF THE CONTENT IS GOVERNED BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS
 * OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED
 * BELOW. IF YOU DO NOT AGREE TO THE TERMS AND CONDITIONS OF THIS AGREEMENT AND
 * THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW, THEN YOU MAY NOT USE THE CONTENT.</p>
 * 
 * <p>This Content is Copyright (C) 2005 Torsten Juergeleit, 
 * and is provided to you under the terms and conditions of the Common Public 
 * License Version 1.0 ("CPL"). A copy of the CPL is provided with this Content 
 * and is also available at 
 *     <a href="http://www.eclipse.org/legal/cpl-v10.html">
 *         http://www.eclipse.org/legal/cpl-v10.html </a>.
 * 
 * For purposes of the CPL, "Program" will mean the Content.</p>
 * 
 * <p>Content includes, but is not limited to, source code, object code,
 * documentation and any other files in this distribution.</p>
 * 
 * </small>
 */
package org.antlr.eclipse.core.parser;

import java.util.Enumeration;
import java.util.Vector;

import antlr.Token;

/**
 * Represents a rule in the outline view
 */
public class Rule extends AbstractModel {
	/** The rule is private */
    public static final int PRIVATE = 1;
	/** The rule is protected */
    public static final int PROTECTED = 2;
	/** The rule is public */
    public static final int PUBLIC = 3;
    
	private int fVisibility;
	private Block fDocComment = null;
	private Block fOptions = null;
	private Block fMemberAction = null;
	private Vector<Block> fExceptions = new Vector<Block>();
	
	/** Indicates if rules is excluded from transformation (suffix "!") */
	private boolean fIsExcluded;
	
	/**
	 * create a rule node
	 * @param aGrammar the grammar containing the rule
	 * @param aName the name of the rule
	 * @param aVisibility the visibility of the rule
	 * @param aStartLine the start line of the rule
	 */
	public Rule(final Grammar aGrammar, final String aName, final int aVisibility,
			final int aStartLine) {
		super(aName, aGrammar);
	    fVisibility = aVisibility;
	    setStartLine(aStartLine);
	    setEndLine(aStartLine);
	}
	
    /**
     * @see IModel#hasChildren()
     */
	public boolean hasChildren() {
	    return fDocComment != null || fOptions != null ||
	    	   fMemberAction != null || !fExceptions.isEmpty();
	}

    /**
     * @see IModel#getChildren()
     */
	public Object[] getChildren() {
	    Vector<Block> childs = new Vector<Block>();
	    if (fDocComment != null) {
	        childs.add(fDocComment);
	    }
	    if (fOptions != null) {
	        childs.add(fOptions);
	    }
	    if (fMemberAction != null) {
	        childs.add(fMemberAction);
	    }
	    childs.addAll(fExceptions);
	    return childs.toArray();
	}
	
	/**
	 * @see ISegment#getUniqueID()
	 */
	public String getUniqueID() {
		return ((ISegment)getParent()).getUniqueID() + "/Rule:" + getName();
	}

	/**
	 * @see ISegment#accept(ISegmentVisitor)
	 */
	public boolean accept(final ISegmentVisitor aVisitor) {
		boolean more = true;
		
		// At first visit all exceptions of this rule
		Enumeration<Block> exceptions = fExceptions.elements();
		while (exceptions.hasMoreElements() && more) {
			more = ((ISegment)exceptions.nextElement()).accept(aVisitor);
		}

		// Now visit this rule's doc comment, options and member action
		if (more && fDocComment != null) {
			more = aVisitor.visit(fDocComment);
		}
		if (more && fOptions != null) {
			more = aVisitor.visit(fOptions);
		}
		if (more && fMemberAction != null) {
			more = aVisitor.visit(fMemberAction);
		}

		// Finally visit this grammar
		if (more) {
			more = aVisitor.visit(this);
		}
		return more;
	}
	
	/**
	 * get the visibility of the rule
	 * @return the rule visibility
	 */
	public int getVisibility() {
	    return fVisibility;
	}
	
	/**
	 * set the rule as excluded
	 * @param anIsExcluded true to exclude the rule
	 */
	public void setIsExcluded(final boolean anIsExcluded) {
	    fIsExcluded = anIsExcluded;
	}
	
	/**
	 * is the rule excluded from view
	 * @return true if excluded
	 */
	public boolean isExcluded() {
	    return fIsExcluded;
	}

	/**
	 * set the doc comment for the rule
	 * @param aToken the doc comment
	 */
	public	void setDocComment(final Token aToken) {
	    fDocComment = new Block(this, Block.COMMENT, aToken.getLine(),
	    						aToken.getColumn());
	}

	/**
	 * get the doc comment for the rule
	 * @return the doc comment
	 */
	public Block getDocComment() {
	    return fDocComment;
	}
	
	/**
	 * set the rule options
	 * @param aToken the rule options
	 */
	public void setOptions(final Token aToken) {
	    fOptions = new Block(this, Block.OPTIONS, aToken.getLine(),
	    					 aToken.getColumn());
	}

	/**
	 * get the rule options
	 * @return the rule options
	 */
	public Block getOptions() {
	    return fOptions;
	}
	
	/**
	 * add a member action to the rule
	 * @param aToken the action
	 */
	public void setMemberAction(final Token aToken) {
	    fMemberAction = new Block(this, Block.ACTION, aToken.getLine(),
	    						  aToken.getColumn());
	}

	/**
	 * get the member action for the rule
	 * @return the action
	 */
	public Block getMemberAction() {
	    return fMemberAction;
	}

	/**
	 * Add an exception to the rule
	 * @param aToken the exception spec
	 */
	public void addException(final Token aToken) {
		fExceptions.add(new Block(this, Block.EXCEPTION, aToken.getLine(),
								  getEndLine()));
	}

	/** {@inheritDoc} */
	@Override
	public String toString() {
	    return getUniqueID() + " [" + getStartLine() + ":" +
	    		getEndLine() + "]";
	}
}
