/**
 * <small>
 * <p><i>Copyright (C) 2005 Torsten Juergeleit, 
 * All rights reserved. </i></p>
 * 
 * <p>USE OF THIS CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS
 * AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE
 * OF THE CONTENT IS GOVERNED BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS
 * OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED
 * BELOW. IF YOU DO NOT AGREE TO THE TERMS AND CONDITIONS OF THIS AGREEMENT AND
 * THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW, THEN YOU MAY NOT USE THE CONTENT.</p>
 * 
 * <p>This Content is Copyright (C) 2005 Torsten Juergeleit, 
 * and is provided to you under the terms and conditions of the Common Public 
 * License Version 1.0 ("CPL"). A copy of the CPL is provided with this Content 
 * and is also available at 
 *     <a href="http://www.eclipse.org/legal/cpl-v10.html">
 *         http://www.eclipse.org/legal/cpl-v10.html </a>.
 * 
 * For purposes of the CPL, "Program" will mean the Content.</p>
 * 
 * <p>Content includes, but is not limited to, source code, object code,
 * documentation and any other files in this distribution.</p>
 * 
 * </small>
 */
package org.antlr.eclipse.core.builder;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Hashtable;

/**
 * Logs output content written by a thread to specified listener.
 *
 * @author Torsten Juergeleit
 */
public class MonitoredOutputStream extends OutputStream {
    private IStreamListener fListener;

    private static final int MAX_SIZE = 1024;
    private Hashtable<Thread, ByteArrayOutputStream> fBuffers = new Hashtable<Thread, ByteArrayOutputStream>();
    private boolean fSkip = false;

    /**
     * Creates a new instance of this class.
     * @param aListener The listener
     */
    public MonitoredOutputStream(final IStreamListener aListener) {
        fListener = aListener;
    }
    
    /**
     * Write the data to the buffer and flush the buffer, if a line separator
     * is detected.
     *
     * @param aByte  data to log
     * @see OutputStream#write(int)
     */
    @Override
    public void write(final int aByte) throws IOException {
        final byte c = (byte)aByte;
        if (c == '\n' || c == '\r') {
            if (!fSkip) {
                processBuffer();
            }
        } else {
            ByteArrayOutputStream buffer = getBuffer();
            buffer.write(aByte);
            if (buffer.size() > MAX_SIZE) {
                processBuffer();
            }
        }
        fSkip = (c == '\r');
    }

    /**
     * Writes all remaining data from buffer.
     * @see OutputStream#flush()
     */
    @Override
    public void flush() throws IOException {
        if (getBuffer().size() > 0) {
            processBuffer();
        }
    }

    /**
     * Writes all remaining data from buffer.
     * @see OutputStream#close()
     */
    @Override
    public void close() throws IOException {
        flush();
    }

    /**
     * Converts the buffer to a string and sends it to listener.
     * @see IStreamListener#streamAppended(String, Object)
     */
    protected void processBuffer() {
        fListener.streamAppended(getBuffer().toString(), this);
        fBuffers.remove(Thread.currentThread());
    }

    private ByteArrayOutputStream getBuffer() {
        Thread current = Thread.currentThread();
        ByteArrayOutputStream buffer = fBuffers.get(current);
        if (buffer == null) {
            buffer = new ByteArrayOutputStream();
            fBuffers.put(current, buffer);
        }
        return buffer;
    }
}
