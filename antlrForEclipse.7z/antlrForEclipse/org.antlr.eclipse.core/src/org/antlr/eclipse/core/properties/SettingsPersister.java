/**
 * <small>
 * <p><i>Copyright (C) 2005 Torsten Juergeleit, 
 * All rights reserved. </i></p>
 * 
 * <p>USE OF THIS CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS
 * AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE
 * OF THE CONTENT IS GOVERNED BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS
 * OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED
 * BELOW. IF YOU DO NOT AGREE TO THE TERMS AND CONDITIONS OF THIS AGREEMENT AND
 * THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW, THEN YOU MAY NOT USE THE CONTENT.</p>
 * 
 * <p>This Content is Copyright (C) 2005 Torsten Juergeleit, 
 * and is provided to you under the terms and conditions of the Common Public 
 * License Version 1.0 ("CPL"). A copy of the CPL is provided with this Content 
 * and is also available at 
 *     <a href="http://www.eclipse.org/legal/cpl-v10.html">
 *         http://www.eclipse.org/legal/cpl-v10.html </a>.
 * 
 * For purposes of the CPL, "Program" will mean the Content.</p>
 * 
 * <p>Content includes, but is not limited to, source code, object code,
 * documentation and any other files in this distribution.</p>
 * 
 * </small>
 */
package org.antlr.eclipse.core.properties;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Iterator;
import java.util.TreeSet;

import org.antlr.eclipse.core.AntlrCorePlugin;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;

import com.javadude.antxr.scanner.BasicCrimsonXMLTokenStream;

/**
 * Utility class to manager persistence of an antlr properties file
 */
public class SettingsPersister {
	private static HashMap<String, String> DEFAULTS;
	
	/** Name of the property specifying normal output turned on */
	public static final String PLUGIN_VERSION_PROPERTY = "pluginVersion";

	/** Name of the property specifying normal output turned on */
	public static final String NORMAL_PROPERTY = "normalOuput";
	
	/** Name of the property specifying if the -html option is turned on */
	public static final String HTML_PROPERTY = "htmlOutput";
	
	/** Name of the property specifying if the -docbook option is turned on */
	public static final String DOCBOOK_PROPERTY = "docbookOutput";
	
	/** Name of the property specifying if the -diagnostic option is turned on */
	public static final String DIAGNOSTIC_PROPERTY = "diagnosticOutput";
	
	/** Name of the property specifying no trace options are turned on */
	public static final String NOTRACE_PROPERTY = "noTrace";
	
	/** Name of the property specifying if the -trace option is turned on */
	public static final String TRACE_PROPERTY = "trace";
	
	/** Name of the property specifying if the -traceParser option is turned on */
	public static final String TRACE_PARSER_PROPERTY = "traceParser";
	
	/** Name of the property specifying if the -traceLexer option is turned on */
	public static final String TRACE_LEXER_PROPERTY = "traceLexer";
	
	/** Name of the property specifying if the -traceTreeParser option is turned on */
	public static final String TRACE_TREE_PARSER_PROPERTY = "traceTreeParser";
	
	/** Name of the property specifying if the -smap option is turned on */
	public static final String SMAP_PROPERTY = "installSmap";
	
	/** Name of the property holding the ANTLR grammar a file is generated
	 * from */
	public static final String GRAMMAR_PROPERTY = "grammar";
	
	/** Name of the property holding the debug option for generated files */
	public static final String DEBUG_PROPERTY = "debug";
	
	/** Name of the property holding the clean warnings option for generated files */
	public static final String CLEAN_WARNINGS = "cleanWarnings";
	
	/** Name of the property holding the output path for generated files */
	public static final String OUTPUT_PROPERTY = "output";
	
	/** Name of the property holding a list of paths to super grammar files
	 * (delimited by ';') */
	public static final String SUPER_GRAMMARS_PROPERTY = "superGrammars";
	
	/** Name of the property holding a list of paths to import vocabulary files
	 * (delimited by ';') */
	public static final String IMPORT_VOCABULARIES_PROPERTY = "importVocabularies";

	private static HashMap<String, String> projectDefaults() {
		if (DEFAULTS == null) {
			HashMap<String, String> defaults = new HashMap<String, String>();
			
			defaults.put(CLEAN_WARNINGS, "false");
			defaults.put(SMAP_PROPERTY, "true");
			defaults.put(DEBUG_PROPERTY, "false");
			
			defaults.put(NORMAL_PROPERTY, "true");
			defaults.put(HTML_PROPERTY, "false");
			defaults.put(DOCBOOK_PROPERTY, "false");
			defaults.put(DIAGNOSTIC_PROPERTY, "false");
			
			defaults.put(NOTRACE_PROPERTY, "true");
			defaults.put(TRACE_PROPERTY, "false");
			defaults.put(TRACE_PARSER_PROPERTY, "false");
			defaults.put(TRACE_LEXER_PROPERTY, "false");
			defaults.put(TRACE_TREE_PARSER_PROPERTY, "false");
			
			DEFAULTS = defaults;
		}
		return DEFAULTS;
	}
	/**
	 * Read the .antlr-eclipse file to retrieve grammar settings
	 * @param project The project containing the grammars
	 * @return A Map of grammar options
	 */
	public static HashMap<String,HashMap<String,String>> readSettings(final IProject project) {
		BufferedReader in = null;
		try {
			IFile file = project.getFile(".antlr-eclipse");
			IPath location = file.getLocation();
			File antlrSettingsFile = location.toFile();
			in = new BufferedReader(new FileReader(antlrSettingsFile));
			BasicCrimsonXMLTokenStream scanner = 
				new BasicCrimsonXMLTokenStream(in, AntlrSettingsParser.class, false, false);
			AntlrSettingsParser parser = new AntlrSettingsParser(scanner);
			try {
				return parser.settings();
			}
			catch (Exception e) {
				throw new RuntimeException(e);
			}
		}
		catch (FileNotFoundException e) {
			// ignore! don't report as error
			return new HashMap<String,HashMap<String,String>>();
		}
		finally {
			if (in != null) {
				try {
					in.close();
				}
				catch (IOException e) {
					// ignore - don't log
					return new HashMap<String,HashMap<String,String>>();
				}
			}
		}
	}
	
	/**
	 * Write all grammar options for a project to an .antlr-eclipse file
	 * @param project The project containing the grammars
	 * @param settings The grammar settings
	 */
	public static void writeSettings(final IProject project, final HashMap<String,HashMap<String,String>> settings) {
		PrintWriter out = null;
		try {
			try {
				set(settings, PLUGIN_VERSION_PROPERTY, AntlrCorePlugin.VERSION);
				IFile file = project.getFile(".antlr-eclipse");
				IPath location = file.getLocation();
				File antlrSettingsFile = location.toFile();
	
				out = new PrintWriter(new FileWriter(antlrSettingsFile));
				out.println("<?xml version='1.0' ?> ");
				out.println("<settings>");
				TreeSet<String> keysOrdered = new TreeSet<String>(settings.keySet());
				for (Iterator<String> i = keysOrdered.iterator(); i.hasNext();) {
					String resourceName = (String)i.next();
					out.println("  <resource name='" + resourceName + "'>");
					HashMap<String,String> properties = settings.get(resourceName);
					TreeSet<String> propertiesOrdered = new TreeSet<String>(properties.keySet());
					for (Iterator<String> j = propertiesOrdered.iterator(); j.hasNext();) {
						String propertyName = (String)j.next();
						String propertyValue = (String)properties.get(propertyName);
						out.println("    <property name='" + propertyName + "' value='" + propertyValue + "' />");
					}
					out.println("  </resource>");
				}
				out.println("</settings>");
			}
			finally {
				if (out != null)
					out.close();
			}
			project.refreshLocal(1, null);
		}
		catch (IOException e) {
			AntlrCorePlugin.log(e);
		} catch (CoreException e) {
			AntlrCorePlugin.log(e);
		}
	}
	
	/**
	 * Set a grammar option
	 * @param projectSettings The settings map
	 * @param resource The grammar
	 * @param property The property name to set
	 * @param value The value of the property
	 */
	public static void set(final HashMap<String,HashMap<String,String>> projectSettings, final IResource resource, final String property, final String value) {
		String resourceName = resource.getProjectRelativePath().toString();
		HashMap<String,String> resourceSettings = projectSettings.get(resourceName);
		if (resourceSettings == null) {
			resourceSettings = new HashMap<String,String>();
			projectSettings.put(resourceName, resourceSettings);
		}
		resourceSettings.put(property, value);
	}

	/**
	 * Set a plugin option
	 * @param projectSettings The settings map
	 * @param property The property name to set
	 * @param value The value of the property
	 */
	public static void set(final HashMap<String,HashMap<String,String>> projectSettings, final String property, String value) {
		HashMap<String,String> resourceSettings = projectSettings.get(AntlrCorePlugin.PLUGIN_RESOURCE_NAME);
		if (resourceSettings == null) {
			resourceSettings = new HashMap<String,String>();
			projectSettings.put(AntlrCorePlugin.PLUGIN_RESOURCE_NAME, resourceSettings);
		}
		resourceSettings.put(property, value);
	}
	
	/**
	 * Get a plugin option
	 * @param projectSettings The settings map
	 * @param property The property name to set
	 * @return The value of the property
	 */
	public static String get(final HashMap<String,HashMap<String,String>> projectSettings, final String property) {
		HashMap<String,String> resourceSettings = projectSettings.get(AntlrCorePlugin.PLUGIN_RESOURCE_NAME);
		if (resourceSettings == null)
			return null;
		
		return (String)resourceSettings.get(property);
	}
	/**
	 * Get a grammar option
	 * @param projectSettings The settings map
	 * @param resource The grammar
	 * @param property The property name to set
	 * @return The value of the property
	 */
	public static String get(final HashMap<String,HashMap<String,String>> projectSettings, final IResource resource, final String property) {
		String resourceName = resource.getProjectRelativePath().toString();
		HashMap<String,String> resourceSettings = projectSettings.get(resourceName);
		if (resourceSettings == null) {
			resourceSettings = projectDefaults();
		}
		
		return (String)resourceSettings.get(property);
	}
}
