By default, ANTLR comes with antlr.jar, a full distribution of the ANTLR
tool and runtime libraries, with debugging symbols.

If you want to build a lighter-weight jar, you can do so by running the ant
build. See ANT-README.txt for details.