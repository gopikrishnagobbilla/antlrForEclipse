namespace antlr.debug
{
	using System;
	
	/// <summary> This type was created in VisualAge.
	/// </summary>
	public interface DebuggingParser
	{
		string getRuleName(int n);
		string getSemPredName(int n);
	}
}