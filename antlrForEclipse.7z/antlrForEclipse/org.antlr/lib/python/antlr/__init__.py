#
# ANTLR Translator Generator
# Project led by Terence Parr at http://www.jGuru.com
# Software rights: http://www.antlr.org/license.html
#
# $Id: __init__.py,v 1.1 2005/02/15 22:27:42 cvs Exp $
#

from antlr import *
