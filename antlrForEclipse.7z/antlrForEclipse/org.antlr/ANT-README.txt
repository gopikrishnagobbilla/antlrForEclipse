To build ANTLR using ANT:

cd ant-build
ant

Note that this will overwrite the antlr.jar, which is used during the antlr
build process. (This allows easy bootstrapping.)

"ant clean" will remove all generated code *except* antlr.jar.

If you will be doing extensive work on the antlr code, you may end up 
with an unusable antlr.jar. I recommend that you make a copy of antlr.jar
whenever it seems to be working (including before you start making changes
to the ANTLR code.)

Questions? Comments? Bugs? Email scott@javadude.com