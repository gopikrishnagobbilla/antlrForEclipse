/**
 * <small>
 * <p><i>Copyright (C) 2005 Torsten Juergeleit, 
 * All rights reserved. </i></p>
 * 
 * <p>USE OF THIS CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS
 * AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE
 * OF THE CONTENT IS GOVERNED BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS
 * OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED
 * BELOW. IF YOU DO NOT AGREE TO THE TERMS AND CONDITIONS OF THIS AGREEMENT AND
 * THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW, THEN YOU MAY NOT USE THE CONTENT.</p>
 * 
 * <p>This Content is Copyright (C) 2005 Torsten Juergeleit, 
 * and is provided to you under the terms and conditions of the Common Public 
 * License Version 1.0 ("CPL"). A copy of the CPL is provided with this Content 
 * and is also available at 
 *     <a href="http://www.eclipse.org/legal/cpl-v10.html">
 *         http://www.eclipse.org/legal/cpl-v10.html </a>.
 * 
 * For purposes of the CPL, "Program" will mean the Content.</p>
 * 
 * <p>Content includes, but is not limited to, source code, object code,
 * documentation and any other files in this distribution.</p>
 * 
 * </small>
 */
package org.antlr.eclipse.ui.editor.text;

import org.antlr.eclipse.ui.AntlrUIPlugin;
import org.eclipse.jface.text.BadLocationException;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.ITextDoubleClickStrategy;
import org.eclipse.jface.text.ITextViewer;

/**
 * Double click strategy aware of ANTLR identifier syntax rules.
 */
public class DoubleClickStrategy implements ITextDoubleClickStrategy {

	protected ITextViewer fText;
	protected int fPos;
	protected int fStartPos;
	protected int fEndPos;

	protected static final char[] BRACKETS = { '{', '}', '(', ')', '[', ']',
	    										  '"', '"' };
	
	/** {@inheritDoc} */
	public void doubleClicked(final ITextViewer aText) {

		fPos = aText.getSelectedRange().x;

		if (fPos >= 0) {
			fText = aText;

			if (!selectBracketBlock()) {
				selectWord();
			}
		}
	}
	
	/**
	 * Select the area between the selected bracket and the closing bracket.
	 * @return true if successful
	 */
	 protected boolean selectBracketBlock() {
		if (matchBracketsAt()) {

			if (fStartPos == fEndPos)
				fText.setSelectedRange(fStartPos, 0);
			else
				fText.setSelectedRange(fStartPos + 1, fEndPos - fStartPos - 1);

			return true;
		}
		return false;
	}
	
	/**
	 * Select the word at the current selection. 
	 */
	 protected void selectWord() {
		if (matchWord()) {

			if (fStartPos == fEndPos)
				fText.setSelectedRange(fStartPos, 0);
			else
				fText.setSelectedRange(fStartPos + 1, fEndPos - fStartPos - 1);
		}
	}
	
	/**
	 * Match the brackets at the current selection.
	 * @return true if successful, false otherwise. 
	 */
	 protected boolean matchBracketsAt() {

		char prevChar, nextChar;

		int i;
		int bracketIndex1 = BRACKETS.length;
		int bracketIndex2 = BRACKETS.length;

		fStartPos = -1;
		fEndPos = -1;

		// get the chars preceding and following the start position
		try {
			IDocument doc = fText.getDocument();

			prevChar = doc.getChar(fPos - 1);
			nextChar = doc.getChar(fPos);

			// is the char either an open or close bracket?
			for (i = 0; i < BRACKETS.length; i += 2) {
				if (prevChar == BRACKETS[i]) {
					fStartPos = fPos - 1;
					bracketIndex1 = i;
				}
			}
			for (i = 1; i < BRACKETS.length; i += + 2) {
				if (nextChar == BRACKETS[i]) {
					fEndPos = fPos;
					bracketIndex2 = i;
				}
			}

			if (fStartPos > -1 && bracketIndex1 < bracketIndex2) {
				fEndPos = searchForClosingBracket(fStartPos, prevChar,
												  BRACKETS[bracketIndex1 + 1], doc);
				if (fEndPos > -1)
					return true;
				else
					fStartPos= -1;
			} else if (fEndPos > -1) {
				fStartPos= searchForOpenBracket(fEndPos, BRACKETS[bracketIndex2 - 1],
												nextChar, doc);
				if (fStartPos > -1)
					return true;
				else
					fEndPos= -1;
			}

		} catch (BadLocationException e) {
			AntlrUIPlugin.log(e);
		}
		return false;
	}
	
	/**
	 * Select the word at the current selection. 
	 * @return true if successful, false otherwise.
	 */
	 protected boolean matchWord() {

		IDocument doc= fText.getDocument();

		try {

			int pos = fPos;
			char c;

			while (pos >= 0) {
				c = doc.getChar(pos);
				if (!isWordPart(c))
					break;
				--pos;
			}

			fStartPos = pos;

			pos = fPos;
			int length = doc.getLength();

			while (pos < length) {
				c = doc.getChar(pos);
				if (!isWordPart(c))
					break;
				++pos;
			}

			fEndPos= pos;

			return true;
		} catch (BadLocationException e) {
			AntlrUIPlugin.log(e);
		}
		return false;
	}
	
	protected boolean isWordPart(final char aChar) {
		return Character.isLetterOrDigit(aChar) || aChar == '_';
	}

	
	/**
	 * Returns the position of the closing bracket after startPosition.
	 *
	 * @param aStartPosition  the beginning position
	 * @param anOpenBracket  the character that represents the open bracket
	 * @param aCloseBracket  the character that represents the close bracket
	 * @param aDocument  the document being searched
	 * @return the location of the closing bracket.
	 * @throws BadLocationException if the document position is invalid
	 */
	 protected int searchForClosingBracket(final int aStartPosition, final char anOpenBracket,
			 final char aCloseBracket, final IDocument aDocument) throws BadLocationException {
		int stack = 1;
		int closePosition = aStartPosition + 1;
		int length = aDocument.getLength();
		char nextChar;

		while (closePosition < length && stack > 0) {
			nextChar= aDocument.getChar(closePosition);
			if (nextChar == anOpenBracket && nextChar != aCloseBracket)
				stack++;
			else if (nextChar == aCloseBracket)
				stack--;
			closePosition++;
		}

		if (stack == 0)
			return closePosition - 1;
		else
			return -1;

	}
	
	/**
	 * Returns the position of the open bracket before startPosition.
	 *
	 * @param startPosition - the beginning position
	 * @param openBracket - the character that represents the open bracket
	 * @param closeBracket - the character that represents the close bracket
	 * @param document - the document being searched
	 * @return the location of the starting bracket.
	 * @throws BadLocationException if the document position is invalid
	 */
	protected int searchForOpenBracket(final int startPosition,
			final char openBracket, final char closeBracket,
			final IDocument document) throws BadLocationException {
		int stack = 1;
		int openPos = startPosition - 1;
		char nextChar;

		while (openPos >= 0 && stack > 0) {
			nextChar= document.getChar(openPos);
			if (nextChar == closeBracket && nextChar != openBracket)
				stack++;
			else if (nextChar == openBracket)
				stack--;
			openPos--;
		}

		if (stack == 0)
			return openPos + 1;
		else
			return -1;
	}
}