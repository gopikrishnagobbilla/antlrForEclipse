/**
 * <small>
 * <p><i>Copyright (C) 2005 Torsten Juergeleit, 
 * All rights reserved. </i></p>
 * 
 * <p>USE OF THIS CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS
 * AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE
 * OF THE CONTENT IS GOVERNED BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS
 * OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED
 * BELOW. IF YOU DO NOT AGREE TO THE TERMS AND CONDITIONS OF THIS AGREEMENT AND
 * THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW, THEN YOU MAY NOT USE THE CONTENT.</p>
 * 
 * <p>This Content is Copyright (C) 2005 Torsten Juergeleit, 
 * and is provided to you under the terms and conditions of the Common Public 
 * License Version 1.0 ("CPL"). A copy of the CPL is provided with this Content 
 * and is also available at 
 *     <a href="http://www.eclipse.org/legal/cpl-v10.html">
 *         http://www.eclipse.org/legal/cpl-v10.html </a>.
 * 
 * For purposes of the CPL, "Program" will mean the Content.</p>
 * 
 * <p>Content includes, but is not limited to, source code, object code,
 * documentation and any other files in this distribution.</p>
 * 
 * </small>
 */
package org.antlr.eclipse.ui.editor.outline;

import org.antlr.eclipse.core.parser.Block;
import org.antlr.eclipse.core.parser.Grammar;
import org.eclipse.jface.viewers.ContentViewer;
import org.eclipse.jface.viewers.ILabelProvider;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.jface.viewers.ViewerSorter;

/**
 * Sorts entries in the outline view
 */
public class AntlrOutlineSorter extends ViewerSorter {

	/** block in the outline */
    public static final int BLOCK = 0;
	/** grammar in the outline */
    public static final int GRAMMAR = 1;
	/** rule in the outline */
    public static final int RULE = 2;

	/** {@inheritDoc} */
	public int category(final Object anElement) {
	    int category;
	    if (anElement instanceof Block) {
	        category = BLOCK;
	    } else if (anElement instanceof Grammar) {
	        category = GRAMMAR;
	    } else {
	        category = RULE;
	    }
	    return category;
	}
    
	/** {@inheritDoc} */
 	public int compare(final Viewer aViewer, final Object anObject1, final Object anObject2) {
 	    int compare;
		int cat1 = category(anObject1);
		int cat2 = category(anObject2);
		if (cat1 != cat2 || cat1 == BLOCK) {
		    compare = 0;
		} else {
			ILabelProvider lprov = (ILabelProvider)
								  ((ContentViewer)aViewer).getLabelProvider();
			compare = collator.compare(lprov.getText(anObject1),
									   lprov.getText(anObject2));
		}
		return compare;
	}
}
