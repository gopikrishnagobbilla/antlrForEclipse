/**
 * <small>
 * <p><i>Copyright (C) 2005 Torsten Juergeleit, 
 * All rights reserved. </i></p>
 * 
 * <p>USE OF THIS CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS
 * AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE
 * OF THE CONTENT IS GOVERNED BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS
 * OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED
 * BELOW. IF YOU DO NOT AGREE TO THE TERMS AND CONDITIONS OF THIS AGREEMENT AND
 * THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW, THEN YOU MAY NOT USE THE CONTENT.</p>
 * 
 * <p>This Content is Copyright (C) 2005 Torsten Juergeleit, 
 * and is provided to you under the terms and conditions of the Common Public 
 * License Version 1.0 ("CPL"). A copy of the CPL is provided with this Content 
 * and is also available at 
 *     <a href="http://www.eclipse.org/legal/cpl-v10.html">
 *         http://www.eclipse.org/legal/cpl-v10.html </a>.
 * 
 * For purposes of the CPL, "Program" will mean the Content.</p>
 * 
 * <p>Content includes, but is not limited to, source code, object code,
 * documentation and any other files in this distribution.</p>
 * 
 * </small>
 */
package org.antlr.eclipse.ui.editor;

import java.io.Reader;

import org.antlr.eclipse.core.parser.AntlrOverviewParser;
import org.antlr.eclipse.ui.editor.text.PartitionScanner;
import org.eclipse.jface.resource.JFaceResources;
import org.eclipse.jface.text.Document;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.IDocumentPartitioner;
import org.eclipse.jface.text.rules.DefaultPartitioner;
import org.eclipse.jface.text.source.SourceViewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;

/**
 * Read-only text editor displaying ANTLR grammar overview (only terminals and
 * non-terminals; no actions, comments and type information).
 */
public class AntlrOverview extends SourceViewer {

	public AntlrOverview(final Composite aParent) {
		super(aParent, null, SWT.V_SCROLL | SWT.H_SCROLL);

		EditorEnvironment.connect();

		// Configure source viewer
		configure(new AntlrConfiguration(null));
		getTextWidget().setEditable(false);
		getTextWidget().setFont(JFaceResources.getFontRegistry().get(
													JFaceResources.TEXT_FONT));
		// Create document with attached partitioner 
		IDocument document = new Document();
		IDocumentPartitioner partitioner = new DefaultPartitioner(
					 new PartitionScanner(), PartitionScanner.PARTITION_TYPES);
		partitioner.connect(document);
		document.setDocumentPartitioner(partitioner);

		// Attach document to source viewer AFTER configuring source viewer
		// Otherwise syntax highlighting will not work 
		setDocument(document);
	}

	/* (non-Javadoc)
	 * @see org.eclipse.jface.text.TextViewer#handleDispose()
	 */
	protected void handleDispose() {
		EditorEnvironment.disconnect();
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.ISaveablePart#isSaveOnCloseNeeded()
	 */
	public boolean isSaveOnCloseNeeded() {
		return false;
	}

	/**
	 * Parses given reader for an ANTLR grammar overview and sets this source
	 * viewer's document to the parsed text.
	 */
	public void show(final Reader aReader) {
		getDocument().set(new AntlrOverviewParser().parse(aReader)); 
	}
}
