/**
 * <small>
 * <p><i>Copyright (C) 2005 Torsten Juergeleit, 
 * All rights reserved. </i></p>
 * 
 * <p>USE OF THIS CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS
 * AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE
 * OF THE CONTENT IS GOVERNED BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS
 * OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED
 * BELOW. IF YOU DO NOT AGREE TO THE TERMS AND CONDITIONS OF THIS AGREEMENT AND
 * THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW, THEN YOU MAY NOT USE THE CONTENT.</p>
 * 
 * <p>This Content is Copyright (C) 2005 Torsten Juergeleit, 
 * and is provided to you under the terms and conditions of the Common Public 
 * License Version 1.0 ("CPL"). A copy of the CPL is provided with this Content 
 * and is also available at 
 *     <a href="http://www.eclipse.org/legal/cpl-v10.html">
 *         http://www.eclipse.org/legal/cpl-v10.html </a>.
 * 
 * For purposes of the CPL, "Program" will mean the Content.</p>
 * 
 * <p>Content includes, but is not limited to, source code, object code,
 * documentation and any other files in this distribution.</p>
 * 
 * </small>
 */
package org.antlr.eclipse.ui.editor;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;

import org.antlr.eclipse.core.parser.AntlrLexer;
import org.antlr.eclipse.core.parser.AntlrParser;
import org.antlr.eclipse.core.parser.Hierarchy;
import org.antlr.eclipse.core.parser.ISegment;
import org.antlr.eclipse.ui.AntlrUIPlugin;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.IRegion;
import org.eclipse.jface.text.reconciler.DirtyRegion;
import org.eclipse.jface.text.reconciler.IReconcilingStrategy;
import org.eclipse.swt.widgets.Display;

import antlr.DefaultFileLineFormatter;
import antlr.FileLineFormatter;

/**
 * Reconciler strategy which parses the whole editor's content (a ANTLR
 * grammar) on a document change.
 */
public class AntlrReconcilingStrategy implements IReconcilingStrategy {
	private AntlrEditor fEditor;
    private Hierarchy fHierarchy;
	private String fError;

	public AntlrReconcilingStrategy(final AntlrEditor anEditor) {
		fEditor = anEditor;
		fHierarchy = new Hierarchy("<empty>");
	}

	public void setDocument(final IDocument aDocument) {
		parse();
	}

	public void reconcile(final DirtyRegion aDirtyRegion, final IRegion aRegion) {
		parse();
	}

	public void reconcile(final IRegion aPartition) {
		parse();
	}

	private void parse() {
		FileLineFormatter.setFormatter(new DefaultFileLineFormatter());
		Reader reader = new StringReader(fEditor.getDocument().get());
		AntlrParser parser = new AntlrParser(new AntlrLexer(reader));
    	Hierarchy hierarchy = null;
        try {
			hierarchy = parser.grammarFile(null);

			// If exception occured then display error message
			Exception e = hierarchy.getException();
			if (e != null) {
				fError = e.toString();
			} else {
				fError = "";
			}
		} catch (Exception e) {
			fError = "";
			AntlrUIPlugin.log(e);
        } finally {
        	try {
				reader.close();        
        	} catch (IOException e) {
        		AntlrUIPlugin.log(e);
        	}
        }

		// Replace saved hierarchy with the new parse tree
		synchronized (this) {
        	if (hierarchy != null) {
				fHierarchy = hierarchy;
        	} else {
        		fHierarchy = new Hierarchy("<empty>");
        	}
		}

		// Update outline view and display error message in status line
		Display.getDefault().syncExec(new Runnable() {
			public void run(){	
				fEditor.updateOutlinePage();
				fEditor.displayErrorMessage(fError);
			}
		});
	}

	/**
	 * Returns root elements of current parse tree.
	 */    
    public Object[] getRootElements() {
        return fHierarchy.getChildren();
    }

	/**
	 * Returns root node of current parse tree.
	 */    
    public ISegment getRootSegment() {
        return fHierarchy;
    }
}
