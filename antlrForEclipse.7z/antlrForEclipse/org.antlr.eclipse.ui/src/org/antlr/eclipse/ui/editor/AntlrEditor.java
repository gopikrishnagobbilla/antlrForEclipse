/**
 * <small>
 * <p><i>Copyright (C) 2005 Torsten Juergeleit, 
 * All rights reserved. </i></p>
 * 
 * <p>USE OF THIS CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS
 * AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE
 * OF THE CONTENT IS GOVERNED BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS
 * OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED
 * BELOW. IF YOU DO NOT AGREE TO THE TERMS AND CONDITIONS OF THIS AGREEMENT AND
 * THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW, THEN YOU MAY NOT USE THE CONTENT.</p>
 * 
 * <p>This Content is Copyright (C) 2005 Torsten Juergeleit, 
 * and is provided to you under the terms and conditions of the Common Public 
 * License Version 1.0 ("CPL"). A copy of the CPL is provided with this Content 
 * and is also available at 
 *     <a href="http://www.eclipse.org/legal/cpl-v10.html">
 *         http://www.eclipse.org/legal/cpl-v10.html </a>.
 * 
 * For purposes of the CPL, "Program" will mean the Content.</p>
 * 
 * <p>Content includes, but is not limited to, source code, object code,
 * documentation and any other files in this distribution.</p>
 * 
 * </small>
 */
package org.antlr.eclipse.ui.editor;

import java.util.Iterator;

import org.antlr.eclipse.core.parser.ISegment;
import org.antlr.eclipse.ui.AntlrUIPlugin;
import org.antlr.eclipse.ui.actions.GotoRuleAction;
import org.antlr.eclipse.ui.actions.IAntlrActionConstants;
import org.antlr.eclipse.ui.actions.IAntlrActionDefinitionIds;
import org.antlr.eclipse.ui.editor.outline.AntlrOutlinePage;
import org.eclipse.core.resources.IMarker;
import org.eclipse.jdt.ui.actions.IJavaEditorActionDefinitionIds;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.IStatusLineManager;
import org.eclipse.jface.text.BadLocationException;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.IRegion;
import org.eclipse.jface.text.ITextOperationTarget;
import org.eclipse.jface.text.ITextSelection;
import org.eclipse.jface.text.Position;
import org.eclipse.jface.text.source.Annotation;
import org.eclipse.jface.text.source.IAnnotationModel;
import org.eclipse.jface.text.source.ISourceViewer;
import org.eclipse.jface.viewers.ISelectionChangedListener;
import org.eclipse.jface.viewers.ISelectionProvider;
import org.eclipse.jface.viewers.SelectionChangedEvent;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.swt.custom.StyledText;
import org.eclipse.ui.IEditorActionBarContributor;
import org.eclipse.ui.IPageLayout;
import org.eclipse.ui.IViewPart;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.editors.text.ForwardingDocumentProvider;
import org.eclipse.ui.editors.text.TextFileDocumentProvider;
import org.eclipse.ui.ide.IGotoMarker;
import org.eclipse.ui.part.EditorActionBarContributor;
import org.eclipse.ui.texteditor.AbstractDecoratedTextEditor;
import org.eclipse.ui.texteditor.ContentAssistAction;
import org.eclipse.ui.texteditor.ITextEditorActionConstants;
import org.eclipse.ui.texteditor.ITextEditorActionDefinitionIds;
import org.eclipse.ui.texteditor.MarkerAnnotation;
import org.eclipse.ui.texteditor.MarkerUtilities;
import org.eclipse.ui.texteditor.TextOperationAction;
import org.eclipse.ui.views.contentoutline.IContentOutlinePage;
import org.eclipse.ui.views.tasklist.TaskList;

/**
 * An editor for an ANTLR grammar
 */
public class AntlrEditor extends AbstractDecoratedTextEditor implements IGotoMarker {

	private static final String PREFIX = "Editor.";

	private AntlrMultiPageEditor fMultiPageEditor;
	private ModelTools fModelTools;
	private AntlrReconcilingStrategy fReconcilingStrategy;

	/** The outline page */
	private AntlrOutlinePage fOutlinePage;

	/** The status line clearer */
	private ISelectionChangedListener fStatusLineClearer;

	/** Last cursor position (line) handled in
	 * <code>handleCursorPositionChanged()</code> */
	private int fLastCursorLine;

	/**
	 * Create the editor
	 * @param aMultiPageEditor the multi-page editor we're in
	 */
	public AntlrEditor(final AntlrMultiPageEditor aMultiPageEditor) {
		fMultiPageEditor = aMultiPageEditor;
		fModelTools = new ModelTools(this);
		fReconcilingStrategy = new AntlrReconcilingStrategy(this);
		
		setEditorContextMenuId("#AntlrGrammarFilePopupContext"); //$NON-NLS-1$
		setRulerContextMenuId("#AntlrGrammarFileRulerContext"); //$NON-NLS-1$
//		setOutlinerContextMenuId("#ClassFileOutlinerContext"); //$NON-NLS-1$
		
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.editors.text.TextEditor#initializeEditor()
	 */
	protected void initializeEditor() {
		super.initializeEditor();

		EditorEnvironment.connect();

		setSourceViewerConfiguration(new AntlrConfiguration(this));
		AntlrDocumentSetupParticipant participant = new AntlrDocumentSetupParticipant();
		ForwardingDocumentProvider forwardingProvider = new ForwardingDocumentProvider(IDocument.DEFAULT_CONTENT_TYPE, participant, new TextFileDocumentProvider());
		setDocumentProvider(forwardingProvider);
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.editors.text.TextEditor#initializeKeyBindingScopes()
	 */
	protected void initializeKeyBindingScopes() {
		setKeyBindingScopes(new String[] { "org.antlr.ui.antlrEditorScope" });
	}
	
	/* (non-Javadoc)
	 * @see org.eclipse.ui.texteditor.AbstractTextEditor#createActions()
	 */
	protected void createActions() {
		super.createActions();

		// Add goto rule action
		IAction action = new GotoRuleAction(
								AntlrUIPlugin.getDefault().getResourceBundle(),
								PREFIX + "GotoRule.", this);
		action.setActionDefinitionId(IAntlrActionDefinitionIds.GOTO_RULE);
		setAction(IAntlrActionConstants.GOTO_RULE, action);

		// Add content assist propsal action
		action = new ContentAssistAction(
								AntlrUIPlugin.getDefault().getResourceBundle(),
								PREFIX + "ContentAssist.", this);
		action.setActionDefinitionId(
					  ITextEditorActionDefinitionIds.CONTENT_ASSIST_PROPOSALS);
		setAction(IAntlrActionConstants.CONTENT_ASSIST, action);

		// Add comment action
		action = new TextOperationAction(
					  AntlrUIPlugin.getDefault().getResourceBundle(),
					  PREFIX + "Comment.", this, ITextOperationTarget.PREFIX);
		action.setActionDefinitionId(IJavaEditorActionDefinitionIds.COMMENT);		
		setAction(IAntlrActionConstants.COMMENT, action);

		// Add uncomment action
		action = new TextOperationAction(
			  AntlrUIPlugin.getDefault().getResourceBundle(),
			  PREFIX + "Uncomment.", this, ITextOperationTarget.STRIP_PREFIX);
		action.setActionDefinitionId(IJavaEditorActionDefinitionIds.UNCOMMENT);		
		setAction(IAntlrActionConstants.UNCOMMENT, action);
	}
	
	/**
	 * The <code>AntlrEditor</code> implementation of this 
	 * <code>AbstractTextEditor</code> method gets the ANTLR content outline
	 * page if request is for a an outline page.
	 * @param aClass the type to adapt to
	 * @return the adapter
	 */ 
	public Object getAdapter(final Class aClass) {
	    Object adapter;
		if (aClass.equals(IContentOutlinePage.class)) {
			if (fOutlinePage == null || fOutlinePage.isDisposed()) {
			    fOutlinePage = new AntlrOutlinePage(this);
				if (getEditorInput() != null) {
					fOutlinePage.setInput(getEditorInput());
				}
			}
			adapter = fOutlinePage;
		} else {
		    adapter = super.getAdapter(aClass);
		}
		return adapter;
	}
	
	/**
	 * The <code>AntlrEditor</code> implementation of this 
	 * <code>AbstractTextEditor</code> method performs any extra 
	 * disposal actions required by the ANTLR editor.
	 *
	 * @see org.eclipse.ui.IWorkbenchPart#dispose()
	 */
	public void dispose() {
		EditorEnvironment.disconnect();
		if (fOutlinePage != null && !fOutlinePage.isDisposed()) {
			fOutlinePage.dispose();
			fOutlinePage = null;
		}
		super.dispose();
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.texteditor.AbstractTextEditor#editorContextMenuAboutToShow(org.eclipse.jface.action.IMenuManager)
	 */
	protected void editorContextMenuAboutToShow(final IMenuManager aMenu) {
		super.editorContextMenuAboutToShow(aMenu);
		addAction(aMenu, ITextEditorActionConstants.MB_ADDITIONS,
				  IAntlrActionConstants.GOTO_RULE);
		addAction(aMenu, ITextEditorActionConstants.MB_ADDITIONS,
				  IAntlrActionConstants.COMMENT);
		addAction(aMenu, ITextEditorActionConstants.MB_ADDITIONS,
				  IAntlrActionConstants.UNCOMMENT);
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.texteditor.AbstractTextEditor#handleCursorPositionChanged()
	 */
	protected void handleCursorPositionChanged() {
		super.handleCursorPositionChanged();
		int line = getCursorLine();
		if (line > 0 && line != fLastCursorLine) {
			fLastCursorLine = line;
			if (fOutlinePage != null && !fOutlinePage.isDisposed()) {
				fOutlinePage.selectSegment(line, false);
			}
		}
	}	
	
	/** {@inheritDoc} */
	public void markInNavigationHistory() {
		getEditorSite().getPage().getNavigationHistory().markLocation(
															 fMultiPageEditor);
	}

	/**
	 * Get the document we're editing
	 * @return the document
	 */
	public IDocument getDocument() {
		return getSourceViewer().getDocument();
	}

	/**
	 * Get the line containing the cursor
	 * @return the line containing the cursor
	 */
	public int getCursorLine() {
		int line = -1;

		ISourceViewer sourceViewer = getSourceViewer();
		if (sourceViewer != null) {
			StyledText styledText = sourceViewer.getTextWidget();
			int caret = widgetOffset2ModelOffset(sourceViewer,
												  styledText.getCaretOffset());
			IDocument document = sourceViewer.getDocument();
			if (document != null) {
				try {
					line = document.getLineOfOffset(caret) + 1;
				} catch (BadLocationException e) {
					AntlrUIPlugin.log(e);
				}
			}
		}
		return line;
	}

	/**
	 * Get the rules defined for this editor
	 * @param aPrefix The prefix
	 * @return the rules
	 */
	public String[] getRules(final String aPrefix) {
		return fModelTools.getRules(aPrefix);
	}

	/**
	 * Get the segment containing the line
	 * @param aLine the line
	 * @return the segment
	 */
	public ISegment getSegment(final int aLine) {
		return fModelTools.getSegment(aLine);
	}

	/**
	 * Get the named segment
	 * @param aName the name
	 * @return the segment
	 */
	public ISegment getSegment(final String aName) {
		return fModelTools.getSegment(aName);
	}

	/**
	 * Highlight the segment
	 * @param aSegment the segment
	 * @param aMoveCursor should we move the cursor?
	 */
	public void highlightSegment(final ISegment aSegment, final boolean aMoveCursor) {
	    IDocument doc = getDocument();
		try {
			int offset = doc.getLineOffset(aSegment.getStartLine() - 1);
			IRegion endLine = doc.getLineInformation(aSegment.getEndLine() - 1);
			int length = endLine.getOffset() + endLine.getLength() - offset;
			setHighlightRange(offset, length, aMoveCursor);
		} catch (BadLocationException e) {
			resetHighlightRange();
		}
		fMultiPageEditor.activateEditor();
	}

	/**
	 * Ensure the segment is visible
	 * @param aSegment the segment
	 */
	public void revealSegment(final ISegment aSegment) {
		ISourceViewer viewer = getSourceViewer();
		if (viewer != null) {
		    IDocument doc = getDocument();
			try {
				int offset = doc.getLineOffset(aSegment.getStartLine() - 1);
				IRegion endLine = doc.getLineInformation(
													aSegment.getEndLine() - 1);
				int length = endLine.getOffset() + endLine.getLength() - offset;
				
				// Reveal segment's text area in document
				StyledText widget = getSourceViewer().getTextWidget();
				widget.setRedraw(false);
				viewer.revealRange(offset, length);
				widget.setRedraw(true);
			} catch (BadLocationException e) {
				resetHighlightRange();
			}
		}
		fMultiPageEditor.activateEditor();
	}

	/**
	 * Jump to the named rule
	 * @param aName the rule
	 */
	public void gotoRule(final String aName) {
		ISegment segment = fModelTools.getSegment(aName);
		if (segment != null) {
			markInNavigationHistory();
			highlightSegment(segment, true);
			markInNavigationHistory();
		}
	}

	/**
	 * Jumps to the next or previous error according to the given direction.
	 * @param anIsForward Move forward to next error (false = previous error)
	 */
	public void gotoError(final boolean anIsForward) {
		ISelectionProvider provider = getSelectionProvider();
		
		if (fStatusLineClearer != null) {
			provider.removeSelectionChangedListener(fStatusLineClearer);
			fStatusLineClearer= null;
		}
		
		ITextSelection s = (ITextSelection)provider.getSelection();
		IMarker nextError = getNextError(s.getOffset(), anIsForward);
		
		if (nextError != null) {
			
			IGotoMarker gotoMarker = (IGotoMarker) getAdapter(IGotoMarker.class);
			if (gotoMarker != null) {
				gotoMarker.gotoMarker(nextError);
			}

			IWorkbenchPage page = getSite().getPage();
			
			IViewPart view = page.findView(IPageLayout.ID_TASK_LIST);
			if (view != null && view instanceof TaskList) {
				StructuredSelection ss = new StructuredSelection(nextError);
				((TaskList)view).setSelection(ss, true);
			}
			
			getStatusLineManager().setErrorMessage(nextError.getAttribute(
														 IMarker.MESSAGE, ""));
			fStatusLineClearer = new ISelectionChangedListener() {
				public void selectionChanged(SelectionChangedEvent event) {
					getSelectionProvider().removeSelectionChangedListener(
														   fStatusLineClearer);
					fStatusLineClearer = null;
					getStatusLineManager().setErrorMessage("");
				}
			};
			provider.addSelectionChangedListener(fStatusLineClearer);
		} else {
			getStatusLineManager().setErrorMessage("");
		}
	}

	private IMarker getNextError(final int anOffset, final boolean anIsForward) {
		
		IMarker nextError = null;
		
		IDocument document = getDocument();
		int endOfDocument = document.getLength(); 
		int distance = 0;
		
		IAnnotationModel model = getDocumentProvider().getAnnotationModel(
															 getEditorInput());
		Iterator iter = model.getAnnotationIterator();
		while (iter.hasNext()) {
			Annotation a = (Annotation)iter.next();
			if (a instanceof MarkerAnnotation) {
				IMarker marker = ((MarkerAnnotation)a).getMarker();
		
				if (MarkerUtilities.isMarkerType(marker, IMarker.PROBLEM)) {
					Position p = model.getPosition(a);
					if (!p.includes(anOffset)) {
						int currentDistance = 0;
						if (anIsForward) {
							currentDistance = p.getOffset() - anOffset;
							if (currentDistance < 0) {
								currentDistance = endOfDocument - anOffset +
												  p.getOffset();
							}
						} else {
							currentDistance = anOffset - p.getOffset();
							if (currentDistance < 0) {
								currentDistance = anOffset + endOfDocument -
												  p.getOffset();
							}
						}						
						if (nextError == null || currentDistance < distance) {
							distance = currentDistance;
							nextError = marker;
						}
					}
				}
		
			}
		}
		return nextError;
	}

	/**
	 * Get the reconciler
	 * @return the reconciler
	 */
	public AntlrReconcilingStrategy getReconcilingStrategy() {
		return fReconcilingStrategy;
	}

	/**
	 * Get the root elements
	 * @return the root elements
	 */
	public Object[] getRootElements() {
		return fReconcilingStrategy.getRootElements();
	}

	/**
	 * Get the root segment
	 * @return the root segment
	 */
	public ISegment getRootSegment() {
		return fReconcilingStrategy.getRootSegment();
	}

	/**
	 * Update the outline page
	 */
	public void updateOutlinePage() {
		if (fOutlinePage != null) {
			fOutlinePage.update();
		}
	}

	/**
	 * Move the cursor to the specified line
	 * @param aLine the target line
	 */
	public void moveCursor(final int aLine) {
		ISourceViewer sourceViewer = getSourceViewer();
		try {
			int offset = getDocument().getLineOffset(aLine - 1);
			sourceViewer.setSelectedRange(offset, 0);
			sourceViewer.revealRange(offset, 0);
		} catch (BadLocationException e) {
			AntlrUIPlugin.log(e);
		}
	}
	
	/**
	 * Returns the desktop's StatusLineManager.
	 * @return the statusline manager
	 */
	protected IStatusLineManager getStatusLineManager() {
		IStatusLineManager manager;
		IEditorActionBarContributor contributor =
					fMultiPageEditor.getEditorSite().getActionBarContributor();
		if (contributor != null &&
						  contributor instanceof EditorActionBarContributor) {
			manager = ((EditorActionBarContributor)contributor).
										getActionBars().getStatusLineManager();
		} else {
			manager = null;
		}
		return manager;
	}	

	/**
	 * Displays an error message in editor's status line.
	 * @param aMessage the message to display
	 */
	public void displayErrorMessage(final String aMessage) {
		IStatusLineManager manager = getStatusLineManager();
		if (manager != null) {
			manager.setErrorMessage(aMessage);
		}
	}	
}
