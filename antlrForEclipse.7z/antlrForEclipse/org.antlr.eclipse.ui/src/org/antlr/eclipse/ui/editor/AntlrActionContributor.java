/**
 * <small>
 * <p><i>Copyright (C) 2005 Torsten Juergeleit, 
 * All rights reserved. </i></p>
 * 
 * <p>USE OF THIS CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS
 * AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE
 * OF THE CONTENT IS GOVERNED BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS
 * OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED
 * BELOW. IF YOU DO NOT AGREE TO THE TERMS AND CONDITIONS OF THIS AGREEMENT AND
 * THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW, THEN YOU MAY NOT USE THE CONTENT.</p>
 * 
 * <p>This Content is Copyright (C) 2005 Torsten Juergeleit, 
 * and is provided to you under the terms and conditions of the Common Public 
 * License Version 1.0 ("CPL"). A copy of the CPL is provided with this Content 
 * and is also available at 
 *     <a href="http://www.eclipse.org/legal/cpl-v10.html">
 *         http://www.eclipse.org/legal/cpl-v10.html </a>.
 * 
 * For purposes of the CPL, "Program" will mean the Content.</p>
 * 
 * <p>Content includes, but is not limited to, source code, object code,
 * documentation and any other files in this distribution.</p>
 * 
 * </small>
 */
package org.antlr.eclipse.ui.editor;

import org.eclipse.jdt.ui.actions.IJavaEditorActionDefinitionIds;
import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.IStatusLineManager;
import org.eclipse.jface.action.IToolBarManager;
import org.eclipse.jface.action.Separator;
import org.eclipse.jface.action.SubMenuManager;
import org.eclipse.jface.action.SubStatusLineManager;
import org.eclipse.jface.action.SubToolBarManager;
import org.eclipse.ui.IActionBars;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.IWorkbenchActionConstants;
import org.eclipse.ui.actions.ActionFactory;
import org.eclipse.ui.ide.IDEActionFactory;
import org.eclipse.ui.texteditor.BasicTextEditorActionContributor;
import org.eclipse.ui.texteditor.ITextEditor;
import org.eclipse.ui.texteditor.ITextEditorActionConstants;
import org.eclipse.ui.texteditor.ITextEditorActionDefinitionIds;
import org.eclipse.ui.texteditor.RetargetTextEditorAction;

import org.antlr.eclipse.ui.AntlrUIPlugin;
import org.antlr.eclipse.ui.actions.GotoErrorAction;
import org.antlr.eclipse.ui.actions.IAntlrActionConstants;
import org.antlr.eclipse.ui.actions.IAntlrActionDefinitionIds;
import org.antlr.eclipse.ui.actions.TogglePresentationAction;

/**
 * Contributes interesting ANTLR actions to the desktop's edit menu and the
 * toolbar.
 */
public class AntlrActionContributor extends
										  BasicTextEditorActionContributor {
	private static final String PREFIX = "Editor.";
	
	/** The global actions to be connected with editor actions */
	private final static String[] ACTIONS = {
		ITextEditorActionConstants.UNDO, 
		ITextEditorActionConstants.REDO,
		ITextEditorActionConstants.CUT,
		ITextEditorActionConstants.COPY,
		ITextEditorActionConstants.PASTE,
		ITextEditorActionConstants.DELETE,
		ITextEditorActionConstants.SELECT_ALL,
		ITextEditorActionConstants.FIND,
		IDEActionFactory.BOOKMARK.getId(),
		IDEActionFactory.ADD_TASK.getId(),
		ITextEditorActionConstants.PRINT,
		ITextEditorActionConstants.REVERT,
	};

	private SubMenuManager fSubMenuManager;
	private SubStatusLineManager fSubStatusLineManager;
	private SubToolBarManager fSubToolbarManager;

	private TogglePresentationAction fTogglePresentation;
	private GotoErrorAction fNextError;
	private GotoErrorAction fPreviousError;
	private RetargetTextEditorAction fGotoRule;
	private RetargetTextEditorAction fContentAssist;
	private RetargetTextEditorAction fComment;
	private RetargetTextEditorAction fUncomment;

	/**
	 * Action contributor
	 */
	public AntlrActionContributor() {
		createActions();
	}

	protected void createActions() {

		// Define toolbar actions
		fTogglePresentation = new TogglePresentationAction();
		fNextError = new GotoErrorAction(true);
		fPreviousError = new GotoErrorAction(false);

		// Define text editor actions
		fGotoRule = new RetargetTextEditorAction(
								AntlrUIPlugin.getDefault().getResourceBundle(),
								PREFIX + "GotoRule.");
		fGotoRule.setActionDefinitionId(IAntlrActionDefinitionIds.GOTO_RULE);
		fContentAssist = new RetargetTextEditorAction(
								AntlrUIPlugin.getDefault().getResourceBundle(),
								PREFIX + "ContentAssist.");
		fContentAssist.setActionDefinitionId(
					  ITextEditorActionDefinitionIds.CONTENT_ASSIST_PROPOSALS);
		fComment = new RetargetTextEditorAction(
								AntlrUIPlugin.getDefault().getResourceBundle(),
								PREFIX + "Comment.");
		fComment.setActionDefinitionId(IJavaEditorActionDefinitionIds.COMMENT);
		fUncomment = new RetargetTextEditorAction(
								AntlrUIPlugin.getDefault().getResourceBundle(),
								PREFIX + "Uncomment.");
		fUncomment.setActionDefinitionId(
									 IJavaEditorActionDefinitionIds.UNCOMMENT);
	}

    /**
     * Sets the active page of the the multi-page editor to be the given editor.
     * Redirect actions to the given editor if actions are not already being sent to it.
     * <p>
     * This method is called whenever the page changes. 
     * Subclasses must implement this method to redirect actions to the given 
     * editor (if not already directed to it).
     * </p>
     *
     * @param activeEditor the new active editor, or <code>null</code> if there is no active page, or if the
     *   active page does not have a corresponding editor
     */
	public void setActivePage(final IEditorPart anEditor) {
		doSetActiveEditor(anEditor);
	}
	
	/**
	 * The method installs the global action handlers for the given text editor.
	 *
	 * @param aPart the editor
	 */
	private void doSetActiveEditor(final IEditorPart aPart) {
		IStatusLineManager manager = getActionBars().getStatusLineManager();
		manager.setMessage(null);
		manager.setErrorMessage(null);

		ITextEditor editor = null;
		if (aPart instanceof AntlrEditor) {
			editor = (AntlrEditor)aPart;
		}
		super.setActiveEditor(editor);

		// Enable/disable menus, status line and tool bars according to the
		// given editor
		fSubMenuManager.setVisible(editor != null);
		fSubMenuManager.update(false);
		fSubStatusLineManager.setVisible(editor != null);
		fSubStatusLineManager.update(false);
		fSubToolbarManager.setVisible(editor != null);
		fSubToolbarManager.update(false);

		// Set the underlying action (registered by the related editor) in
		// the action handlers
		fTogglePresentation.setEditor(editor);
		fNextError.setEditor(editor);
		fPreviousError.setEditor(editor);
		fGotoRule.setAction(getAction(editor,
									  IAntlrActionConstants.GOTO_RULE));
		fContentAssist.setAction(getAction(editor,
										IAntlrActionConstants.CONTENT_ASSIST));
		fComment.setAction(getAction(editor, IAntlrActionConstants.COMMENT));
		fUncomment.setAction(getAction(editor,
									   IAntlrActionConstants.UNCOMMENT));
		// Set global action handlers according to the given editor
		IActionBars actionBars = getActionBars();
		if (actionBars != null) {
			actionBars.clearGlobalActionHandlers();
			for (int i = 0; i < ACTIONS.length; i++) {
				actionBars.setGlobalActionHandler(ACTIONS[i],
												getAction(editor, ACTIONS[i]));
			}
			actionBars.setGlobalActionHandler(ITextEditorActionConstants.GOTO_LINE,
				getAction(editor, ITextEditorActionDefinitionIds.LINE_GOTO));
			actionBars.setGlobalActionHandler(ActionFactory.NEXT.getId(),
											  fNextError);
			actionBars.setGlobalActionHandler(ActionFactory.PREVIOUS.getId(),
											  fPreviousError);

			actionBars.setGlobalActionHandler(IJavaEditorActionDefinitionIds.COMMENT,
				getAction(editor, IAntlrActionConstants.COMMENT));
			actionBars.setGlobalActionHandler(IJavaEditorActionDefinitionIds.UNCOMMENT,
				getAction(editor, IAntlrActionConstants.UNCOMMENT));

			actionBars.setGlobalActionHandler(IAntlrActionDefinitionIds.GOTO_RULE,
				getAction(editor, IAntlrActionConstants.GOTO_RULE));

			actionBars.updateActionBars();
		}
	}

	/** {@inheritDoc} */
	public void contributeToMenu(final IMenuManager aMenuManager) {
		fSubMenuManager = new SubMenuManager(aMenuManager);

		// Add standard text editor menu contributions
		super.contributeToMenu(fSubMenuManager);

		// Add actions to desktop's edit menu
		IMenuManager menu = fSubMenuManager.findMenuUsingPath(
											 IWorkbenchActionConstants.M_EDIT);
		if (menu != null) {
			menu.add(fContentAssist);
			menu.add(fComment);
			menu.add(fUncomment);
		}

		// Add actions to desktop's navigate menu
		menu = fSubMenuManager.findMenuUsingPath(
										 IWorkbenchActionConstants.M_NAVIGATE);
		if (menu != null) {
			menu.appendToGroup(IWorkbenchActionConstants.MB_ADDITIONS,
							   fGotoRule);
		}
	}

	/** {@inheritDoc} */
	public void contributeToStatusLine(final IStatusLineManager aStatusLineManager) {
		fSubStatusLineManager = new SubStatusLineManager(aStatusLineManager);
		super.contributeToStatusLine(fSubStatusLineManager);
	}

	/** {@inheritDoc} */
	public void contributeToToolBar(final IToolBarManager aToolBarManager) {
		fSubToolbarManager = new SubToolBarManager(aToolBarManager);

		// Add standard text editor tool bar contributions
		super.contributeToToolBar(fSubToolbarManager);

		// Add our own tool bar contributions
		fSubToolbarManager.add(new Separator());
		fSubToolbarManager.add(fTogglePresentation);		
		fSubToolbarManager.add(fPreviousError);
		fSubToolbarManager.add(fNextError);
	}

	/** {@inheritDoc} */
	public void dispose() {
		doSetActiveEditor(null);
		super.dispose();
	}
	
	/* (non-Javadoc)
	 * @see org.eclipse.ui.part.EditorActionBarContributor#init(org.eclipse.ui.IActionBars)
	 */
	public void init(final IActionBars bars) {
		// TODO Auto-generated method stub
		super.init(bars);
	}
	
    /* (non-JavaDoc)
     * Method declared on EditorActionBarContributor
     * Registers the contributor with the multi-page editor for future 
     * editor action redirection when the active page is changed, and sets
     * the active page.
     */
    public void setActiveEditor(final IEditorPart part) {
        IEditorPart activeNestedEditor = null;
        if (part instanceof AntlrMultiPageEditor) {
            activeNestedEditor = ((AntlrMultiPageEditor) part).getActiveEditor();
        }
        setActivePage(activeNestedEditor);
    }
}
