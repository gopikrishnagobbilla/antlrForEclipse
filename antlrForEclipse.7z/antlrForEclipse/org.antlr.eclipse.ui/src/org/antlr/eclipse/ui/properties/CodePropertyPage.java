/**
 * <small>
 * <p><i>Copyright (C) 2005 Torsten Juergeleit, 
 * All rights reserved. </i></p>
 * 
 * <p>USE OF THIS CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS
 * AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE
 * OF THE CONTENT IS GOVERNED BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS
 * OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED
 * BELOW. IF YOU DO NOT AGREE TO THE TERMS AND CONDITIONS OF THIS AGREEMENT AND
 * THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW, THEN YOU MAY NOT USE THE CONTENT.</p>
 * 
 * <p>This Content is Copyright (C) 2005 Torsten Juergeleit, 
 * and is provided to you under the terms and conditions of the Common Public 
 * License Version 1.0 ("CPL"). A copy of the CPL is provided with this Content 
 * and is also available at 
 *     <a href="http://www.eclipse.org/legal/cpl-v10.html">
 *         http://www.eclipse.org/legal/cpl-v10.html </a>.
 * 
 * For purposes of the CPL, "Program" will mean the Content.</p>
 * 
 * <p>Content includes, but is not limited to, source code, object code,
 * documentation and any other files in this distribution.</p>
 * 
 * </small>
 */
package org.antlr.eclipse.ui.properties;

import java.util.StringTokenizer;

import org.antlr.eclipse.core.builder.AntlrBuilder;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.jface.preference.PreferencePage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.dialogs.PropertyPage;

/**
 * Properties page for Java files.
 * If the Java file is generated via ANTLR then the name of the according ANTLR
 * grammar file is displayed.
 */
public class CodePropertyPage extends PropertyPage {

	private static final String GRAMMAR_LABEL = "Grammar:";
	private static final String COMMAND_LINE_OPTIONS_LABEL = "Command-line Options:";

	/**
	 * @see PreferencePage#createContents(Composite)
	 */
	protected Control createContents(final Composite aParent) {

		// Get ANTLR grammar name from file property
		String grammar = "";
		String commandLineOptions = "";
		try {
			grammar = ((IResource)getElement()).getPersistentProperty(
											 AntlrBuilder.GRAMMAR_ECLIPSE_PROPERTY);
			commandLineOptions = ((IResource)getElement()).getPersistentProperty(
											 AntlrBuilder.COMMAND_LINE_OPTIONS_PROPERTY);
		}
		catch (CoreException e) {
			// ignore - likely just due to upgrade
		}
		
		// If ANTLR grammar property found then display it
		Composite composite;
		if (grammar != null) {
			composite = new Composite(aParent, SWT.NULL);
			GridLayout layout = new GridLayout();
			layout.numColumns = 2;
			composite.setLayout(layout);
	
			new Label(composite, SWT.NONE).setText(GRAMMAR_LABEL);
			new Text(composite, SWT.READ_ONLY).setText(grammar);
			new Label(composite, SWT.NONE).setText(COMMAND_LINE_OPTIONS_LABEL);
			StringTokenizer tokenizer = new StringTokenizer(commandLineOptions, "|");
			if (tokenizer.hasMoreTokens())
				new Text(composite, SWT.READ_ONLY).setText(tokenizer.nextToken());
			while(tokenizer.hasMoreTokens()) {
				new Label(composite, SWT.NONE); // blank
				new Text(composite, SWT.READ_ONLY).setText(tokenizer.nextToken());
			}
		} else {
			composite = aParent;
		}
		noDefaultAndApplyButton();
		return composite;
	}
}