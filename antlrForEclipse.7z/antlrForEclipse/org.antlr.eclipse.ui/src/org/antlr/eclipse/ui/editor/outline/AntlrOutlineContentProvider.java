/**
 * <small>
 * <p><i>Copyright (C) 2005 Torsten Juergeleit, 
 * All rights reserved. </i></p>
 * 
 * <p>USE OF THIS CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS
 * AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE
 * OF THE CONTENT IS GOVERNED BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS
 * OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED
 * BELOW. IF YOU DO NOT AGREE TO THE TERMS AND CONDITIONS OF THIS AGREEMENT AND
 * THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW, THEN YOU MAY NOT USE THE CONTENT.</p>
 * 
 * <p>This Content is Copyright (C) 2005 Torsten Juergeleit, 
 * and is provided to you under the terms and conditions of the Common Public 
 * License Version 1.0 ("CPL"). A copy of the CPL is provided with this Content 
 * and is also available at 
 *     <a href="http://www.eclipse.org/legal/cpl-v10.html">
 *         http://www.eclipse.org/legal/cpl-v10.html </a>.
 * 
 * For purposes of the CPL, "Program" will mean the Content.</p>
 * 
 * <p>Content includes, but is not limited to, source code, object code,
 * documentation and any other files in this distribution.</p>
 * 
 * </small>
 */
package org.antlr.eclipse.ui.editor.outline;

import org.antlr.eclipse.core.parser.IModel;
import org.antlr.eclipse.ui.editor.AntlrEditor;
import org.eclipse.jface.viewers.ITreeContentProvider;
import org.eclipse.jface.viewers.Viewer;

/**
 * Supplies a model for an outline view
 */
public class AntlrOutlineContentProvider implements ITreeContentProvider {

	private AntlrEditor fEditor;

	/**
	 * Create the model
	 * @param anEditor the target editor
	 */
	public AntlrOutlineContentProvider(final AntlrEditor anEditor) {
	    fEditor = anEditor;
	}

	/** {@inheritDoc} */
	public void inputChanged(final Viewer aViewer, final Object anOldInput,
			final Object aNewInput) {
		// nothing to do here
    }

	/** {@inheritDoc} */
	public void dispose() {
		// nothing to do here
    }
    
	/** {@inheritDoc} */
	public Object[] getElements(final Object inputElement) {
        return fEditor.getRootElements();
    }
	
	/** {@inheritDoc} */
	public Object[] getChildren(final Object anElement) {
        return (anElement instanceof IModel) ?
						((IModel)anElement).getChildren() : IModel.NO_CHILDREN;
    }

	/** {@inheritDoc} */
	public Object getParent(final Object anElement) {
		return (anElement instanceof IModel) ?
										((IModel)anElement).getParent() : null;
    }

    /** {@inheritDoc} */
    public boolean hasChildren(final Object anElement) {
        return (anElement instanceof IModel) ?
									 ((IModel)anElement).hasChildren() : false;
    }
}
