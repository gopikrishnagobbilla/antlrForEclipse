/**
 * <small>
 * <p><i>Copyright (C) 2005 Torsten Juergeleit, 
 * All rights reserved. </i></p>
 * 
 * <p>USE OF THIS CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS
 * AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE
 * OF THE CONTENT IS GOVERNED BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS
 * OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED
 * BELOW. IF YOU DO NOT AGREE TO THE TERMS AND CONDITIONS OF THIS AGREEMENT AND
 * THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW, THEN YOU MAY NOT USE THE CONTENT.</p>
 * 
 * <p>This Content is Copyright (C) 2005 Torsten Juergeleit, 
 * and is provided to you under the terms and conditions of the Common Public 
 * License Version 1.0 ("CPL"). A copy of the CPL is provided with this Content 
 * and is also available at 
 *     <a href="http://www.eclipse.org/legal/cpl-v10.html">
 *         http://www.eclipse.org/legal/cpl-v10.html </a>.
 * 
 * For purposes of the CPL, "Program" will mean the Content.</p>
 * 
 * <p>Content includes, but is not limited to, source code, object code,
 * documentation and any other files in this distribution.</p>
 * 
 * </small>
 */
package org.antlr.eclipse.ui;

import org.antlr.eclipse.core.builder.AntlrBuilder;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.jface.viewers.ILabelDecorator;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.swt.graphics.Image;

/**
 * Decorates the text for generated files
 */
public class AntlrLabelDecorator extends LabelProvider
								  implements ILabelDecorator {
	/** {@inheritDoc} */
	public void dispose()  {
		super.dispose();
	}

	/** {@inheritDoc} */
	public Image decorateImage(final Image anImage, final Object anElement)  {
		return anImage;
	}

	/** {@inheritDoc} */
	public String decorateText(String aText, final Object anElement)  {
		String grammar = getGrammarProperty(anElement);
		if (grammar != null) {
			StringBuilder buf = new StringBuilder(aText);
			buf.append("  <");
			buf.append(grammar);
			buf.append(">");
			aText = buf.toString();
		}
		return aText;
	}

	private String getGrammarProperty(final Object anElement) {
		String grammar = null;
		if (anElement instanceof IResource) {

			if (((IResource) anElement).isAccessible()
					&& !((IResource) anElement).isPhantom()) {
				try {
					grammar = ((IResource) anElement)
							.getPersistentProperty(AntlrBuilder.GRAMMAR_ECLIPSE_PROPERTY);
				} catch (CoreException e) {
					AntlrUIPlugin.log(e);
				}
			} else {
				grammar = "(resource not found)";
			}
		}
		return grammar;
	}
}
