/**
 * <small>
 * <p><i>Copyright (C) 2005 Torsten Juergeleit, 
 * All rights reserved. </i></p>
 * 
 * <p>USE OF THIS CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS
 * AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE
 * OF THE CONTENT IS GOVERNED BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS
 * OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED
 * BELOW. IF YOU DO NOT AGREE TO THE TERMS AND CONDITIONS OF THIS AGREEMENT AND
 * THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW, THEN YOU MAY NOT USE THE CONTENT.</p>
 * 
 * <p>This Content is Copyright (C) 2005 Torsten Juergeleit, 
 * and is provided to you under the terms and conditions of the Common Public 
 * License Version 1.0 ("CPL"). A copy of the CPL is provided with this Content 
 * and is also available at 
 *     <a href="http://www.eclipse.org/legal/cpl-v10.html">
 *         http://www.eclipse.org/legal/cpl-v10.html </a>.
 * 
 * For purposes of the CPL, "Program" will mean the Content.</p>
 * 
 * <p>Content includes, but is not limited to, source code, object code,
 * documentation and any other files in this distribution.</p>
 * 
 * </small>
 */
package org.antlr.eclipse.ui.preferences;

import org.antlr.eclipse.ui.AntlrUIPlugin;
import org.antlr.eclipse.ui.IPreferencesConstants;
import org.eclipse.jface.preference.ColorFieldEditor;
import org.eclipse.jface.preference.FieldEditorPreferencePage;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPreferencePage;

/**
 * Color settings for editor syntax highliting.
 */
public class EditorPreferencePage extends FieldEditorPreferencePage
										 implements IWorkbenchPreferencePage {
	private final String PREFIX = "Preferences.Editor.";

	/**
	 * Create the pref page
	 */
	public EditorPreferencePage() {
		super(FieldEditorPreferencePage.GRID);
		setPreferenceStore(AntlrUIPlugin.getDefault().getPreferenceStore());
        setDescription(AntlrUIPlugin.getMessage(PREFIX + "description"));
	}

	/* (non-Javadoc)
	 * @see org.eclipse.jface.preference.FieldEditorPreferencePage#createFieldEditors()
	 */
	protected void createFieldEditors() {
		addField(new ColorFieldEditor(IPreferencesConstants.COLOR_DEFAULT,
								  AntlrUIPlugin.getMessage(PREFIX + "default"),
								  getFieldEditorParent()));
		addField(new ColorFieldEditor(IPreferencesConstants.COLOR_KEYWORD,
								  AntlrUIPlugin.getMessage(PREFIX + "keyword"),
								  getFieldEditorParent()));
		addField(new ColorFieldEditor(IPreferencesConstants.COLOR_STRING,
								   AntlrUIPlugin.getMessage(PREFIX + "string"),
								   getFieldEditorParent()));
		addField(new ColorFieldEditor(IPreferencesConstants.COLOR_COMMENT,
								  AntlrUIPlugin.getMessage(PREFIX + "comment"),
								  getFieldEditorParent()));
		addField(new ColorFieldEditor(IPreferencesConstants.COLOR_DOC_COMMENT,
							  AntlrUIPlugin.getMessage(PREFIX + "doc_comment"),
							  getFieldEditorParent()));
    }

	/** {@inheritDoc} */
	public void init(final IWorkbench aWorkbench) {
		// nothing to do here
	}

	/** {@inheritDoc} */
	public boolean performOk() {
        boolean value = super.performOk();
        AntlrUIPlugin.getDefault().savePluginPreferences();
        return value;
    }
}
