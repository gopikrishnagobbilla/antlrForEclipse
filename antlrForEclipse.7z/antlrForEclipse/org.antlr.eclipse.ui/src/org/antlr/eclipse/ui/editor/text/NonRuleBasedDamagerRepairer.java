/**
 * <small>
 * <p><i>Copyright (C) 2005 Torsten Juergeleit, 
 * All rights reserved. </i></p>
 * 
 * <p>USE OF THIS CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS
 * AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE
 * OF THE CONTENT IS GOVERNED BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS
 * OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED
 * BELOW. IF YOU DO NOT AGREE TO THE TERMS AND CONDITIONS OF THIS AGREEMENT AND
 * THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW, THEN YOU MAY NOT USE THE CONTENT.</p>
 * 
 * <p>This Content is Copyright (C) 2005 Torsten Juergeleit, 
 * and is provided to you under the terms and conditions of the Common Public 
 * License Version 1.0 ("CPL"). A copy of the CPL is provided with this Content 
 * and is also available at 
 *     <a href="http://www.eclipse.org/legal/cpl-v10.html">
 *         http://www.eclipse.org/legal/cpl-v10.html </a>.
 * 
 * For purposes of the CPL, "Program" will mean the Content.</p>
 * 
 * <p>Content includes, but is not limited to, source code, object code,
 * documentation and any other files in this distribution.</p>
 * 
 * </small>
 */
package org.antlr.eclipse.ui.editor.text;

import org.antlr.eclipse.ui.AntlrUIPlugin;
import org.eclipse.jface.text.BadLocationException;
import org.eclipse.jface.text.DocumentEvent;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.IRegion;
import org.eclipse.jface.text.ITypedRegion;
import org.eclipse.jface.text.Region;
import org.eclipse.jface.text.TextAttribute;
import org.eclipse.jface.text.TextPresentation;
import org.eclipse.jface.text.presentation.IPresentationDamager;
import org.eclipse.jface.text.presentation.IPresentationRepairer;
import org.eclipse.jface.util.Assert;
import org.eclipse.swt.custom.StyleRange;

/**
 * Damage repairer
 */
public class NonRuleBasedDamagerRepairer implements IPresentationDamager,
													   IPresentationRepairer {
	/** The document this object works on */
	protected IDocument fDocument;

	/** The default text attribute if non is returned as data by the current token */
	protected TextAttribute fDefaultTextAttribute;

	/**
	 * Constructor for NonRuleBasedDamagerRepairer.
	 * @param aDefaultTextAttribute text attribute
	 */
	public NonRuleBasedDamagerRepairer(final TextAttribute aDefaultTextAttribute) {
		Assert.isNotNull(aDefaultTextAttribute);

		fDefaultTextAttribute = aDefaultTextAttribute;
	}

	/**
	 * @see IPresentationRepairer#setDocument(IDocument)
	 */
	public void setDocument(final IDocument aDocument) {
		fDocument = aDocument;
	}

	/**
	 * Returns the end offset of the line that contains the specified offset or
	 * if the offset is inside a line delimiter, the end offset of the next line.
	 *
	 * @param anOffset the offset whose line end offset must be computed
	 * @return the line end offset for the given offset
	 * @exception BadLocationException if offset is invalid in the current document
	 */
	protected int endOfLineOf(final int anOffset) throws BadLocationException {

		IRegion info = fDocument.getLineInformationOfOffset(anOffset);
		if (anOffset <= info.getOffset() + info.getLength())
			return info.getOffset() + info.getLength();

		int line = fDocument.getLineOfOffset(anOffset);
		try {
			info = fDocument.getLineInformation(line + 1);
			return info.getOffset() + info.getLength();
		} catch (BadLocationException x) {
			return fDocument.getLength();
		}
	}

	/**
	 * @see IPresentationDamager#getDamageRegion(ITypedRegion, DocumentEvent, boolean)
	 */
	public IRegion getDamageRegion(final ITypedRegion aPartition,
			final DocumentEvent anEvent, final boolean aDocumentPartitioningChanged) {
		if (!aDocumentPartitioningChanged) {
			try {

				IRegion info = fDocument.getLineInformationOfOffset(
														  anEvent.getOffset());
				int start = Math.max(aPartition.getOffset(), info.getOffset());

				int end = anEvent.getOffset() + (anEvent.getText() == null
												 ? anEvent.getLength()
												 : anEvent.getText().length());
				if (info.getOffset() <= end && end <= (info.getOffset() +
								 						   info.getLength())) {
					// optimize the case of the same line
					end = info.getOffset() + info.getLength();
				} else {
					end = endOfLineOf(end);
				}
				end = Math.min(aPartition.getOffset() + aPartition.getLength(),
								end);
				return new Region(start, end - start);
			} catch (BadLocationException x) {
				AntlrUIPlugin.log(x);
			}
		}
		return aPartition;
	}

	/**
	 * @see IPresentationRepairer#createPresentation(TextPresentation, ITypedRegion)
	 */
	public void createPresentation(final TextPresentation aPresentation,
			final ITypedRegion aRegion) {
		addRange(aPresentation, aRegion.getOffset(), aRegion.getLength(),
				 fDefaultTextAttribute);
	}

	/**
	 * Adds style information to the given text presentation.
	 *
	 * @param aPresentation the text presentation to be extended
	 * @param anOffset the offset of the range to be styled
	 * @param aLength the length of the range to be styled
	 * @param anAttr the attribute describing the style of the range to be styled
	 */
	protected void addRange(final TextPresentation aPresentation, final int anOffset,
			final int aLength, final TextAttribute anAttr) {
		if (anAttr != null)
			aPresentation.addStyleRange(new StyleRange(anOffset, aLength,
													   anAttr.getForeground(),
													   anAttr.getBackground(),
													   anAttr.getStyle()));
	}
}
