/**
 * <small>
 * <p><i>Copyright (C) 2005 Torsten Juergeleit, 
 * All rights reserved. </i></p>
 * 
 * <p>USE OF THIS CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS
 * AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE
 * OF THE CONTENT IS GOVERNED BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS
 * OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED
 * BELOW. IF YOU DO NOT AGREE TO THE TERMS AND CONDITIONS OF THIS AGREEMENT AND
 * THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW, THEN YOU MAY NOT USE THE CONTENT.</p>
 * 
 * <p>This Content is Copyright (C) 2005 Torsten Juergeleit, 
 * and is provided to you under the terms and conditions of the Common Public 
 * License Version 1.0 ("CPL"). A copy of the CPL is provided with this Content 
 * and is also available at 
 *     <a href="http://www.eclipse.org/legal/cpl-v10.html">
 *         http://www.eclipse.org/legal/cpl-v10.html </a>.
 * 
 * For purposes of the CPL, "Program" will mean the Content.</p>
 * 
 * <p>Content includes, but is not limited to, source code, object code,
 * documentation and any other files in this distribution.</p>
 * 
 * </small>
 */
package org.antlr.eclipse.ui;

/**
 * Defines constants which are used to refer to values in the plugin's
 * preference bundle.
 */
public interface IPreferencesConstants {
	/** ui plugin id */
	String PREFIX = AntlrUIPlugin.PLUGIN_ID + ".";

	/** show segments action */
	String EDITOR_SHOW_SEGMENTS = PREFIX + "editor.showSegments";
	/** sort outline action */
	String EDITOR_OUTLINE_SORT = PREFIX + "editor.outline.sort";

	/** color prefix */
	String PREFIX_COLOR = PREFIX + "color.";

	/** color for basic grammar text */
	String COLOR_DEFAULT = PREFIX_COLOR + IColorConstants.DEFAULT;
	/** color for grammar keyword text */
	String COLOR_KEYWORD = PREFIX_COLOR + IColorConstants.KEYWORD;
	/** color for grammar string text */
	String COLOR_STRING = PREFIX_COLOR + IColorConstants.STRING;
	/** color for grammar comment text */
	String COLOR_COMMENT = PREFIX_COLOR + IColorConstants.COMMENT;
	/** color for grammar doc comment text */
	String COLOR_DOC_COMMENT = PREFIX_COLOR + IColorConstants.DOC_COMMENT;
}