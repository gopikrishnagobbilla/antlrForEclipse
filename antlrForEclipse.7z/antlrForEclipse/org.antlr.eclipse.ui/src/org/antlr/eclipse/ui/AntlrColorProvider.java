/**
 * <small>
 * <p><i>Copyright (C) 2005 Torsten Juergeleit, 
 * All rights reserved. </i></p>
 * 
 * <p>USE OF THIS CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS
 * AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE
 * OF THE CONTENT IS GOVERNED BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS
 * OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED
 * BELOW. IF YOU DO NOT AGREE TO THE TERMS AND CONDITIONS OF THIS AGREEMENT AND
 * THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW, THEN YOU MAY NOT USE THE CONTENT.</p>
 * 
 * <p>This Content is Copyright (C) 2005 Torsten Juergeleit, 
 * and is provided to you under the terms and conditions of the Common Public 
 * License Version 1.0 ("CPL"). A copy of the CPL is provided with this Content 
 * and is also available at 
 *     <a href="http://www.eclipse.org/legal/cpl-v10.html">
 *         http://www.eclipse.org/legal/cpl-v10.html </a>.
 * 
 * For purposes of the CPL, "Program" will mean the Content.</p>
 * 
 * <p>Content includes, but is not limited to, source code, object code,
 * documentation and any other files in this distribution.</p>
 * 
 * </small>
 */
package org.antlr.eclipse.ui;

import java.util.HashMap;
import java.util.Iterator;

import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.jface.preference.PreferenceConverter;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.RGB;
import org.eclipse.swt.widgets.Display;

/**
 * Color provider to syntax highlight ANTLR grammars
 */
public class AntlrColorProvider implements IColorConstants {

	// Default colors
	private static final RGB RGB_DEFAULT = new RGB(0, 0, 0);
	private static final RGB RGB_KEYWORD = new RGB(127, 0, 85);
	private static final RGB RGB_STRING = new RGB(42, 0, 255);
	private static final RGB RGB_COMMENT = new RGB(63, 127, 95);
	private static final RGB RGB_DOC_COMMENT = new RGB(63, 95, 191);

	protected HashMap<String, Color> fColorTable = new HashMap<String, Color>(10);

	/**
	 * Set default colors in given preference store.
	 * @param aStore the pref store
	 */
	public static void initializeDefaults(final IPreferenceStore aStore) {
		PreferenceConverter.setDefault(aStore,
							 IPreferencesConstants.COLOR_DEFAULT, RGB_DEFAULT);
		PreferenceConverter.setDefault(aStore,
							 IPreferencesConstants.COLOR_KEYWORD, RGB_KEYWORD);
		PreferenceConverter.setDefault(aStore,
							   IPreferencesConstants.COLOR_STRING, RGB_STRING);
		PreferenceConverter.setDefault(aStore,
							 IPreferencesConstants.COLOR_COMMENT, RGB_COMMENT);
		PreferenceConverter.setDefault(aStore,
					 IPreferencesConstants.COLOR_DOC_COMMENT, RGB_DOC_COMMENT);
	}

	/**
	 * Returns specified color that is stored in the color table. If color not
	 * found in color table then a new instance is created from according
	 * preferences value and stored in color table.
	 * @param aName the name of the color
	 * @return the color instance
	 */
	public Color getColor(final String aName) {
		Color color = fColorTable.get(aName);
		if (color == null) {
			IPreferenceStore store =
							   AntlrUIPlugin.getDefault().getPreferenceStore();
			RGB rgb = PreferenceConverter.getColor(store,
								   IPreferencesConstants.PREFIX_COLOR + aName);
			if (rgb != null) {
				color = new Color(Display.getCurrent(), rgb);
			} else {
				color = Display.getCurrent().getSystemColor(
													SWT.COLOR_LIST_FOREGROUND);
				AntlrUIPlugin.logErrorMessage("Undefined color '" +
											  aName + "'");
			}
			fColorTable.put(aName, color);
		}
		return color;
	}

	/**
	 * Release all of the color resources held onto by the color provider.
	 */
	public void dispose() {
		Iterator<Color> colors = fColorTable.values().iterator();
		while (colors.hasNext()) {
			 colors.next().dispose();
		}
	}
}
