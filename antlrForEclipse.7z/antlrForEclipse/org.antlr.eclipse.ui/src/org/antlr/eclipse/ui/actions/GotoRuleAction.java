/**
 * <small>
 * <p><i>Copyright (C) 2005 Torsten Juergeleit, 
 * All rights reserved. </i></p>
 * 
 * <p>USE OF THIS CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS
 * AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE
 * OF THE CONTENT IS GOVERNED BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS
 * OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED
 * BELOW. IF YOU DO NOT AGREE TO THE TERMS AND CONDITIONS OF THIS AGREEMENT AND
 * THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW, THEN YOU MAY NOT USE THE CONTENT.</p>
 * 
 * <p>This Content is Copyright (C) 2005 Torsten Juergeleit, 
 * and is provided to you under the terms and conditions of the Common Public 
 * License Version 1.0 ("CPL"). A copy of the CPL is provided with this Content 
 * and is also available at 
 *     <a href="http://www.eclipse.org/legal/cpl-v10.html">
 *         http://www.eclipse.org/legal/cpl-v10.html </a>.
 * 
 * For purposes of the CPL, "Program" will mean the Content.</p>
 * 
 * <p>Content includes, but is not limited to, source code, object code,
 * documentation and any other files in this distribution.</p>
 * 
 * </small>
 */
package org.antlr.eclipse.ui.actions;

import java.util.ResourceBundle;

import org.antlr.eclipse.ui.AntlrUIPlugin;
import org.antlr.eclipse.ui.editor.AntlrEditor;
import org.eclipse.jface.text.BadLocationException;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.ITextSelection;
import org.eclipse.jface.text.TextSelection;
import org.eclipse.ui.texteditor.ITextEditor;
import org.eclipse.ui.texteditor.TextEditorAction;

/**
 * An action that moves the editor position to a rule
 */
public class GotoRuleAction extends TextEditorAction {

	/**
	 * Create the action
	 * @param aBundle messages
	 * @param aPrefix prefix
	 * @param anEditor edior
	 */
	public GotoRuleAction(final ResourceBundle aBundle, final String aPrefix,
			final ITextEditor anEditor) {
		super(aBundle, aPrefix, anEditor);
	}
	
	/** {@inheritDoc} */
	public void run() {
		AntlrEditor editor = (AntlrEditor)getTextEditor();
		ITextSelection selection = (ITextSelection)
								  editor.getSelectionProvider().getSelection();
		if (!selection.isEmpty() && selection instanceof TextSelection) {
			IDocument doc = editor.getDocument();
			int offset = selection.getOffset();
			int length = selection.getLength();
			try {
				if (length != 0) {
					
					// Use selected text as rule name
					if (length < 0) {
						length = -length;
						offset -= length;
					}
					editor.gotoRule(doc.get(offset, length));
				} else {
					
					// Use Java identifier under cursor as rule name
					int start = offset;
					while (start > 0) {
						if (Character.isJavaIdentifierPart(doc.getChar(start -
																	   1))) {
							start--;
						} else {
							break;
						}
					}
					length = offset - start;
					int max = doc.getLength();
					while (offset < max) {
						if (Character.isJavaIdentifierPart(doc.getChar(offset))) {
							offset++;
							length++;
						} else {
							break;
						}
					}
					if (length > 0) {
						editor.gotoRule(doc.get(start, length));
					}
				}
			} catch (BadLocationException e) {
				AntlrUIPlugin.log(e);
			}
		}
	}
}