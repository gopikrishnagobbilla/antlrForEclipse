/**
 * <small>
 * <p><i>Copyright (C) 2005 Torsten Juergeleit, 
 * All rights reserved. </i></p>
 * 
 * <p>USE OF THIS CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS
 * AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE
 * OF THE CONTENT IS GOVERNED BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS
 * OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED
 * BELOW. IF YOU DO NOT AGREE TO THE TERMS AND CONDITIONS OF THIS AGREEMENT AND
 * THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW, THEN YOU MAY NOT USE THE CONTENT.</p>
 * 
 * <p>This Content is Copyright (C) 2005 Torsten Juergeleit, 
 * and is provided to you under the terms and conditions of the Common Public 
 * License Version 1.0 ("CPL"). A copy of the CPL is provided with this Content 
 * and is also available at 
 *     <a href="http://www.eclipse.org/legal/cpl-v10.html">
 *         http://www.eclipse.org/legal/cpl-v10.html </a>.
 * 
 * For purposes of the CPL, "Program" will mean the Content.</p>
 * 
 * <p>Content includes, but is not limited to, source code, object code,
 * documentation and any other files in this distribution.</p>
 * 
 * </small>
 */
package org.antlr.eclipse.ui.editor.text;

import org.eclipse.jface.text.BadLocationException;
import org.eclipse.jface.text.IDocument;

/**
 * Guesses the start/end of an ANTLR rule from a given offset.
 */
public class AntlrTextGuesser {
	private String fText;
	private int fLine;

	/**
	 * Create an empty text guesser.
	 */
	public AntlrTextGuesser() {
		fText = "";
		fLine = -1;
	}

	/**
	 * Create a guesser
	 * @param aDocument The document being edited
	 * @param anOffset The position in the document
	 * @param aGuessEnd the last position for the guess
	 */
	public AntlrTextGuesser(final IDocument aDocument, final int anOffset,
			final boolean aGuessEnd) {
		try {

		 	// Guess start position
			int start = anOffset;
			while (start >= 1 && isWordPart(aDocument.getChar(start - 1))) {
				start--;
			}

			// Guess end position
			int end = anOffset;
			if (aGuessEnd) {
				int len = aDocument.getLength() - 1;
				while (end < len && isWordPart(aDocument.getChar(end))) {
					end++;
				}
			}
			fText = aDocument.get(start, end - start);
			fLine = aDocument.getLineOfOffset(start) + 1;
		} catch (BadLocationException e) {
			fText = "";
			fLine = -1;
		}
	}

	/**
	 * Get the text
	 * @return the text
	 */
	public String getText() {
		return fText;
	}

	/**
	 * Get the line
	 * @return the line
	 */
	public int getLine() {
		return fLine;
	}

	/**
     * Determines if the specified character may be part of a ANTLR rule
     * as other than the first character. A character may be part of
     * a ANTLR rule if and only if it is one of the following:
     * <ul>
     * <li>a letter (a..z, A..Z)
     * <li>a digit (0..9)
     * <li>a hyphen ("-")
     * <li>a connecting punctuation character ("_")
     * </ul>
     * 
     * @param aChar  the character to be tested.
     * @return true if the character may be part of a ANTLR identifier; 
     *          false otherwise.
     * @see java.lang.Character#isLetterOrDigit(char)
	 */
	private static final boolean isWordPart(final char aChar) {
		return Character.isLetterOrDigit(aChar) || aChar == '-' ||
													aChar == '_';
	}

	/** {@inheritDoc} */
	public String toString() {
		return "text=" + fText + ", line=" + fLine;
	}
}
