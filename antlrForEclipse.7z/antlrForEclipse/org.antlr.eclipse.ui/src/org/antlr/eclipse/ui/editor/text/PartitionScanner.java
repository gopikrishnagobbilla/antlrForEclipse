/**
 * <small>
 * <p><i>Copyright (C) 2005 Torsten Juergeleit, 
 * All rights reserved. </i></p>
 * 
 * <p>USE OF THIS CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS
 * AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE
 * OF THE CONTENT IS GOVERNED BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS
 * OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED
 * BELOW. IF YOU DO NOT AGREE TO THE TERMS AND CONDITIONS OF THIS AGREEMENT AND
 * THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW, THEN YOU MAY NOT USE THE CONTENT.</p>
 * 
 * <p>This Content is Copyright (C) 2005 Torsten Juergeleit, 
 * and is provided to you under the terms and conditions of the Common Public 
 * License Version 1.0 ("CPL"). A copy of the CPL is provided with this Content 
 * and is also available at 
 *     <a href="http://www.eclipse.org/legal/cpl-v10.html">
 *         http://www.eclipse.org/legal/cpl-v10.html </a>.
 * 
 * For purposes of the CPL, "Program" will mean the Content.</p>
 * 
 * <p>Content includes, but is not limited to, source code, object code,
 * documentation and any other files in this distribution.</p>
 * 
 * </small>
 */
package org.antlr.eclipse.ui.editor.text;

import java.util.ArrayList;

import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.rules.EndOfLineRule;
import org.eclipse.jface.text.rules.IPredicateRule;
import org.eclipse.jface.text.rules.IToken;
import org.eclipse.jface.text.rules.MultiLineRule;
import org.eclipse.jface.text.rules.RuleBasedPartitionScanner;
import org.eclipse.jface.text.rules.SingleLineRule;
import org.eclipse.jface.text.rules.Token;
import org.eclipse.jface.text.rules.WordPatternRule;

/**
 * This scanner recognizes the ANTLR comments.
 */
public class PartitionScanner extends RuleBasedPartitionScanner {
	/** string type */
	public final static String STRING = "__antlr_string";
	/** single-line comment type */
	public final static String SINGLE_LINE_COMMENT = "__antlr_single_line_comment";
	/** multi-line comment type */
	public final static String MULTI_LINE_COMMENT = "__antlr_multi_line_comment";
	/** javadoc comment type */
	public final static String JAVA_DOC = "__java_doc";
	
	/**
	 * types of partitions in an ANTLR grammar
	 */
	public static final String[] PARTITION_TYPES = new String[] {
							IDocument.DEFAULT_CONTENT_TYPE, STRING,
							SINGLE_LINE_COMMENT, MULTI_LINE_COMMENT, JAVA_DOC };
	/**
	 * Creates the partitioner and sets up the appropriate rules.
	 */
	public PartitionScanner() {
		IToken string = new Token(STRING);
		IToken singleLineComment = new Token(SINGLE_LINE_COMMENT);
		IToken multiLineComment = new Token(MULTI_LINE_COMMENT);
		IToken javaDoc = new Token(JAVA_DOC);

		ArrayList<IPredicateRule> rules = new ArrayList<IPredicateRule>();

		// Add rule for strings and character constants.
		rules.add(new SingleLineRule("\"", "\"", string, '\\'));
		rules.add(new SingleLineRule("'", "'", string, '\\'));

		// Add special empty comment word rule
		rules.add(new WordPatternRule(new EmptyCommentDetector(), "/**/",
									  null, multiLineComment));
		// Add rules for multi-line comments
		rules.add(new MultiLineRule("/**", "*/", javaDoc));
		rules.add(new MultiLineRule("/*", "*/", multiLineComment));

		// Add special empty comment word rules
		rules.add(new WordPatternRule(new EmptyCommentDetector(), "/**/",
									  null, multiLineComment));
		rules.add(new WordPatternRule(new EmptyCommentDetector(), "/***/",
									  null, javaDoc));
		// Add rule for single line comments
		rules.add(new EndOfLineRule("//", singleLineComment));

		IPredicateRule[] result = new IPredicateRule[rules.size()];
		rules.toArray(result);
		setPredicateRules(result);
	}
}
