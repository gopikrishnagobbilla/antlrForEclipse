/**
 * <small>
 * <p><i>Copyright (C) 2005 Torsten Juergeleit, 
 * All rights reserved. </i></p>
 * 
 * <p>USE OF THIS CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS
 * AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE
 * OF THE CONTENT IS GOVERNED BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS
 * OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED
 * BELOW. IF YOU DO NOT AGREE TO THE TERMS AND CONDITIONS OF THIS AGREEMENT AND
 * THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW, THEN YOU MAY NOT USE THE CONTENT.</p>
 * 
 * <p>This Content is Copyright (C) 2005 Torsten Juergeleit, 
 * and is provided to you under the terms and conditions of the Common Public 
 * License Version 1.0 ("CPL"). A copy of the CPL is provided with this Content 
 * and is also available at 
 *     <a href="http://www.eclipse.org/legal/cpl-v10.html">
 *         http://www.eclipse.org/legal/cpl-v10.html </a>.
 * 
 * For purposes of the CPL, "Program" will mean the Content.</p>
 * 
 * <p>Content includes, but is not limited to, source code, object code,
 * documentation and any other files in this distribution.</p>
 * 
 * </small>
 */
package org.antlr.eclipse.ui.properties;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.antlr.eclipse.core.AntlrCorePlugin;
import org.antlr.eclipse.core.properties.SettingsPersister;
import org.antlr.eclipse.ui.AntlrUIPlugin;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.jface.viewers.ViewerFilter;
import org.eclipse.jface.window.Window;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.dialogs.ElementTreeSelectionDialog;
import org.eclipse.ui.dialogs.ISelectionStatusValidator;
import org.eclipse.ui.dialogs.PropertyPage;
import org.eclipse.ui.model.WorkbenchContentProvider;
import org.eclipse.ui.model.WorkbenchLabelProvider;

/**
 * Properties page for ANTLR grammar files.
 * It appends the name of the according grammar file to the file name.
 */
public class GrammarPropertyPage extends PropertyPage {
	// TODO cleanup the layout of this pref page!
	// TODO figure out how to force a rebuild when the user changes options!
	// TODO store prefs in an xml file called .antlr so they can be shared

	private static final String PREFIX = "Properties.Grammar.";
	private HashMap<String,HashMap<String,String>> map;
	private Text fOutputText;
	private Text fGrammarText;
	private Text fImportText;
	private HashMap<String, Button> booleanControls = new HashMap<String, Button>();
	private HashMap<String, Boolean> booleanDefaults = new HashMap<String, Boolean>();

	/* (non-Javadoc)
	 * @see org.eclipse.jface.preference.PreferencePage#createContents(org.eclipse.swt.widgets.Composite)
	 */
	protected Control createContents(final Composite aParent) {
		Composite composite = setupGridLayout(new Composite(aParent, SWT.NONE));

		// TODO remove the following if we can force a rebuild like jdt does when java options change
		Label note = new Label(composite, SWT.NONE);
		note.setText("Note: You must recompile your grammar for these changes to take place");

		// read the settings for this grammar
		map = SettingsPersister.readSettings(((IResource)getElement()).getProject());
		AntlrCorePlugin.getDefault().upgradeOldSettings((IResource)getElement(), map);
		
		addOutputProperty(composite);
		addGrammarProperty(composite);
		addImportVocabProperty(composite);
		addBooleanProperty(SWT.CHECK, SettingsPersister.CLEAN_WARNINGS, getString("cleanWarnings.label"), composite, false);
		addBooleanProperty(SWT.CHECK, SettingsPersister.SMAP_PROPERTY, getString("smap.label"), composite, true);
		addBooleanProperty(SWT.CHECK, SettingsPersister.DEBUG_PROPERTY, getString("debug.label"), composite, false);
		
		Group outputType = (Group)setupGridLayout(new Group(composite, SWT.SHADOW_ETCHED_IN));
		outputType.setText(getString("output.types.label"));
		addBooleanProperty(SWT.RADIO, SettingsPersister.NORMAL_PROPERTY, getString("normal.label"), outputType, true);
		addBooleanProperty(SWT.RADIO, SettingsPersister.HTML_PROPERTY, getString("html.label"), outputType, false);
		addBooleanProperty(SWT.RADIO, SettingsPersister.DOCBOOK_PROPERTY, getString("docbook.label"), outputType, false);
		addBooleanProperty(SWT.RADIO, SettingsPersister.DIAGNOSTIC_PROPERTY, getString("diagnostic.label"), outputType, false);
		
		Group traceType = (Group)setupGridLayout(new Group(composite, SWT.SHADOW_ETCHED_IN));
		traceType.setText(getString("trace.types.label"));
		addBooleanProperty(SWT.RADIO, SettingsPersister.NOTRACE_PROPERTY, getString("notrace.label"), traceType, true);
		addBooleanProperty(SWT.RADIO, SettingsPersister.TRACE_PROPERTY, getString("trace.label"), traceType, false);
		addBooleanProperty(SWT.RADIO, SettingsPersister.TRACE_PARSER_PROPERTY, getString("traceParser.label"), traceType, false);
		addBooleanProperty(SWT.RADIO, SettingsPersister.TRACE_LEXER_PROPERTY, getString("traceLexer.label"), traceType, false);
		addBooleanProperty(SWT.RADIO, SettingsPersister.TRACE_TREE_PARSER_PROPERTY, getString("traceTreeParser.label"), traceType, false);
		
		return composite;
	}

	private Composite setupGridLayout(final Composite composite) {
		GridLayout layout = new GridLayout();
		composite.setLayout(layout);
		GridData data = new GridData(GridData.FILL);
		data.grabExcessHorizontalSpace = true;
		composite.setLayoutData(data);
		return composite;
	}
	private void addOutputProperty(final Composite aParent) {
		Composite composite = createDefaultComposite(aParent);

		// Label for output field
		Label label = new Label(composite, SWT.NONE);
		label.setText(getString("output.label"));
//		label.setLayoutData(new GridData(GridData.HORIZONTAL_ALIGN_FILL));

		// Output text field
		fOutputText = new Text(composite, SWT.READ_ONLY | SWT.SINGLE | SWT.BORDER);
		String output = SettingsPersister.get(map, (IResource)getElement(), SettingsPersister.OUTPUT_PROPERTY);
		if (output != null) {
			fOutputText.setText(output);
		}
		GridData gd = new GridData();
		gd.horizontalAlignment= GridData.FILL_HORIZONTAL;
		gd.widthHint = convertWidthInCharsToPixels(50);
//		gd.grabExcessHorizontalSpace = true;
		fOutputText.setLayoutData(gd);

		// Choose folder button			
		Button button = new Button(composite, SWT.PUSH);
		button.setText(getString("output.button"));
		button.addSelectionListener(new SelectionListener() {
			public void widgetDefaultSelected(SelectionEvent anEvent) {
				chooseOutputFolder();
			}
			public void widgetSelected(SelectionEvent anEvent) {
				chooseOutputFolder();
			}
		});	
	}

	private void addGrammarProperty(final Composite aParent) {
		Composite composite = createDefaultComposite(aParent);

		// Label for grammar field
		Label label = new Label(composite, SWT.NONE);
		label.setText(getString("grammar.label"));

		// Grammar text field
		fGrammarText = new Text(composite, SWT.READ_ONLY | SWT.SINGLE | SWT.BORDER);
		String grammar;
		grammar = SettingsPersister.get(map, (IResource)getElement(), SettingsPersister.SUPER_GRAMMARS_PROPERTY);
		if (grammar != null) {
			fGrammarText.setText(grammar);
		}
		GridData gd = new GridData();
		gd.horizontalAlignment= GridData.FILL_HORIZONTAL;
		gd.widthHint = convertWidthInCharsToPixels(50);
//		gd.grabExcessHorizontalSpace = true;
		fGrammarText.setLayoutData(gd);

		// Choose folder button			
		Button button = new Button(composite, SWT.PUSH);
		button.setText(getString("grammar.button"));
		button.addSelectionListener(new SelectionListener() {
			public void widgetDefaultSelected(SelectionEvent anEvent) {
				String file = chooseGrammarFile();
				fGrammarText.setText(file);
			}
			public void widgetSelected(SelectionEvent anEvent) {
				String file = chooseGrammarFile();
				fGrammarText.setText(file);
			}
		});	
	}
	
	private void addImportVocabProperty(final Composite aParent) {
		Composite composite = createDefaultComposite(aParent);

		// Label for grammar field
		Label label = new Label(composite, SWT.NONE);
		label.setText(getString("importvocabulary.label"));

		// Grammar text field
		fImportText = new Text(composite, SWT.READ_ONLY | SWT.SINGLE | SWT.BORDER);
		String grammar;
		grammar = SettingsPersister.get(map, (IResource)getElement(), SettingsPersister.IMPORT_VOCABULARIES_PROPERTY);
		if (grammar != null) {
			fImportText.setText(grammar);
		}
		GridData gd = new GridData();
		gd.horizontalAlignment= GridData.FILL_HORIZONTAL;
		gd.widthHint = convertWidthInCharsToPixels(50);
//		gd.grabExcessHorizontalSpace = true;
		fImportText.setLayoutData(gd);

		// Choose folder button			
		Button button = new Button(composite, SWT.PUSH);
		button.setText(getString("importvocabulary.button"));
		button.addSelectionListener(new SelectionListener() {
			public void widgetDefaultSelected(SelectionEvent anEvent) {
				String file = chooseGrammarFile();
				fImportText.setText(file);
			}
			public void widgetSelected(SelectionEvent anEvent) {
				String file = chooseGrammarFile();
				fImportText.setText(file);
			}
		});	
	}

	private void addBooleanProperty(final int type, final String propertyName, final String label, final Composite aParent, final boolean defaultValue) {
		// Label for grammar field
		final Button button = new Button(aParent, type);
		booleanControls.put(propertyName, button);
		booleanDefaults.put(propertyName, Boolean.valueOf(defaultValue));
		button.setText(label);
		String value = SettingsPersister.get(map, (IResource)getElement(), propertyName);
		boolean booleanValue;
		if (value == null) {
			booleanValue = defaultValue;
			SettingsPersister.set(map, (IResource)getElement(), propertyName,defaultValue?"true":"false");
		}
		else
			booleanValue = ("true".equalsIgnoreCase(value));
		
		button.setSelection(booleanValue);
	}

	private Composite createDefaultComposite(final Composite aParent) {
		Composite composite = new Composite(aParent, SWT.NULL);
		GridLayout layout = new GridLayout();
		layout.numColumns = 3;
		composite.setLayout(layout);

		GridData data = new GridData();
		data.verticalAlignment = GridData.FILL;
		data.horizontalAlignment = GridData.FILL;
		composite.setLayoutData(data);

		return composite;
	}

	/** {@inheritDoc} */
	public boolean performOk() {
		SettingsPersister.set(map, (IResource)getElement(), SettingsPersister.OUTPUT_PROPERTY, fOutputText.getText());
		SettingsPersister.set(map, (IResource)getElement(), SettingsPersister.SUPER_GRAMMARS_PROPERTY, fGrammarText.getText());
		SettingsPersister.set(map, (IResource)getElement(), SettingsPersister.IMPORT_VOCABULARIES_PROPERTY, fImportText.getText());
			
		for (Iterator<String> i = booleanControls.keySet().iterator(); i.hasNext();) {
			String propertyName = i.next();
			Button b = booleanControls.get(propertyName);
			SettingsPersister.set(map, (IResource)getElement(), propertyName, String.valueOf(b.getSelection()));
		}

		SettingsPersister.writeSettings(((IResource)getElement()).getProject(), map);
		return true;
	}

	/* (non-Javadoc)
	 * @see org.eclipse.jface.preference.PreferencePage#performDefaults()
	 */
	protected void performDefaults() {
		fOutputText.setText("");
		fGrammarText.setText("");
		for (Iterator<String> i = booleanControls.keySet().iterator(); i.hasNext();) {
			String propertyName = i.next();
			Button b = booleanControls.get(propertyName);
			Boolean defaultValue = booleanDefaults.get(propertyName);
			b.setSelection(defaultValue.booleanValue());
		}
	}

	private String getString(String aKey) {
		return AntlrUIPlugin.getMessage(PREFIX + aKey);
	}

	private void chooseOutputFolder() {
		ISelectionStatusValidator validator = new ISelectionStatusValidator() {
			public IStatus validate(Object[] aSelection) {
				for (int i= 0; i < aSelection.length; i++) {
					if (!(aSelection[i] instanceof IFolder ||
										 aSelection[i] instanceof IProject)) {
						return new Status(IStatus.ERROR,
							   AntlrUIPlugin.getUniqueIdentifier(), IStatus.OK,
							   getString("output.choose.select"), null);
					}
				}
				return new Status(IStatus.OK,
							   AntlrUIPlugin.getUniqueIdentifier(), IStatus.OK,
							   "", null);
			}			
		};
		ElementTreeSelectionDialog dialog = new ElementTreeSelectionDialog(
									  getShell(), new WorkbenchLabelProvider(),
									  new WorkbenchContentProvider());
		dialog.setValidator(validator);
		dialog.setTitle(getString("output.choose.title"));
		dialog.setMessage(getString("output.choose.message"));
		dialog.addFilter(new FolderFilter());
		dialog.setInput(ResourcesPlugin.getWorkspace().getRoot());
		dialog.setAllowMultiple(false);	

		if (dialog.open() == Window.OK) {
			Object[] folders = dialog.getResult();
			String folder;
			if (folders.length > 0) {
				folder = ((IResource)folders[0]).getFullPath().toString();
			} else {
				folder = "";
			}
			fOutputText.setText(folder);
		}
	}
	
	private static class FolderFilter extends ViewerFilter {
		/** {@inheritDoc} */
		public boolean select(final Viewer aViewer, final Object aParent,
				final Object anElement) {
			return ((anElement instanceof IProject &&
					  ((IProject)anElement).isOpen()) ||
					 anElement instanceof IFolder);
		}		
	}

	private String chooseGrammarFile() {
		ISelectionStatusValidator validator = new ISelectionStatusValidator() {
			public IStatus validate(Object[] aSelection) {
				for (int i= 0; i < aSelection.length; i++) {
					if (!(aSelection[i] instanceof IFile)) {
						return new Status(IStatus.ERROR,
							  AntlrUIPlugin.getUniqueIdentifier(), IStatus.OK,
							  getString("grammar.choose.select"), null);
					}
				}
				return new Status(IStatus.OK,
							   AntlrUIPlugin.getUniqueIdentifier(), IStatus.OK,
							   "", null);
			}			
		};
		ElementTreeSelectionDialog dialog = new ElementTreeSelectionDialog(
									  getShell(), new WorkbenchLabelProvider(),
									  new WorkbenchContentProvider());
		dialog.setValidator(validator);
		dialog.setTitle(getString("grammar.choose.title"));
		dialog.setMessage(getString("grammar.choose.message"));
		dialog.addFilter(new GrammarFileFilter());
		dialog.setInput(ResourcesPlugin.getWorkspace().getRoot());
		dialog.setAllowMultiple(true);	

		if (dialog.open() == Window.OK) {
			Object[] files = dialog.getResult();

			// Create list of grammars delimited by ';'
			StringBuffer grammars = new StringBuffer();
			for (int i = 0; i < files.length; i++) {
				grammars.append(((IFile)files[i]).getFullPath().toString());
				if (i < (files.length - 1)) {
					grammars.append(';');
				}
			}
			return grammars.toString();
		}
		return new String();
	}
	
	private static class GrammarFileFilter extends ViewerFilter {
		/** {@inheritDoc} */
		public boolean select(final Viewer aViewer, final Object aParent,
				final Object anElement) {
			boolean select = false;
			if (anElement instanceof IProject ||
					 anElement instanceof IFolder) {
				select = true;
			} else if (anElement instanceof IFile) {
				String extension = ((IFile)anElement).getFileExtension();
				if (extension != null && extension.equals("g")) {
					select = true;
				}
			}
			return select;
		}		
	}
}