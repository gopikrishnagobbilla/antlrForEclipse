/**
 * <small>
 * <p><i>Copyright (C) 2005 Torsten Juergeleit, 
 * All rights reserved. </i></p>
 * 
 * <p>USE OF THIS CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS
 * AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE
 * OF THE CONTENT IS GOVERNED BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS
 * OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED
 * BELOW. IF YOU DO NOT AGREE TO THE TERMS AND CONDITIONS OF THIS AGREEMENT AND
 * THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW, THEN YOU MAY NOT USE THE CONTENT.</p>
 * 
 * <p>This Content is Copyright (C) 2005 Torsten Juergeleit, 
 * and is provided to you under the terms and conditions of the Common Public 
 * License Version 1.0 ("CPL"). A copy of the CPL is provided with this Content 
 * and is also available at 
 *     <a href="http://www.eclipse.org/legal/cpl-v10.html">
 *         http://www.eclipse.org/legal/cpl-v10.html </a>.
 * 
 * For purposes of the CPL, "Program" will mean the Content.</p>
 * 
 * <p>Content includes, but is not limited to, source code, object code,
 * documentation and any other files in this distribution.</p>
 * 
 * </small>
 */
package org.antlr.eclipse.ui.actions;

import org.antlr.eclipse.ui.AntlrUIPlugin;
import org.antlr.eclipse.ui.AntlrUIPluginImages;
import org.antlr.eclipse.ui.IPreferencesConstants;
import org.antlr.eclipse.ui.editor.outline.AntlrOutlineSorter;
import org.eclipse.core.runtime.Preferences;
import org.eclipse.jface.action.Action;
import org.eclipse.jface.viewers.StructuredViewer;
import org.eclipse.jface.viewers.ViewerSorter;

/**
 * Sorts the outline page
 */
public class LexicalSortingAction extends Action {

	private static final String PREFIX = "OutlinePage.Sort.";
	private static final ViewerSorter SORTER = new AntlrOutlineSorter();
	private StructuredViewer fViewer;

    /**
     * Constructor for LexicalSortingAction.
     * @param aViewer the viewer containing the outline
     */
    public LexicalSortingAction(final StructuredViewer aViewer) {
        fViewer = aViewer;
        setText(AntlrUIPlugin.getMessage(PREFIX + "label"));
        AntlrUIPluginImages.setLocalImageDescriptors(this, "alphab_sort_co.gif");
        Preferences prefs = AntlrUIPlugin.getDefault().getPluginPreferences();
        boolean checked = prefs.getBoolean(IPreferencesConstants.EDITOR_OUTLINE_SORT);
        valueChanged(checked, false);
    }

    /** {@inheritDoc} */
    public void run() {
        valueChanged(isChecked(), true);
    }

    private void valueChanged(final boolean aValue, final boolean aDoStore) {
        setChecked(aValue);
        fViewer.setSorter(aValue ? SORTER : null);
        setToolTipText(aValue ?
			AntlrUIPlugin.getMessage(PREFIX + "tooltip.checked") :
			AntlrUIPlugin.getMessage(PREFIX + "tooltip.unchecked"));
        setDescription(aValue ?
			AntlrUIPlugin.getMessage(PREFIX + "description.checked") :
			AntlrUIPlugin.getMessage(PREFIX + "description.unchecked"));
        if (aDoStore) {
	        Preferences prefs = AntlrUIPlugin.getDefault().getPluginPreferences();
	        prefs.setValue(IPreferencesConstants.EDITOR_OUTLINE_SORT, aValue);
        }
    }
}