/**
 * <small>
 * <p><i>Copyright (C) 2005 Torsten Juergeleit, 
 * All rights reserved. </i></p>
 * 
 * <p>USE OF THIS CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS
 * AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE
 * OF THE CONTENT IS GOVERNED BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS
 * OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED
 * BELOW. IF YOU DO NOT AGREE TO THE TERMS AND CONDITIONS OF THIS AGREEMENT AND
 * THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW, THEN YOU MAY NOT USE THE CONTENT.</p>
 * 
 * <p>This Content is Copyright (C) 2005 Torsten Juergeleit, 
 * and is provided to you under the terms and conditions of the Common Public 
 * License Version 1.0 ("CPL"). A copy of the CPL is provided with this Content 
 * and is also available at 
 *     <a href="http://www.eclipse.org/legal/cpl-v10.html">
 *         http://www.eclipse.org/legal/cpl-v10.html </a>.
 * 
 * For purposes of the CPL, "Program" will mean the Content.</p>
 * 
 * <p>Content includes, but is not limited to, source code, object code,
 * documentation and any other files in this distribution.</p>
 * 
 * </small>
 */
package org.antlr.eclipse.ui.editor.outline;

import org.antlr.eclipse.core.parser.ISegment;
import org.antlr.eclipse.ui.actions.CollapseAllAction;
import org.antlr.eclipse.ui.actions.LexicalSortingAction;
import org.antlr.eclipse.ui.editor.AntlrEditor;
import org.eclipse.jface.action.IToolBarManager;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.SelectionChangedEvent;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.ui.views.contentoutline.ContentOutlinePage;

/**
 * A content outline page which represents the content of an ANTLR grammar file.
 */
public class AntlrOutlinePage extends ContentOutlinePage {
	private AntlrEditor fEditor;
	private Object fInput;
	private String fSelectedSegmentID;
	private AntlrOutlineLabelProvider fLabelProvider;
	private boolean fIsDisposed;

	/**
	 * Create the outline page
	 * @param anEditor the editor
	 */
	public AntlrOutlinePage(final AntlrEditor anEditor) {
		fEditor = anEditor;
		fIsDisposed = true;
	}

	/** {@inheritDoc} */
	public void createControl(final Composite aParent) {
		super.createControl(aParent);
		
		fLabelProvider = new AntlrOutlineLabelProvider();

		// Init tree viewer
		TreeViewer viewer = getTreeViewer();
		viewer.setContentProvider(new AntlrOutlineContentProvider(fEditor));
		viewer.setLabelProvider(fLabelProvider);
		viewer.addSelectionChangedListener(this);
		if (fInput != null) {
			viewer.setInput(fInput);
		}
		fIsDisposed = false;
		
		// Add collapse all button to viewer's toolbar
		IToolBarManager mgr = getSite().getActionBars().getToolBarManager();
		mgr.add(new CollapseAllAction(viewer));
		mgr.add(new LexicalSortingAction(viewer));

		// Refresh outline according to initial cursor position
		update();
	}

	/** {@inheritDoc} */
	public void selectionChanged(final SelectionChangedEvent anEvent) {
		super.selectionChanged(anEvent);

		ISelection selection = anEvent.getSelection();
		if (!selection.isEmpty()) {
			ISegment segment = (ISegment)
						   ((IStructuredSelection)selection).getFirstElement();
			if (fSelectedSegmentID == null || isDifferentSegment(segment)) {
				fEditor.highlightSegment(segment, true);
				fSelectedSegmentID = segment.getUniqueID();
			} else {
				fEditor.revealSegment(segment);
			}
		}
	}

	/**
	 * Select part of the grammar
	 * @param aLine the line to select
	 * @param aForceSelect should we force the selection?
	 */
	public void selectSegment(final int aLine, final boolean aForceSelect) {
		if (aLine > 0) {
			TreeViewer viewer = getTreeViewer();
			ISegment segment = fEditor.getSegment(aLine);
			viewer.removeSelectionChangedListener(this);
			if (segment == null) {
				if (fSelectedSegmentID != null) {
					viewer.setSelection(new StructuredSelection());
					fEditor.resetHighlightRange();
					fSelectedSegmentID = null;
				}
			} else {
				if (aForceSelect || isDifferentSegment(segment)) {
					viewer.setSelection(new StructuredSelection(segment));
					fEditor.highlightSegment(segment, false);
					fSelectedSegmentID = segment.getUniqueID();
				}
				viewer.reveal(segment);
			}
			viewer.addSelectionChangedListener(this);
		}
	}

	private boolean isDifferentSegment(final ISegment aSegment) {
		return (fSelectedSegmentID == null ||
				 !fSelectedSegmentID.equals(aSegment.getUniqueID()));
	}

	/**
	 * @param aInput
	 */
	public void setInput(Object aInput) {
		fInput = aInput;
		update();
	}

	/**
	 * Updates the outline page.
	 */
	public void update() {
		TreeViewer viewer = getTreeViewer();
		if (viewer != null) {
			Control control = viewer.getControl();
			if (control != null && !control.isDisposed()) {
				viewer.removeSelectionChangedListener(this);
				control.setRedraw(false);
				viewer.setInput(fInput);
//				viewer.expandAll();
				control.setRedraw(true);
				selectSegment(fEditor.getCursorLine(), true);
				viewer.addSelectionChangedListener(this);
			}
		}
	}

	/** {@inheritDoc} */
	public void dispose() {
	    setInput(null);
	    if (fLabelProvider != null) {
	    	fLabelProvider.dispose();
	    	fLabelProvider = null;
	    }
	    fIsDisposed = true;
	    super.dispose();
	}

	/**
	 * Have we disposed the outline yet?
	 * @return true if disposed
	 */
	public boolean isDisposed() {
		return fIsDisposed;
	}
}
