/**
 * <small>
 * <p><i>Copyright (C) 2005 Torsten Juergeleit, 
 * All rights reserved. </i></p>
 * 
 * <p>USE OF THIS CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS
 * AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE
 * OF THE CONTENT IS GOVERNED BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS
 * OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED
 * BELOW. IF YOU DO NOT AGREE TO THE TERMS AND CONDITIONS OF THIS AGREEMENT AND
 * THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW, THEN YOU MAY NOT USE THE CONTENT.</p>
 * 
 * <p>This Content is Copyright (C) 2005 Torsten Juergeleit, 
 * and is provided to you under the terms and conditions of the Common Public 
 * License Version 1.0 ("CPL"). A copy of the CPL is provided with this Content 
 * and is also available at 
 *     <a href="http://www.eclipse.org/legal/cpl-v10.html">
 *         http://www.eclipse.org/legal/cpl-v10.html </a>.
 * 
 * For purposes of the CPL, "Program" will mean the Content.</p>
 * 
 * <p>Content includes, but is not limited to, source code, object code,
 * documentation and any other files in this distribution.</p>
 * 
 * </small>
 */
package org.antlr.eclipse.ui.actions;

import java.lang.reflect.InvocationTargetException;

import org.antlr.eclipse.core.builder.AntlrBuilder;
import org.antlr.eclipse.ui.AntlrUIPlugin;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.dialogs.ProgressMonitorDialog;
import org.eclipse.jface.util.Assert;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.IActionDelegate;
import org.eclipse.ui.IObjectActionDelegate;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.actions.WorkspaceModifyOperation;

/**
 * A popup menu action to compile a java grammar
 */
public class CompileAction implements IObjectActionDelegate {
    private IFile fGrammarFile;

    /**
     * @see IObjectActionDelegate#setActivePart(IAction, IWorkbenchPart)
     */
    public void setActivePart(final IAction anAction, final IWorkbenchPart aTargetPart) {
		// nothing to do here...
    }

    /**
     * @see IActionDelegate#selectionChanged(IAction, ISelection)
     */
    public void selectionChanged(final IAction anAction, final ISelection aSelection) {
        IFile file = null;
		if (aSelection instanceof IStructuredSelection) {
			Object obj = ((IStructuredSelection)aSelection).getFirstElement();
			if (obj != null && obj instanceof IFile) {
				file = (IFile)obj;
			}
		}
		fGrammarFile = file;
    }

    /**
     * @see IActionDelegate#run(IAction)
     */
    public void run(final IAction anAction) {
		Assert.isNotNull(fGrammarFile);
        Shell shell = AntlrUIPlugin.getActiveWorkbenchShell();
		ProgressMonitorDialog pmd = new ProgressMonitorDialog(shell);
		try {
			pmd.run(true, false, new Operation(fGrammarFile));	// cancel button disabled
		} catch (InterruptedException e) {
			AntlrUIPlugin.log(e);
		} catch (InvocationTargetException e) {
			AntlrUIPlugin.log(e);
		}
	}

    private class Operation extends WorkspaceModifyOperation {
        IFile fFile;
        
        /**
         * Create an operation, holding a file
         * @param aFile the file to hold
         */
        public Operation(final IFile aFile) {
            fFile = aFile;
        }

        /**
         * @see WorkspaceModifyOperation#execute(IProgressMonitor)
         */
        protected void execute(final IProgressMonitor aMonitor) throws CoreException,
        						 InvocationTargetException, InterruptedException {
        	new AntlrBuilder().compileFile(fFile, aMonitor);
        }
	}
}
