/**
 * <small>
 * <p><i>Copyright (C) 2005 Torsten Juergeleit, 
 * All rights reserved. </i></p>
 * 
 * <p>USE OF THIS CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS
 * AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE
 * OF THE CONTENT IS GOVERNED BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS
 * OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED
 * BELOW. IF YOU DO NOT AGREE TO THE TERMS AND CONDITIONS OF THIS AGREEMENT AND
 * THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW, THEN YOU MAY NOT USE THE CONTENT.</p>
 * 
 * <p>This Content is Copyright (C) 2005 Torsten Juergeleit, 
 * and is provided to you under the terms and conditions of the Common Public 
 * License Version 1.0 ("CPL"). A copy of the CPL is provided with this Content 
 * and is also available at 
 *     <a href="http://www.eclipse.org/legal/cpl-v10.html">
 *         http://www.eclipse.org/legal/cpl-v10.html </a>.
 * 
 * For purposes of the CPL, "Program" will mean the Content.</p>
 * 
 * <p>Content includes, but is not limited to, source code, object code,
 * documentation and any other files in this distribution.</p>
 * 
 * </small>
 */
package org.antlr.eclipse.ui.editor.text;

import java.util.ArrayList;

import org.antlr.eclipse.ui.AntlrColorProvider;
import org.antlr.eclipse.ui.IColorConstants;
import org.eclipse.jface.text.TextAttribute;
import org.eclipse.jface.text.rules.IRule;
import org.eclipse.jface.text.rules.IToken;
import org.eclipse.jface.text.rules.RuleBasedScanner;
import org.eclipse.jface.text.rules.Token;
import org.eclipse.jface.text.rules.WhitespaceRule;
import org.eclipse.jface.text.rules.WordRule;
import org.eclipse.swt.SWT;

/**
 * An ANTLR and Java aware code scanner.
 */
public class AntlrCodeScanner extends RuleBasedScanner {
	/** ANTLR keywords we care about */
	public static final String[] ANTLR_KEYWORDS = new String[] {
					   "header", "options", "tokens", "returns", "exception" };

	
	/** Java keywords we care about */
	public static final String[] JAVA_KEYWORDS = new String[] {
			"abstract", "boolean", "break", "byte", "case", "catch", "char",
			"class", "const", "continue", "default", "do", "double", "else",
			"extends", "false", "final", "finally", "float", "for", "goto",
			"if", "implements", "import", "instanceof", "int", "interface",
			"long", "native", "new", "null", "package", "private", "protected",
			"public", "return", "short", "static", "super", "switch",
			"synchronized", "this", "throw", "throws", "transient", "true",
			"try", "void", "volatile", "while" };

	/**
	 * Create an instance of a code scanner for syntax highlighting
	 * @param aColorProvider The color mapping
	 */
	public AntlrCodeScanner(final AntlrColorProvider aColorProvider) {

		IToken keyword = new Token(new TextAttribute(aColorProvider.getColor(
									IColorConstants.KEYWORD), null, SWT.BOLD));
		IToken other = new Token(new TextAttribute(aColorProvider.getColor(
													IColorConstants.DEFAULT)));
		ArrayList<IRule> rules = new ArrayList<IRule>();

		// Add generic whitespace rule
		rules.add(new WhitespaceRule(new WhitespaceDetector()));

		// Add word rule for ANTLR keywords
		WordRule wordRule = new WordRule(new WordDetector(), other);
		for (int i = 0; i < ANTLR_KEYWORDS.length; i++) {
			wordRule.addWord(ANTLR_KEYWORDS[i], keyword);
		}
		for (int i = 0; i < JAVA_KEYWORDS.length; i++) {
			wordRule.addWord(JAVA_KEYWORDS[i], keyword);
		}
		rules.add(wordRule);

		IRule[] result = new IRule[rules.size()];
		rules.toArray(result);
		setRules(result);
	}
}
