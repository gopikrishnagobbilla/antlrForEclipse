/**
 * <small>
 * <p><i>Copyright (C) 2005 Torsten Juergeleit, 
 * All rights reserved. </i></p>
 * 
 * <p>USE OF THIS CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS
 * AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE
 * OF THE CONTENT IS GOVERNED BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS
 * OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED
 * BELOW. IF YOU DO NOT AGREE TO THE TERMS AND CONDITIONS OF THIS AGREEMENT AND
 * THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW, THEN YOU MAY NOT USE THE CONTENT.</p>
 * 
 * <p>This Content is Copyright (C) 2005 Torsten Juergeleit, 
 * and is provided to you under the terms and conditions of the Common Public 
 * License Version 1.0 ("CPL"). A copy of the CPL is provided with this Content 
 * and is also available at 
 *     <a href="http://www.eclipse.org/legal/cpl-v10.html">
 *         http://www.eclipse.org/legal/cpl-v10.html </a>.
 * 
 * For purposes of the CPL, "Program" will mean the Content.</p>
 * 
 * <p>Content includes, but is not limited to, source code, object code,
 * documentation and any other files in this distribution.</p>
 * 
 * </small>
 */
package org.antlr.eclipse.ui.editor;

import java.util.ArrayList;

import org.antlr.eclipse.ui.AntlrColorProvider;
import org.antlr.eclipse.ui.IColorConstants;
import org.antlr.eclipse.ui.editor.text.AutoIndentStrategy;
import org.antlr.eclipse.ui.editor.text.DoubleClickStrategy;
import org.antlr.eclipse.ui.editor.text.NonRuleBasedDamagerRepairer;
import org.antlr.eclipse.ui.editor.text.PartitionScanner;
import org.eclipse.jdt.core.IJavaElement;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.JavaCore;
import org.eclipse.jdt.core.formatter.DefaultCodeFormatterConstants;
import org.eclipse.jdt.internal.ui.javaeditor.IClassFileEditorInput;
import org.eclipse.jdt.internal.ui.javaeditor.ICompilationUnitDocumentProvider;
import org.eclipse.jface.text.DefaultAutoIndentStrategy;
import org.eclipse.jface.text.IAutoIndentStrategy;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.ITextDoubleClickStrategy;
import org.eclipse.jface.text.ITextHover;
import org.eclipse.jface.text.TextAttribute;
import org.eclipse.jface.text.contentassist.ContentAssistant;
import org.eclipse.jface.text.contentassist.IContentAssistant;
import org.eclipse.jface.text.presentation.IPresentationReconciler;
import org.eclipse.jface.text.presentation.PresentationReconciler;
import org.eclipse.jface.text.reconciler.IReconciler;
import org.eclipse.jface.text.reconciler.MonoReconciler;
import org.eclipse.jface.text.rules.DefaultDamagerRepairer;
import org.eclipse.jface.text.source.IAnnotationHover;
import org.eclipse.jface.text.source.ISourceViewer;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.editors.text.TextSourceViewerConfiguration;
import org.eclipse.ui.texteditor.AbstractDecoratedTextEditor;
import org.eclipse.ui.texteditor.IDocumentProvider;

/**
 * Configure an editor for ANTLR grammars
 */
public class AntlrConfiguration extends TextSourceViewerConfiguration {

	private AbstractDecoratedTextEditor fEditor;

	/**
	 * Create the instance
	 * @param anEditor the target editor
	 */
	public AntlrConfiguration(final AbstractDecoratedTextEditor anEditor) {
		fEditor = anEditor;
	}

	/** {@inheritDoc} */
	public IAutoIndentStrategy getAutoIndentStrategy(final ISourceViewer aViewer,
			final String aContentType) {
		return (aContentType.equals(IDocument.DEFAULT_CONTENT_TYPE) ?
				  new AutoIndentStrategy() : new DefaultAutoIndentStrategy());
	}

	/** {@inheritDoc} */
	public ITextDoubleClickStrategy getDoubleClickStrategy(
			final ISourceViewer aViewer, final String aContentType) {
		return new DoubleClickStrategy();
	}

	/** {@inheritDoc} */
	public String[] getConfiguredContentTypes(final ISourceViewer aSourceViewer) {
		return PartitionScanner.PARTITION_TYPES;
	}

	/** {@inheritDoc} */
	public IPresentationReconciler getPresentationReconciler(
			final ISourceViewer aViewer) {
		PresentationReconciler reconciler = new PresentationReconciler();

		AntlrColorProvider cp = EditorEnvironment.getColorProvider();

		DefaultDamagerRepairer dr = new DefaultDamagerRepairer(
										   EditorEnvironment.getCodeScanner());
		reconciler.setDamager(dr, IDocument.DEFAULT_CONTENT_TYPE);
		reconciler.setRepairer(dr, IDocument.DEFAULT_CONTENT_TYPE);

		NonRuleBasedDamagerRepairer ndr = new NonRuleBasedDamagerRepairer(
					   new TextAttribute(cp.getColor(IColorConstants.STRING)));
		reconciler.setDamager(ndr, PartitionScanner.STRING);
		reconciler.setRepairer(ndr, PartitionScanner.STRING);

		ndr = new NonRuleBasedDamagerRepairer(new TextAttribute(
										cp.getColor(IColorConstants.COMMENT)));
		reconciler.setDamager(ndr, PartitionScanner.SINGLE_LINE_COMMENT);
		reconciler.setRepairer(ndr, PartitionScanner.SINGLE_LINE_COMMENT);

		ndr = new NonRuleBasedDamagerRepairer(new TextAttribute(
										cp.getColor(IColorConstants.COMMENT)));
		reconciler.setDamager(ndr, PartitionScanner.MULTI_LINE_COMMENT);
		reconciler.setRepairer(ndr, PartitionScanner.MULTI_LINE_COMMENT);

		ndr = new NonRuleBasedDamagerRepairer(new TextAttribute(
									cp.getColor(IColorConstants.DOC_COMMENT)));
		reconciler.setDamager(ndr, PartitionScanner.JAVA_DOC);
		reconciler.setRepairer(ndr, PartitionScanner.JAVA_DOC);

		return reconciler;
	}

	/** {@inheritDoc} */
	public IReconciler getReconciler(final ISourceViewer aSourceViewer) {
		IReconciler reconciler;
		if (fEditor != null && fEditor instanceof AntlrEditor) {
			reconciler = new MonoReconciler(((AntlrEditor)
									 fEditor).getReconcilingStrategy(), false);
		} else {
			reconciler = null;
		}
		return reconciler;
	}
	
	/** {@inheritDoc} */
	public IContentAssistant getContentAssistant(final ISourceViewer aSourceViewer) {
		ContentAssistant assistant;
		if (fEditor != null && fEditor instanceof AntlrEditor) {
			assistant = new ContentAssistant();
			assistant.setContentAssistProcessor(new AntlrCompletionProcessor(
					    (AntlrEditor)fEditor), IDocument.DEFAULT_CONTENT_TYPE);
			assistant.enableAutoInsert(true);
		} else {
			assistant = null;
		}
		return assistant;
	}

	/** {@inheritDoc} */
	public IAnnotationHover getAnnotationHover(final ISourceViewer aSourceViewer) {
		return new AntlrAnnotationHover();
	}
	
	/** {@inheritDoc} */
	public ITextHover getTextHover(final ISourceViewer aSourceViewer,
			final String aContentType) {
		ITextHover hover;
		if (aContentType.equals(IDocument.DEFAULT_CONTENT_TYPE) &&
						   fEditor != null && fEditor instanceof AntlrEditor) {
			hover = new AntlrTextHover((AntlrEditor)fEditor);
		} else {
			hover = null;
		}
		return hover;
	}

	/** {@inheritDoc} */
	public String[] getDefaultPrefixes(final ISourceViewer aSourceViewer,
			final String aContentType) {
		return new String[] { "//", "" };
	}

	// copied from JavaSourceViewerConfiguration and tweaked
	/** {@inheritDoc} */
	public String[] getIndentPrefixes(final ISourceViewer sourceViewer,
			final String contentType) {
		ArrayList<String> prefixes = new ArrayList<String>();
		int tabWidth=0;
		boolean useSpaces;

		IJavaProject project = getProject();
		String tabSize;
		if (project != null) {
			tabSize = project.getOption(DefaultCodeFormatterConstants.FORMATTER_TAB_SIZE, true);
			useSpaces = JavaCore.SPACE.equals(project.getOption(DefaultCodeFormatterConstants.FORMATTER_TAB_CHAR, true));
		}
		else {
			tabSize = JavaCore.getOption(DefaultCodeFormatterConstants.FORMATTER_TAB_SIZE);
			useSpaces = JavaCore.SPACE.equals(JavaCore.getOption(DefaultCodeFormatterConstants.FORMATTER_TAB_CHAR));
		}
		try {
			tabWidth = Integer.parseInt(tabSize);
		}
		catch (NumberFormatException e) {
			tabWidth = 4;
		}
		
		// prefix[0] is either '\t' or ' ' x tabWidth, depending on useSpaces
		for (int i= 0; i <= tabWidth; i++) {
		    StringBuffer prefix= new StringBuffer();

			if (useSpaces) {
			    for (int j= 0; j + i < tabWidth; j++)
			    	prefix.append(' ');
		    	
				if (i != 0)
		    		prefix.append('\t');				
			} else {    
			    for (int j= 0; j < i; j++)
			    	prefix.append(' ');
		    	
				if (i != tabWidth)
		    		prefix.append('\t');
			}
			
			prefixes.add(prefix.toString());
		}

		prefixes.add(""); //$NON-NLS-1$
		
		return (String[]) prefixes.toArray(new String[prefixes.size()]);
	}

	// copied from JavaSourceViewerConfiguration and tweaked
	private IJavaProject getProject() {
		if (fEditor == null)
			return null;
		
		IJavaElement element= null;
		IEditorInput input= fEditor.getEditorInput();
		IDocumentProvider provider= fEditor.getDocumentProvider();
		if (provider instanceof ICompilationUnitDocumentProvider) {
			ICompilationUnitDocumentProvider cudp= (ICompilationUnitDocumentProvider) provider;
			element= cudp.getWorkingCopy(input);
		} else if (input instanceof IClassFileEditorInput) {
			IClassFileEditorInput cfei= (IClassFileEditorInput) input;
			element= cfei.getClassFile();
		}
		
		if (element == null)
			return null;
		
		return element.getJavaProject();
	}
}
