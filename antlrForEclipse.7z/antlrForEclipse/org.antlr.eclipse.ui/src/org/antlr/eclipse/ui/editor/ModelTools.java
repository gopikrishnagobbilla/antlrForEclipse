/**
 * <small>
 * <p><i>Copyright (C) 2005 Torsten Juergeleit, 
 * All rights reserved. </i></p>
 * 
 * <p>USE OF THIS CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS
 * AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE
 * OF THE CONTENT IS GOVERNED BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS
 * OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED
 * BELOW. IF YOU DO NOT AGREE TO THE TERMS AND CONDITIONS OF THIS AGREEMENT AND
 * THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW, THEN YOU MAY NOT USE THE CONTENT.</p>
 * 
 * <p>This Content is Copyright (C) 2005 Torsten Juergeleit, 
 * and is provided to you under the terms and conditions of the Common Public 
 * License Version 1.0 ("CPL"). A copy of the CPL is provided with this Content 
 * and is also available at 
 *     <a href="http://www.eclipse.org/legal/cpl-v10.html">
 *         http://www.eclipse.org/legal/cpl-v10.html </a>.
 * 
 * For purposes of the CPL, "Program" will mean the Content.</p>
 * 
 * <p>Content includes, but is not limited to, source code, object code,
 * documentation and any other files in this distribution.</p>
 * 
 * </small>
 */
package org.antlr.eclipse.ui.editor;

import java.util.ArrayList;

import org.antlr.eclipse.core.parser.ISegment;
import org.antlr.eclipse.core.parser.ISegmentVisitor;
import org.antlr.eclipse.core.parser.Rule;

public class ModelTools {
	private AntlrEditor fEditor;

	public ModelTools(final AntlrEditor anEditor) {
		fEditor = anEditor;	
	}

	/**
	 * Uses visitor design pattern to find segment which contains given line.
	 * @param aLine  line to find according segment for
	 * @return segment containing given line or null if no segment found
	 */
    public ISegment getSegment(final int aLine) {
		SegmentLineVisitor visitor = new SegmentLineVisitor(aLine);
		fEditor.getReconcilingStrategy().getRootSegment().accept(visitor);
		return visitor.getSegment();
    }

	/**
	 * Uses visitor design pattern to find segment with given name.
	 * @param aName  name to find according segment for
	 * @return segment with given name or null if no segment found
	 */
    public ISegment getSegment(final String aName) {
		SegmentRuleNameVisitor visitor = new SegmentRuleNameVisitor(aName);
		fEditor.getReconcilingStrategy().getRootSegment().accept(visitor);
		return visitor.getSegment();
    }

	/**
	 * Uses visitor design pattern to find all rules with given prefix.
	 */
    public String[] getRules(String aPrefix) {
		SegmentRulesVisitor visitor = new SegmentRulesVisitor(aPrefix);
		fEditor.getReconcilingStrategy().getRootSegment().accept(visitor);
		return visitor.getRules();
    }

	private class SegmentLineVisitor implements ISegmentVisitor {
		private int fLine;
		private ISegment fSegment;

		public SegmentLineVisitor(final int aLine) {
			fLine = aLine;
			fSegment = null;
		}

		public boolean visit(final ISegment aSegment) {
			if (fLine >= aSegment.getStartLine() &&
										 	fLine <= aSegment.getEndLine()) {
				fSegment = aSegment;
				return false;
			}

			return true;
		}

		public ISegment getSegment() {
			return fSegment;
		}
	}

	private class SegmentRulesVisitor implements ISegmentVisitor {
		private String fPrefix;
		private ArrayList<String> fRules;

		public SegmentRulesVisitor(final String aPrefix) {
			fPrefix = aPrefix;
			fRules = new ArrayList<String>();
		}

		public boolean visit(final ISegment aSegment) {
			if (aSegment instanceof Rule) {
				String name = ((Rule)aSegment).getName();
				if (name.startsWith(fPrefix)) {
					fRules.add(name);
				}
			}
			return true; 
		}

		public String[] getRules() {
			return fRules.toArray(new String[fRules.size()]);
		}
	}

	private class SegmentRuleNameVisitor implements ISegmentVisitor {
		private String fName;
		private ISegment fSegment;

		public SegmentRuleNameVisitor(final String aName) {
			fName = aName;
			fSegment = null;
		}

		public boolean visit(final ISegment aSegment) {
			if (aSegment instanceof Rule &&
									((Rule)aSegment).getName().equals(fName)) {
				fSegment = aSegment;
				return false;
			}

			return true;
		}

		public ISegment getSegment() {
			return fSegment;
		}
	}
}
