/**
 * <small>
 * <p><i>Copyright (C) 2005 Torsten Juergeleit, 
 * All rights reserved. </i></p>
 * 
 * <p>USE OF THIS CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS
 * AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE
 * OF THE CONTENT IS GOVERNED BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS
 * OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED
 * BELOW. IF YOU DO NOT AGREE TO THE TERMS AND CONDITIONS OF THIS AGREEMENT AND
 * THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW, THEN YOU MAY NOT USE THE CONTENT.</p>
 * 
 * <p>This Content is Copyright (C) 2005 Torsten Juergeleit, 
 * and is provided to you under the terms and conditions of the Common Public 
 * License Version 1.0 ("CPL"). A copy of the CPL is provided with this Content 
 * and is also available at 
 *     <a href="http://www.eclipse.org/legal/cpl-v10.html">
 *         http://www.eclipse.org/legal/cpl-v10.html </a>.
 * 
 * For purposes of the CPL, "Program" will mean the Content.</p>
 * 
 * <p>Content includes, but is not limited to, source code, object code,
 * documentation and any other files in this distribution.</p>
 * 
 * </small>
 */
package org.antlr.eclipse.ui.editor;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import org.antlr.eclipse.ui.editor.text.AntlrTextGuesser;
import org.eclipse.jface.text.ITextViewer;
import org.eclipse.jface.text.contentassist.CompletionProposal;
import org.eclipse.jface.text.contentassist.ICompletionProposal;
import org.eclipse.jface.text.contentassist.IContentAssistProcessor;
import org.eclipse.jface.text.contentassist.IContextInformation;
import org.eclipse.jface.text.contentassist.IContextInformationValidator;

/**
 * Provides code completion support
 */
public class AntlrCompletionProcessor implements IContentAssistProcessor {

	private static final char[] AUTO_ACTIVATION_CHARS = new char[] {
															   '(', '|', ':' };
	private AntlrEditor fEditor;

	private static final Comparator<ICompletionProposal> PROPOSAL_COMPARATOR = new Comparator<ICompletionProposal>() {
		public int compare(ICompletionProposal aProposal1, ICompletionProposal aProposal2) {
			String text1 = ((CompletionProposal)aProposal1).getDisplayString();
			String text2 = ((CompletionProposal)aProposal2).getDisplayString();
			return text1.compareTo(text2);
		}

		public boolean equals(final Object aProposal) {
			if (this == aProposal){
				return true;
			}

			return false;
		}
	};

	/**
	 * Create the instance
	 * @param anEditor the editor we're completing for
	 */
	public AntlrCompletionProcessor(final AntlrEditor anEditor) {
		fEditor = anEditor;
	}

	/** {@inheritDoc} */
	public ICompletionProposal[] computeCompletionProposals(
			final ITextViewer aViewer, final int anOffset) {
		ArrayList<ICompletionProposal> proposals = new ArrayList<ICompletionProposal>();
		String prefix = new AntlrTextGuesser(aViewer.getDocument(), anOffset,
											 false).getText();
		String[] rules = fEditor.getRules(prefix);
		for (int i = 0; i < rules.length; i++) {
			if (rules[i].startsWith(prefix)) {
				proposals.add(new CompletionProposal(rules[i],
							  anOffset - prefix.length(), prefix.length(),
							  rules[i].length(), null, rules[i], null, null)); 
			}
		}
		Collections.sort(proposals, PROPOSAL_COMPARATOR);
		return (ICompletionProposal[])proposals.toArray(
									new ICompletionProposal[proposals.size()]);
	}

	/** {@inheritDoc} */
	public IContextInformation[] computeContextInformation(final ITextViewer viewer,
			final int documentOffset) {
		return null;
	}
	
	/** {@inheritDoc} */
	public char[] getCompletionProposalAutoActivationCharacters() {
		return AUTO_ACTIVATION_CHARS;
	}
	
	/** {@inheritDoc} */
	public char[] getContextInformationAutoActivationCharacters() {
		return null;
	}
	
	/** {@inheritDoc} */
	public IContextInformationValidator getContextInformationValidator() {
		return null;
	}
	
	/** {@inheritDoc} */
	public String getErrorMessage() {
		return null;
	}
}
