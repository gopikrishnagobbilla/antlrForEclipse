/**
 * <small>
 * <p><i>Copyright (C) 2005 Torsten Juergeleit, 
 * All rights reserved. </i></p>
 * 
 * <p>USE OF THIS CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS
 * AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE
 * OF THE CONTENT IS GOVERNED BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS
 * OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED
 * BELOW. IF YOU DO NOT AGREE TO THE TERMS AND CONDITIONS OF THIS AGREEMENT AND
 * THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW, THEN YOU MAY NOT USE THE CONTENT.</p>
 * 
 * <p>This Content is Copyright (C) 2005 Torsten Juergeleit, 
 * and is provided to you under the terms and conditions of the Common Public 
 * License Version 1.0 ("CPL"). A copy of the CPL is provided with this Content 
 * and is also available at 
 *     <a href="http://www.eclipse.org/legal/cpl-v10.html">
 *         http://www.eclipse.org/legal/cpl-v10.html </a>.
 * 
 * For purposes of the CPL, "Program" will mean the Content.</p>
 * 
 * <p>Content includes, but is not limited to, source code, object code,
 * documentation and any other files in this distribution.</p>
 * 
 * </small>
 */
package org.antlr.eclipse.ui.editor;

import java.util.Iterator;

import org.antlr.eclipse.ui.AntlrUIPlugin;
import org.eclipse.core.resources.IMarker;
import org.eclipse.jface.text.BadLocationException;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.Position;
import org.eclipse.jface.text.source.IAnnotationHover;
import org.eclipse.jface.text.source.IAnnotationModel;
import org.eclipse.jface.text.source.ISourceViewer;
import org.eclipse.ui.texteditor.MarkerAnnotation;

/**
 * Determines marker for the given line and formates the according message.
 */
public class AntlrAnnotationHover implements IAnnotationHover {

	/**
	 * @see org.eclipse.jface.text.source.IAnnotationHover#getHoverInfo(org.eclipse.jface.text.source.ISourceViewer, int)
	 */
	public String getHoverInfo(final ISourceViewer aViewer, final int aLine) {
		String info = null;
		IMarker marker = getMarkerForLine(aViewer, aLine);
		if (marker != null) {
			String message = marker.getAttribute(IMarker.MESSAGE, (String)null);
			if (message != null && message.trim().length() > 0) {
				info = message.trim();
			}
		}
		return info;
	}
	
	/**
	 * Returns one marker which includes the ruler's line of activity.
	 * @param aViewer the viewer
	 * @param aLine the current line
	 * @return the marker
	 */
	protected IMarker getMarkerForLine(final ISourceViewer aViewer, final int aLine) {
		IMarker marker = null;
		IAnnotationModel model = aViewer.getAnnotationModel();
		if (model != null) {
			Iterator e = model.getAnnotationIterator();
			while (e.hasNext()) {
				Object o = e.next();
				if (o instanceof MarkerAnnotation) {
					MarkerAnnotation a = (MarkerAnnotation)o;
					if (compareRulerLine(model.getPosition(a),
										 aViewer.getDocument(), aLine) != 0) {
						marker = a.getMarker();
					}
				}
			}
		}
		return marker;
	}

	/**
	 * Returns distance of given line to specified position (1 = same line,
	 * 2 = included in given position, 0 = not related).
	 * @param aPosition the position in the document
	 * @param aDocument the document
	 * @param aLine the line
	 * @return the distance
	 */
	protected int compareRulerLine(final Position aPosition, final IDocument aDocument,
			final int aLine) {
		int distance = 0;
		if (aPosition.getOffset() > -1 && aPosition.getLength() > -1) {
			try {
				int markerLine = aDocument.getLineOfOffset(
														aPosition.getOffset());
				if (aLine == markerLine) {
					distance = 1;
				} else if (markerLine <= aLine && aLine <=
							  aDocument.getLineOfOffset(aPosition.getOffset() +
													  aPosition.getLength())) {
					distance = 2;
				}
			} catch (BadLocationException e) {
				AntlrUIPlugin.log(e);
			}
		}
		return distance;
	}
}
