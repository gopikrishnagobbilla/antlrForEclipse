/**
 * <small>
 * <p><i>Copyright (C) 2005 Torsten Juergeleit, 
 * All rights reserved. </i></p>
 * 
 * <p>USE OF THIS CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS
 * AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE
 * OF THE CONTENT IS GOVERNED BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS
 * OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED
 * BELOW. IF YOU DO NOT AGREE TO THE TERMS AND CONDITIONS OF THIS AGREEMENT AND
 * THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW, THEN YOU MAY NOT USE THE CONTENT.</p>
 * 
 * <p>This Content is Copyright (C) 2005 Torsten Juergeleit, 
 * and is provided to you under the terms and conditions of the Common Public 
 * License Version 1.0 ("CPL"). A copy of the CPL is provided with this Content 
 * and is also available at 
 *     <a href="http://www.eclipse.org/legal/cpl-v10.html">
 *         http://www.eclipse.org/legal/cpl-v10.html </a>.
 * 
 * For purposes of the CPL, "Program" will mean the Content.</p>
 * 
 * <p>Content includes, but is not limited to, source code, object code,
 * documentation and any other files in this distribution.</p>
 * 
 * </small>
 */
package org.antlr.eclipse.ui.editor;

import java.io.Reader;
import java.io.StringReader;

import org.eclipse.core.resources.IMarker;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.dialogs.ErrorDialog;
import org.eclipse.ui.IEditorActionBarContributor;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.INavigationLocation;
import org.eclipse.ui.INavigationLocationProvider;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.editors.text.ILocationProvider;
import org.eclipse.ui.ide.IDE;
import org.eclipse.ui.ide.IGotoMarker;
import org.eclipse.ui.part.MultiPageEditorPart;
import org.eclipse.ui.texteditor.ITextEditor;
import org.eclipse.ui.views.contentoutline.IContentOutlinePage;

import org.antlr.eclipse.ui.AntlrUIPlugin;

public class AntlrMultiPageEditor extends MultiPageEditorPart
									   implements INavigationLocationProvider, IGotoMarker {
	private static final String PREFIX = "Editor.page.";

	private static final int PAGE_EDITOR = 0;
	private static final int PAGE_OVERVIEW = 1;

	private AntlrEditor fEditor;
	private AntlrOverview fOverview;
	
	/* (non-Javadoc)
	 * @see org.eclipse.ui.INavigationLocationProvider#createEmptyNavigationLocation()
	 */
	public INavigationLocation createEmptyNavigationLocation() {
		return new AntlrNavigationLocation(fEditor, false);
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.INavigationLocationProvider#createNavigationLocation()
	 */
	public INavigationLocation createNavigationLocation() {
		return new AntlrNavigationLocation(fEditor, true);
	}

	public void activateEditor() {
		if (getActivePage() != PAGE_EDITOR) {
			setActivePage(PAGE_EDITOR);
		}
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.part.MultiPageEditorPart#createPages()
	 */
	protected void createPages() {
		try {
			fEditor = new AntlrEditor(this);
			addPage(fEditor, getEditorInput());
			setPageText(PAGE_EDITOR,
						AntlrUIPlugin.getMessage(PREFIX + "Source"));

			fOverview = new AntlrOverview(getContainer());
			addPage(fOverview.getControl());
			setPageText(PAGE_OVERVIEW,
						AntlrUIPlugin.getMessage(PREFIX + "Overview"));
		} catch (PartInitException e) {
			ErrorDialog.openError(getSite().getShell(),
				 		 AntlrUIPlugin.getMessage("ErrorCreatingNestedEditor"),
				 		 null, e.getStatus());
		}
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.ISaveablePart#doSave(org.eclipse.core.runtime.IProgressMonitor)
	 */
	public void doSave(final IProgressMonitor monitor) {
		getEditor(PAGE_EDITOR).doSave(monitor);
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.ISaveablePart#doSaveAs()
	 */
	public void doSaveAs() {
		IEditorPart editor = getEditor(PAGE_EDITOR);
		editor.doSaveAs();
		setInput(editor.getEditorInput());
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.part.MultiPageEditorPart#getActiveEditor()
	 */
	protected IEditorPart getActiveEditor() {
		return super.getActiveEditor();
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.IEditorPart#gotoMarker(org.eclipse.core.resources.IMarker)
	 */
	public void gotoMarker(final IMarker aMarker) {
		setActivePage(PAGE_EDITOR);
		IDE.gotoMarker(getEditor(PAGE_EDITOR), aMarker);
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.ISaveablePart#isSaveAsAllowed()
	 */
	public boolean isSaveAsAllowed() {
		return true;
	}

	/**
	 * Refresh overview editor if activated.
	 * @see org.eclipse.ui.part.MultiPageEditorPart#pageChange(int)
	 */
	protected void pageChange(final int newPageIndex) {
		super.pageChange(newPageIndex);

		// update AntlrActionContributor
		IEditorPart activeEditor = getEditor(newPageIndex);
		IEditorActionBarContributor contributor = getEditorSite()
				.getActionBarContributor();
		if (contributor != null
				&& contributor instanceof AntlrActionContributor) {
			((AntlrActionContributor) contributor).setActivePage(activeEditor);
		}

		if (newPageIndex == PAGE_OVERVIEW) {
			Reader reader = new StringReader(fEditor.getDocument().get());
			fOverview.show(reader);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.ui.ISaveablePart#isDirty()
	 */
	public boolean isDirty() {
		return fEditor != null && fEditor.isDirty();
	}

	/**
	 * Returns ANTLR content outline page from ANTLR editor page if request.
	 * 
	 * @see org.eclipse.core.runtime.IAdaptable.getAdapter(Class)
	 */ 
	public Object getAdapter(Class aClass) {
	    Object adapter;
		if (aClass.equals(IContentOutlinePage.class)) {
			adapter = fEditor.getAdapter(aClass);
		} else if (aClass.equals(ITextEditor.class)) {
			adapter = fEditor;
		} else {
		    adapter = super.getAdapter(aClass);
		}
		return adapter;
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.part.EditorPart#setInput(org.eclipse.ui.IEditorInput)
	 */
	protected void setInput(IEditorInput anInput) {
		super.setInput(anInput);
		if (anInput != null) {
			setPartName(anInput.getName());

			// If the input is a file then use the path to the input file
			// (without the filename) as content discription
			if (anInput instanceof ILocationProvider) {
				IPath path = ((ILocationProvider) anInput).getPath(anInput);
				setContentDescription(path.removeLastSegments(1).toString());
			}
		}
	}
}
