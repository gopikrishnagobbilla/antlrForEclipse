package org.antlr.eclipse.ui;

import org.eclipse.core.runtime.preferences.AbstractPreferenceInitializer;
import org.eclipse.jface.preference.IPreferenceStore;

/**
 * Initialize default preferences for the ANTLR UI plugin.
 */
public class AntlrPreferenceInitializer extends AbstractPreferenceInitializer {

	/** {@inheritDoc} */
	public void initializeDefaultPreferences() {
		IPreferenceStore store = AntlrUIPlugin.getDefault().getPreferenceStore();
		store.setDefault(IPreferencesConstants.EDITOR_SHOW_SEGMENTS, false);
		AntlrColorProvider.initializeDefaults(store);
	}
}
