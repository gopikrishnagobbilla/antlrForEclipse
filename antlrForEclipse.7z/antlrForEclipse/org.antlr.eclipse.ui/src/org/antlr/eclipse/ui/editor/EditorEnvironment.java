/**
 * <small>
 * <p><i>Copyright (C) 2005 Torsten Juergeleit, 
 * All rights reserved. </i></p>
 * 
 * <p>USE OF THIS CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS
 * AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE
 * OF THE CONTENT IS GOVERNED BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS
 * OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED
 * BELOW. IF YOU DO NOT AGREE TO THE TERMS AND CONDITIONS OF THIS AGREEMENT AND
 * THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW, THEN YOU MAY NOT USE THE CONTENT.</p>
 * 
 * <p>This Content is Copyright (C) 2005 Torsten Juergeleit, 
 * and is provided to you under the terms and conditions of the Common Public 
 * License Version 1.0 ("CPL"). A copy of the CPL is provided with this Content 
 * and is also available at 
 *     <a href="http://www.eclipse.org/legal/cpl-v10.html">
 *         http://www.eclipse.org/legal/cpl-v10.html </a>.
 * 
 * For purposes of the CPL, "Program" will mean the Content.</p>
 * 
 * <p>Content includes, but is not limited to, source code, object code,
 * documentation and any other files in this distribution.</p>
 * 
 * </small>
 */
package org.antlr.eclipse.ui.editor;

import org.antlr.eclipse.ui.AntlrColorProvider;
import org.antlr.eclipse.ui.editor.outline.*;
import org.antlr.eclipse.ui.editor.text.AntlrCodeScanner;
import org.eclipse.jface.text.rules.ITokenScanner;
import org.eclipse.jface.viewers.ILabelProvider;

/**
 * The EditorEnvironment maintains singletons used by the ANTLR editor.
 *
 * @author Torsten Juergeleit
 */
public class EditorEnvironment {

	private static AntlrColorProvider fColorProvider;
	private static ITokenScanner fCodeScanner;
	private static ILabelProvider fLabelProvider;

	private static int fRefCount = 0;

	/**
	 * A connection has occured - initialize the receiver if it is the first
	 * activation.
	 */
	public static void connect() {
		if (++fRefCount == 1) {
			fColorProvider = new AntlrColorProvider();
			fCodeScanner = new AntlrCodeScanner(fColorProvider);
			fLabelProvider = new AntlrOutlineLabelProvider();
		}
	}
	
	/**
	 * A disconnection has occured - clear the receiver if it is the last
	 * deactivation.
	 */
	public static void disconnect() {
		if (--fRefCount == 0) {
			fColorProvider.dispose();
			fColorProvider = null;
			fCodeScanner = null;
			fLabelProvider.dispose();
			fLabelProvider = null;
		}
	}
	
	/**
	 * Returns the singleton color provider.
	 */
	public static AntlrColorProvider getColorProvider() {
		return fColorProvider;
	}
	
	/**
	 * Returns the singleton scanner.
	 */
	public static ITokenScanner getCodeScanner() {
		return fCodeScanner;
	}
	
	/**
	 * Returns the singleton label provider.
	 */
	public static ILabelProvider getLabelProvider() {
		return fLabelProvider;
	}
}
