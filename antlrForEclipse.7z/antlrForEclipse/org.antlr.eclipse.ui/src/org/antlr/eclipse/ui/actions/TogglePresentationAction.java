/**
 * <small>
 * <p><i>Copyright (C) 2005 Torsten Juergeleit, 
 * All rights reserved. </i></p>
 * 
 * <p>USE OF THIS CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS
 * AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE
 * OF THE CONTENT IS GOVERNED BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS
 * OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED
 * BELOW. IF YOU DO NOT AGREE TO THE TERMS AND CONDITIONS OF THIS AGREEMENT AND
 * THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW, THEN YOU MAY NOT USE THE CONTENT.</p>
 * 
 * <p>This Content is Copyright (C) 2005 Torsten Juergeleit, 
 * and is provided to you under the terms and conditions of the Common Public 
 * License Version 1.0 ("CPL"). A copy of the CPL is provided with this Content 
 * and is also available at 
 *     <a href="http://www.eclipse.org/legal/cpl-v10.html">
 *         http://www.eclipse.org/legal/cpl-v10.html </a>.
 * 
 * For purposes of the CPL, "Program" will mean the Content.</p>
 * 
 * <p>Content includes, but is not limited to, source code, object code,
 * documentation and any other files in this distribution.</p>
 * 
 * </small>
 */
package org.antlr.eclipse.ui.actions;

import org.antlr.eclipse.ui.AntlrUIPlugin;
import org.antlr.eclipse.ui.AntlrUIPluginImages;
import org.antlr.eclipse.ui.IPreferencesConstants;
import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.jface.text.IRegion;
import org.eclipse.ui.texteditor.ITextEditor;
import org.eclipse.ui.texteditor.TextEditorAction;

/**
 * A toolbar action which toggles the presentation model of the connected text
 * editor. The editor shows either the highlight range only or always the
 * whole document.
 */
public class TogglePresentationAction extends TextEditorAction {
	private static final String PREFIX = "Editor.TogglePresentation";

	/**
	 * Constructs and updates the action.
	 */
	public TogglePresentationAction() {
		super(AntlrUIPlugin.getDefault().getResourceBundle(), PREFIX, null);
        AntlrUIPluginImages.setToolImageDescriptors(this, "segment_edit.gif");
		update();
	}
	
	/** {@inheritDoc} */
	public void run() {
		ITextEditor editor = getTextEditor();
		if (editor != null) {
			IRegion remembered = editor.getHighlightRange();
			editor.resetHighlightRange();
			
			boolean showAll = !editor.showsHighlightRangeOnly();
			setChecked(showAll);
			setToolTipText(getToolTipText(showAll));
			
			editor.showHighlightRangeOnly(showAll);
			if (remembered != null)  {
				editor.setHighlightRange(remembered.getOffset(),
										 remembered.getLength(), true);
			}
			
			IPreferenceStore store = AntlrUIPlugin.getDefault().getPreferenceStore();
			store.setValue(IPreferencesConstants.EDITOR_SHOW_SEGMENTS, showAll);
		}
	}
	
	/** {@inheritDoc} */
	public void update() {
		ITextEditor editor = getTextEditor();
		boolean checked = (editor != null && editor.showsHighlightRangeOnly());
		setChecked(checked);
		setToolTipText(getToolTipText(checked));
		setEnabled(true);
	}
	
	/** {@inheritDoc} */
	public void setEditor(final ITextEditor anEditor) {
		super.setEditor(anEditor);
		
		if (anEditor != null) {
			IPreferenceStore store = AntlrUIPlugin.getDefault().getPreferenceStore();
			boolean showSegments = store.getBoolean(
									IPreferencesConstants.EDITOR_SHOW_SEGMENTS);
			if (isChecked() != showSegments) {
				setChecked(showSegments);
				setToolTipText(getToolTipText(showSegments));
			}
			
			if (anEditor.showsHighlightRangeOnly() != showSegments) {
				IRegion remembered = anEditor.getHighlightRange();
				anEditor.resetHighlightRange();
				anEditor.showHighlightRangeOnly(showSegments);
				if (remembered != null) {
					anEditor.setHighlightRange(remembered.getOffset(),
											   remembered.getLength(), true);
				}
			}
		}
	}

	private String getToolTipText(final boolean anIsChecked) {
		return (anIsChecked
				? AntlrUIPlugin.getMessage(PREFIX + ".tooltip.checked")
				: AntlrUIPlugin.getMessage(PREFIX + ".tooltip.unchecked"));
	}
}
