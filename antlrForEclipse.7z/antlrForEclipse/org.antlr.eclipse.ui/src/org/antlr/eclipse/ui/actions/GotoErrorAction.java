/**
 * <small>
 * <p><i>Copyright (C) 2005 Torsten Juergeleit, 
 * All rights reserved. </i></p>
 * 
 * <p>USE OF THIS CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS
 * AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE
 * OF THE CONTENT IS GOVERNED BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS
 * OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED
 * BELOW. IF YOU DO NOT AGREE TO THE TERMS AND CONDITIONS OF THIS AGREEMENT AND
 * THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES
 * INDICATED OR REFERENCED BELOW, THEN YOU MAY NOT USE THE CONTENT.</p>
 * 
 * <p>This Content is Copyright (C) 2005 Torsten Juergeleit, 
 * and is provided to you under the terms and conditions of the Common Public 
 * License Version 1.0 ("CPL"). A copy of the CPL is provided with this Content 
 * and is also available at 
 *     <a href="http://www.eclipse.org/legal/cpl-v10.html">
 *         http://www.eclipse.org/legal/cpl-v10.html </a>.
 * 
 * For purposes of the CPL, "Program" will mean the Content.</p>
 * 
 * <p>Content includes, but is not limited to, source code, object code,
 * documentation and any other files in this distribution.</p>
 * 
 * </small>
 */
package org.antlr.eclipse.ui.actions;

import org.antlr.eclipse.ui.AntlrUIPlugin;
import org.antlr.eclipse.ui.AntlrUIPluginImages;
import org.antlr.eclipse.ui.editor.AntlrEditor;
import org.eclipse.ui.texteditor.ITextEditor;
import org.eclipse.ui.texteditor.TextEditorAction;

/**
 * Action that moves us to next/previous errors in the grammar editor
 */
public class GotoErrorAction extends TextEditorAction {
	private boolean fIsForward;

	/**
	 * Create the action
	 * @param anIsForward ?
	 */
	public GotoErrorAction(final boolean anIsForward) {
		super(AntlrUIPlugin.getDefault().getResourceBundle(), (anIsForward ?
						"Editor.NextError." : "Editor.PreviousError.") , null);
		setImageDescriptor(anIsForward ?
						   AntlrUIPluginImages.DESC_TOOL_GOTO_NEXT_ERROR :
						   AntlrUIPluginImages.DESC_TOOL_GOTO_PREV_ERROR);
		fIsForward = anIsForward;
	}
	
	/** {@inheritDoc} */
	public void run() {
		ITextEditor editor = getTextEditor();
		if (editor != null && editor instanceof AntlrEditor) {
			((AntlrEditor)editor).gotoError(fIsForward);
		}
	}
	
	/** {@inheritDoc} */
	public void update() {
		setEnabled(true);
	}
}